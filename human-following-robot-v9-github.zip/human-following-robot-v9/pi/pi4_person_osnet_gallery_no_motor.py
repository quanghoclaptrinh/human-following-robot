#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Raspberry Pi 4 V8: optimized YOLO NCNN + ByteTrack + multi-shot OSNet Person Re-ID.

Reuses the recognition principles of human_following_multimodal_PWM_CONTROL_STABLE.py:
MSMT17-trained OSNet-x0.25, multi-shot immutable target enrollment gallery, top-K
cosine similarity, conservative reacquisition, optional pose/motion/position fusion.

Camera-only experimental version. NO serial, NO PWM calculation, NO ESP32 commands.
V8 adds quality-gated 24-shot enrollment, confidence-aware reacquisition, and lower frame-copy overhead.
Optional distance is *camera bbox-width estimate*, NOT a depth sensor.

Click person: enroll multiple crops. U: forget person. C/1/2/3/4: distance calibration.
Q/Esc: quit. Re-enroll by clicking the person again.

Install base: pip install ultralytics opencv-python numpy
OSNet additionally requires compatible torch, torchvision, torchreid and a trusted
OSNet-x0.25 MSMT17 checkpoint. The checkpoint is NEVER auto-downloaded unless
--download-weights is explicitly requested. For a quick pipeline comparison use
--reid hsv; that mode does NOT run the OSNet method.
"""
from __future__ import annotations

import os
os.environ.setdefault('OMP_NUM_THREADS', '3')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')

import argparse
import hashlib
import math
import time
import urllib.request
from collections import deque
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from ultralytics import YOLO

WINDOW = 'PI4 MULTI-SHOT PERSON RE-ID - NO MOTOR'
CHECKPOINT_NAME = ('osnet_x0_25_msmt17_combineall_256x128_amsgrad_ep150_'
                   'stp60_lr0.0015_b64_fb10_softmax_labelsmooth_flip_jitter.pth')
CHECKPOINT_URL = 'https://huggingface.co/kaiyangzhou/osnet/resolve/main/' + CHECKPOINT_NAME + '?download=true'
CHECKPOINT_SHA256 = 'cf55163d78fc44c62c82f85ab62d39f10438679b5abe8c698ae08cfa84aa6e18'

# Reflect source method. Pose is intentionally OFF by default on Raspberry Pi 4.
# Appearance is the primary identity signal. Motion/position are only supporting cues.
FUSION_WEIGHTS = {'reid': 0.70, 'pose': 0.15, 'motion': 0.10, 'position': 0.05}
# Multi-shot enrollment: more views improve robustness to pose, lighting and partial occlusion.
ENROLL_N = 24
ENROLL_MIN = 8
ENROLL_INTERVAL_S = 0.18
ENROLL_FORCE_S = 0.90
ENROLL_TIMEOUT_S = 75.0
MIN_BLUR_SCORE = 28.0
NOVELTY_SIM_MAX = 0.975
TOP_K = 3
CHECKS_TO_RELEASE = 3
REACQUIRE_CONFIRMS = 2
REACQUIRE_BLOCK_S = 2.5


def parse_camera(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return value


def crop_box(frame, box):
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = [int(round(float(v))) for v in box]
    x1, x2 = max(0, min(x1, w)), max(0, min(x2, w))
    y1, y2 = max(0, min(y1, h)), max(0, min(y2, h))
    if x2 <= x1 or y2 <= y1:
        return None
    return frame[y1:y2, x1:x2]


def box_center(box):
    x1, y1, x2, y2 = map(float, box)
    return ((x1+x2)/2., (y1+y2)/2.)


def normalized(x):
    x = np.asarray(x, dtype=np.float32)
    return x / max(1e-9, float(np.linalg.norm(x)))


def gallery_topk(gallery, feature, k=TOP_K):
    if not gallery or feature is None:
        return -1.0
    scores = [float(np.dot(ref, feature)) for ref in gallery]
    scores.sort(reverse=True)
    return float(np.mean(scores[:min(k, len(scores))]))


def blur_score(crop):
    """Fast focus score; CV_32F is sufficient for screening enrollment crops."""
    if crop is None or crop.size == 0:
        return 0.0
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_32F).var())


def fused_score(reid=None, pose=None, motion=None, position=None):
    scores = {'reid': reid, 'pose': pose, 'motion': motion, 'position': position}
    available = [(max(0., min(1., float(v))), FUSION_WEIGHTS[k])
                 for k, v in scores.items() if v is not None]
    if not available:
        return 0.0
    return float(sum(v*w for v, w in available) / sum(w for _, w in available))


def position_score(center, last_center, frame_shape, elapsed_s):
    if last_center is None:
        return None
    h, w = frame_shape[:2]
    dist = math.hypot(center[0]-last_center[0], center[1]-last_center[1])
    # Avoid rejecting a person simply because the camera itself might rotate.
    allowance = max(40., float(w)*0.60*max(elapsed_s, .08))
    return float(np.clip(1.0-dist/allowance, 0., 1.))


def motion_score(target_hist, candidate_hist):
    """Source-inspired trajectory direction + speed; unavailable => no penalty."""
    if len(target_hist) < 2 or len(candidate_hist) < 2:
        return None
    a, b = target_hist[-2:]
    c, d = candidate_hist[-2:]
    va = np.array([b[0]-a[0], b[1]-a[1]], dtype=np.float32)
    vb = np.array([d[0]-c[0], d[1]-c[1]], dtype=np.float32)
    sa = float(np.linalg.norm(va) / max(b[2]-a[2], 1e-3))
    sb = float(np.linalg.norm(vb) / max(d[2]-c[2], 1e-3))
    if min(sa, sb) < 8.0:
        return None
    direction = float(np.dot(va, vb) / (np.linalg.norm(va)*np.linalg.norm(vb)+1e-6))
    speed_score = float(np.exp(-abs(np.log(max(sa, sb)/max(min(sa, sb), 1e-6)))))
    return float(np.clip(.7*(direction+1.)/2. + .3*speed_score, 0., 1.))


def normalize_pose_keypoints(kpts, confidence=None):
    if kpts is None or len(kpts) < 17:
        return None
    pts = np.asarray(kpts, dtype=np.float32).copy()[:, :2]
    conf = (np.asarray(confidence).reshape(-1) if confidence is not None
            else np.ones(len(pts), dtype=np.float32))
    if len(conf) < len(pts):
        return None
    valid = (conf[:len(pts)] >= .25) & np.isfinite(pts).all(axis=1)
    if not (valid[5] and valid[6]) or int(valid.sum()) < 4:
        return None
    center = (pts[5]+pts[6])/2
    scale = float(np.linalg.norm(pts[5]-pts[6]))
    if scale < 1.:
        return None
    pts = (pts-center)/scale
    pts[~valid] = 0
    return np.concatenate((pts, valid[:, None].astype(np.float32)), axis=1).flatten()


def pose_similarity(a, b):
    if a is None or b is None:
        return None
    a, b = np.asarray(a, dtype=np.float32).reshape(-1, 3), np.asarray(b, dtype=np.float32).reshape(-1, 3)
    if a.shape != b.shape or len(a) < 17:
        return None
    common = (a[:,2] >= .5) & (b[:,2] >= .5)
    if int(common.sum()) < 4:
        return None
    u, v = a[common,:2].flatten(), b[common,:2].flatten()
    return float(np.clip((float(np.dot(u, v))/(float(np.linalg.norm(u)*np.linalg.norm(v))+1e-6)+1.)/2., 0., 1.))


class ReIDBackend:
    def __init__(self, backend, checkpoint, download_weights=False, threads=2):
        self.name = backend
        self.model = None
        self.torch = None
        if backend == 'hsv':
            print('[REID] HSV HISTOGRAM fallback chosen explicitly (not OSNet).')
            return
        try:
            import torch
            import torchreid
            from torchreid.utils import load_pretrained_weights
        except Exception as e:
            raise RuntimeError('OSNet requires compatible torch, torchvision and torchreid. '
                               'Install them in venv, or use --reid hsv to test. '
                               f'Details: {e}') from e
        self.torch = torch
        torch.set_num_threads(max(1, int(threads)))
        # Inter-op threads can only be set before parallel work starts; tolerate
        # an already-initialized runtime (e.g. when imported by another app).
        try:
            torch.set_num_interop_threads(1)
        except RuntimeError:
            pass
        if hasattr(torch.backends, 'mkldnn'):
            torch.backends.mkldnn.enabled = True
        pth = Path(checkpoint).expanduser().resolve()
        if not pth.is_file():
            if not download_weights:
                raise FileNotFoundError('Missing OSNet MSMT17 weights: ' + str(pth) + '\n'
                    'Download the trusted checkpoint into that location, or pass --download-weights. '
                    'Do NOT use random OSNet weights: identity matching needs trained weights.')
            pth.parent.mkdir(parents=True, exist_ok=True)
            temp = str(pth) + '.download'
            print('[REID] Downloading OSNet weights by explicit request...')
            try:
                urllib.request.urlretrieve(CHECKPOINT_URL, temp)
                if self._file_sha256(temp) != CHECKPOINT_SHA256:
                    raise ValueError('Downloaded checkpoint SHA256 mismatch; refusing to load.')
                os.replace(temp, pth)
            finally:
                if os.path.exists(temp):
                    os.remove(temp)
        print('[REID] Checking OSNet checkpoint SHA256...')
        if self._file_sha256(pth) != CHECKPOINT_SHA256:
            raise ValueError('OSNet checkpoint SHA256 mismatch; check whether this is the correct MSMT17 file.')
        print('[REID] Loading OSNet-x0.25 / MSMT17 on CPU...')
        net = torchreid.models.build_model(name='osnet_x0_25', num_classes=1,
                                          loss='softmax', pretrained=False, use_gpu=False)
        load_pretrained_weights(net, str(pth))
        self.model = net.to('cpu').eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        self.mean = np.array([.485, .456, .406], dtype=np.float32).reshape(3, 1, 1)
        self.std = np.array([.229, .224, .225], dtype=np.float32).reshape(3, 1, 1)
        print('[REID] OSNet ready. Input: 256x128 RGB, gallery Top-3 cosine.')

    @staticmethod
    def _file_sha256(path):
        h = hashlib.sha256()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(1024*1024), b''):
                h.update(chunk)
        return h.hexdigest()

    def embed(self, crops):
        """Return list[unit numpy vectors]; batch only crops valid and nonempty."""
        if not crops:
            return []
        if self.name == 'hsv':
            features = []
            for crop in crops:
                r = cv2.resize(crop, (96,192), interpolation=cv2.INTER_AREA)
                hsv = cv2.cvtColor(r, cv2.COLOR_BGR2HSV)
                hist = []
                for region in np.array_split(hsv, 3, axis=0):
                    h = cv2.calcHist([region], [0,1], None, [24,16], [0,180,0,256]).reshape(-1)
                    hist.append(normalized(h))
                features.append(normalized(np.concatenate(hist)))
            return features
        data = []
        for crop in crops:
            resized = cv2.resize(crop, (128,256), interpolation=cv2.INTER_LINEAR)
            rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
            chw = np.ascontiguousarray(rgb.transpose(2,0,1), dtype=np.float32) / 255.
            data.append((chw - self.mean) / self.std)
        batch = self.torch.from_numpy(np.ascontiguousarray(np.stack(data)))
        with self.torch.inference_mode():
            out = self.model(batch)
        if isinstance(out, (tuple, list)):
            out = out[0]
        vals = out.float().cpu().numpy()
        return [normalized(v.copy()) for v in vals]


class PoseBackend:
    def __init__(self, model_path):
        self.model = YOLO(model_path) if model_path else None
        if self.model is None:
            print('[POSE] Disabled (default for Raspberry Pi 4 CPU).')
        else:
            print(f'[POSE] Enabled: {model_path}; this costs extra inference time.')

    def embed(self, crop):
        if self.model is None or crop is None or crop.size == 0:
            return None
        try:
            r = self.model.predict(crop, imgsz=256, verbose=False)[0]
            if r.keypoints is None or len(r.keypoints.xy) == 0:
                return None
            xy = r.keypoints.xy[0].cpu().numpy()
            conf = (r.keypoints.conf[0].cpu().numpy()
                    if r.keypoints.conf is not None else None)
            return normalize_pose_keypoints(xy, conf)
        except Exception as e:
            print('[POSE] Could not calculate pose:', e)
            return None


# Bbox-width distance visualization ported from the prior no-motor Pi build.
# Calibration is PER SELECTED PERSON; no motor decisions use this estimate.
class DistanceEstimator:
    def __init__(self):
        self.reset()

    def reset(self):
        self.points = {}
        self.collecting = None
        self.samples = []
        self.recent = deque(maxlen=3)
        self.filtered = None
        self.last_t = None

    def invalidate(self):
        self.recent.clear()
        self.filtered = None
        self.last_t = None
        if self.collecting is not None:
            self.collecting = None
            self.samples.clear()

    def start(self, meters):
        self.collecting = float(meters)
        self.samples.clear()
        self.recent.clear()
        self.filtered = None
        print(f'[CALIB] Stand at {meters:.2f}m, face the camera; collecting 8 frames.')

    def update(self, box, shape):
        h, w = shape[:2]
        x1,y1,x2,y2 = map(float, box)
        width = x2-x1
        if x1 <= 5 or x2 >= w-5 or width < 35 or y2 <= y1:
            self.invalidate()
            return None, 'WIDTH UNRELIABLE / SIDE CLIP'
        if self.collecting is not None:
            self.samples.append(width)
            if len(self.samples) < 8:
                return None, f'CALIB {len(self.samples)}/8'
            vals = np.array(self.samples, dtype=float)
            med = float(np.median(vals))
            spread = (np.max(vals)-np.min(vals))/max(med,1.)
            at = self.collecting
            self.collecting = None
            self.samples.clear()
            pts = dict(self.points)
            pts[at] = med
            ordered = sorted(pts.items())
            if spread > .10 or any(ordered[i][1] <= ordered[i+1][1] for i in range(len(ordered)-1)):
                return None, 'CALIB UNSTABLE / NON-MONOTONIC - RETRY'
            self.points = pts
            print(f'[CALIB] OK: {at:.2f}m = {med:.1f}px; {len(self.points)} point(s)')
        if not self.points:
            return None, 'PRESS C / 1 / 2 / 3 / 4 TO CALIB'
        pts = sorted(self.points.items())
        if len(pts) == 1:
            d, rw = pts[0]
            raw = d*rw/width
            label = '1-POINT ESTIMATE'
        else:
            xp = sorted((1./rw,d) for d,rw in pts)
            value = 1./width
            if value < xp[0][0] or value > xp[-1][0]:
                self.invalidate()
                return None, 'OUTSIDE CALIBRATED RANGE'
            raw = float(np.interp(value,[p[0] for p in xp],[p[1] for p in xp]))
            label = 'MULTI-POINT ESTIMATE'
        self.recent.append(raw)
        med = float(np.median(self.recent))
        now = time.monotonic()
        alpha = 1. if self.last_t is None else 1.-math.exp(-max(0.,now-self.last_t)/.35)
        self.last_t = now
        self.filtered = med if self.filtered is None else self.filtered + alpha*(med-self.filtered)
        return self.filtered, label


class TargetManager:
    """Conservative multi-shot target gallery with identity continuity across ID changes."""
    def __init__(self, reid, pose, args):
        self.reid, self.pose, self.args = reid, pose, args
        self.reset()

    def reset(self):
        self.id = None
        self.memory_id = None
        self.gallery = []  # immutable enrollment gallery after finalize
        self.trusted = []  # strictly screened, slowly growing gallery
        self.pose_gallery = []
        self.enroll_id = None
        self.enroll_start = 0.
        self.enroll_last_probe = 0.
        self.enroll_last_accept = 0.
        self.enroll_missed = 0
        self.last_center = None
        self.last_seen = 0.
        self.last_trusted_add = 0.
        self.last_score = None
        self.last_fusion = None
        self.last_pose = None
        self.last_motion = None
        self.last_pos = None
        self.suspicious = 0
        self.pending_id = None
        self.pending_count = 0
        self.frame_idx = 0
        self.blocked_ids = {}
        self.histories = {}
        self.target_history = []
        self.reid_seconds = 0.
        self.pose_seconds = 0.

    def begin_enrollment(self, track_id):
        self.reset()
        self.enroll_id = int(track_id)
        self.enroll_start = time.monotonic()
        print(f'[TARGET] Capturing {ENROLL_N} images of ByteTrack ID {track_id} for gallery...')

    def _embed(self, crops):
        t = time.perf_counter()
        ans = self.reid.embed(crops)
        self.reid_seconds += time.perf_counter()-t
        return ans

    def _usable_crop(self, crop):
        """Reject crops too small for dependable person Re-ID."""
        if crop is None or crop.size == 0:
            return False
        h, w = crop.shape[:2]
        return h >= self.args.reid_min_height and w >= self.args.reid_min_width

    def _pose(self, crop):
        if self.pose.model is None:
            return None
        t = time.perf_counter()
        ans = self.pose.embed(crop)
        self.pose_seconds += time.perf_counter()-t
        return ans

    def _history(self, boxes, ids, now):
        seen = set()
        for box, tid in zip(boxes, ids):
            tid = int(tid)
            cx,cy = box_center(box)
            history = self.histories.setdefault(tid, [])
            history.append((cx, cy, now))
            del history[:-12]
            seen.add(tid)
        # Prevent unbounded growth of IDs in crowded scenes.
        if len(self.histories) > 80:
            for tid in list(self.histories):
                if tid not in seen:
                    del self.histories[tid]
                if len(self.histories) <= 60:
                    break

    def _pose_match(self, crop):
        p = self._pose(crop)
        if p is None or not self.pose_gallery:
            return None
        sims = [pose_similarity(g, p) for g in self.pose_gallery]
        sims = sorted((s for s in sims if s is not None), reverse=True)
        return float(np.mean(sims[:3])) if sims else None

    def _gallery_match(self, emb):
        original = gallery_topk(self.gallery, emb)
        trusted = gallery_topk(self.trusted, emb) if self.trusted else original
        # Permanent identity anchor dominates adaptive trusted images.
        return .80*original + .20*trusted

    def _finish_enrollment(self, tid, box, now):
        self.id = self.memory_id = int(tid)
        self.enroll_id = None
        self.last_center = box_center(box)
        self.last_seen = now
        self.last_score = self.last_fusion = 1.
        self.target_history = list(self.histories.get(self.id, []))
        print(f'[TARGET] LOCKED memory={self.memory_id}, ByteTrack ID={self.id}, '
              f'gallery={len(self.gallery)}, pose={len(self.pose_gallery)}')

    def update(self, frame, boxes, ids, confidences=None):
        """Return (confirmed target bbox or None, status). No motor outputs.

        ``confidences`` is optional so the motor wrapper and older callers remain
        API-compatible; missing confidence values are treated as 1.0.
        """
        self.frame_idx += 1
        self.reid_seconds = self.pose_seconds = 0.
        now = time.monotonic()
        self._history(boxes, ids, now)
        self.blocked_ids = {i:expiry for i,expiry in self.blocked_ids.items() if expiry > now}
        if confidences is None:
            confs = np.ones(len(ids), dtype=np.float32)
        else:
            confs = np.asarray(confidences, dtype=np.float32).reshape(-1)
            if len(confs) < len(ids):
                confs = np.pad(confs, (0, len(ids)-len(confs)), constant_values=1.0)
            confs = confs[:len(ids)]
        indexed = {int(tid): (idx,box,float(confs[idx]))
                   for idx,(box,tid) in enumerate(zip(boxes,ids))}
        if self.enroll_id is not None:
            item = indexed.get(self.enroll_id)
            if item is None:
                self.enroll_missed += 1
                if self.enroll_missed > 10:
                    print('[TARGET] Enrollment aborted: target ID disappeared.')
                    self.reset()
                return None, f'ENROLL: WAIT TARGET {self.enroll_missed}/10'
            self.enroll_missed = 0
            box, detection_conf = item[1], item[2]
            if now-self.enroll_last_probe >= ENROLL_INTERVAL_S:
                self.enroll_last_probe = now
                crop = crop_box(frame, box)
                if (detection_conf >= self.args.reid_min_conf and self._usable_crop(crop)
                        and blur_score(crop) >= self.args.min_blur_score):
                    emb = self._embed([crop])[0]
                    novelty = max((float(np.dot(g,emb)) for g in self.gallery), default=-1.)
                    accept = novelty < NOVELTY_SIM_MAX or not self.gallery or (now-self.enroll_last_accept >= ENROLL_FORCE_S)
                    if accept:
                        self.gallery.append(emb.copy())
                        self.enroll_last_accept = now
                        if self.pose.model is not None and (len(self.gallery)==1 or len(self.gallery)%4==0):
                            p = self._pose(crop)
                            if p is not None:
                                self.pose_gallery.append(p)
                        print(f'[GALLERY] {len(self.gallery)}/{ENROLL_N}; similarity={novelty:.3f}')
            if len(self.gallery) >= ENROLL_N or (now-self.enroll_start >= ENROLL_TIMEOUT_S):
                if len(self.gallery) >= ENROLL_MIN:
                    self._finish_enrollment(self.enroll_id, box, now)
                    return np.asarray(box), 'TRACKED / GALLERY READY'
                print('[TARGET] Not enough enrollment images: retry clicking person.')
                self.reset()
                return None, 'ENROLL FAILED - CLICK AGAIN'
            return None, f'ENROLLING {len(self.gallery)}/{ENROLL_N} - WAIT'

        if not self.gallery:
            return None, 'CLICK PERSON TO ENROLL'

        # ByteTrack continuity, periodically cross-checked against *immutable* gallery.
        if self.id is not None and self.id in indexed:
            box, detection_conf = indexed[self.id][1], indexed[self.id][2]
            if detection_conf < self.args.reid_min_conf:
                return None, f'LOW DETECTION CONFIDENCE ({detection_conf:.2f}) - HOLD'
            verify = (self.frame_idx % max(1,self.args.reid_every) == 0)
            if verify:
                crop = crop_box(frame, box)
                if self._usable_crop(crop) and blur_score(crop) >= self.args.min_blur_score:
                    emb = self._embed([crop])[0]
                    score = self._gallery_match(emb)
                    self.last_score = score
                    pose = (self._pose_match(crop) if self.pose.model is not None and
                            self.frame_idx % max(1,self.args.pose_every)==0 else None)
                    elapsed = max(0.,now-self.last_seen)
                    pos = position_score(box_center(box),self.last_center,frame.shape,elapsed)
                    fusion = fused_score(reid=score, pose=pose, position=pos)
                    self.last_fusion,self.last_pose,self.last_pos = fusion,pose,pos
                    self.last_motion = None  # Same-ID trajectory cannot prove identity.
                    sanity = .50 if self.reid.name == 'osnet' else .64
                    passed = score >= sanity and fusion >= self.args.fusion_track
                    if passed:
                        self.suspicious = 0
                        if score >= (.82 if self.reid.name=='osnet' else .86) and now-self.last_trusted_add >= 2.:
                            if gallery_topk(self.trusted, emb, 1) < .97 or not self.trusted:
                                self.trusted.append(emb.copy())
                                del self.trusted[:-16]
                                self.last_trusted_add = now
                    else:
                        self.suspicious += 1
            if self.suspicious >= CHECKS_TO_RELEASE:
                old = self.id
                print(f'[TARGET] ID {old} uncertain after repeated gallery checks '
                      f'(reid={self.last_score:.3f}, fusion={self.last_fusion:.3f}); searching...')
                self.blocked_ids[old] = now + REACQUIRE_BLOCK_S
                self.id = None
                self.pending_id = None
                self.pending_count = 0
                return None, 'IDENTITY UNCERTAIN - SEARCHING'
            if self.suspicious:
                return None, f'IDENTITY CHECK {self.suspicious}/{CHECKS_TO_RELEASE}'
            self.last_center = box_center(box)
            self.last_seen = now
            self.target_history = list(self.histories.get(self.id,[]))
            return np.asarray(box), f'TRACKED ID {self.id}'

        self.id = None
        if self.frame_idx % max(1,self.args.reacquire_every) != 0:
            return None, 'SEARCHING GALLERY (WAIT)'
        valid = []
        for tid,(idx,box,detection_conf) in indexed.items():
            if tid in self.blocked_ids or detection_conf < self.args.reid_min_conf:
                continue
            crop = crop_box(frame,box)
            if self._usable_crop(crop) and blur_score(crop) >= self.args.min_blur_score:
                valid.append((tid,np.asarray(box),crop,detection_conf))
        # Use location only shortly after loss. After a longer gap (or camera
        # movement), prioritize clear, confident, sufficiently large detections.
        elapsed_lost = max(0.0, now-self.last_seen)
        if self.last_center and elapsed_lost < 1.5:
            valid.sort(key=lambda item: (
                math.dist(box_center(item[1]),self.last_center) /
                max(1.0, math.hypot(frame.shape[1],frame.shape[0])),
                -item[3], -float(item[1][3]-item[1][1])))
        else:
            valid.sort(key=lambda item: (-item[3], -float(item[1][3]-item[1][1])))
        valid = valid[:max(1,self.args.max_candidates)]
        if not valid:
            self.pending_id = None
            self.pending_count = 0
            return None, 'TARGET LOST / GALLERY KEPT'
        features = self._embed([v[2] for v in valid])
        scored = []
        for (tid,box,crop,detection_conf),emb in zip(valid,features):
            reid = self._gallery_match(emb)
            pos = position_score(box_center(box),self.last_center,frame.shape,now-self.last_seen)
            mot = motion_score(self.target_history, self.histories.get(tid,[]))
            # Pose computed only for top Re-ID candidate below, not all people.
            scored.append({'id':tid,'box':box,'crop':crop,'reid':reid,'position':pos,
                           'motion':mot,'confidence':detection_conf})
        scored.sort(key=lambda x:x['reid'],reverse=True)
        if not scored:
            return None, 'NO VALID RE-ID CANDIDATE'
        # Expensive pose call only on the top candidate, if explicitly enabled.
        for i,item in enumerate(scored):
            pose = (self._pose_match(item['crop']) if i==0 and self.pose.model is not None else None)
            item['pose'] = pose
            item['fusion'] = fused_score(reid=item['reid'],pose=pose,
                                         motion=item['motion'],position=item['position'])
        # Re-rank using the multimodal fusion; pose not available for all candidates
        # so require a hard Re-ID gate and a Re-ID margin independently.
        scored.sort(key=lambda x:x['fusion'],reverse=True)
        best = scored[0]
        runner = max((item['reid'] for item in scored if item is not best), default=-1.)
        threshold = (.68 if len(scored)==1 else .62) if self.reid.name=='osnet' else .68
        # Track source's FUSION_REACQUIRE_THRESH but never let position rescue
        # a weak appearance match or an ambiguous two-person scene.
        allowed = (best['reid'] >= threshold and best['fusion'] >= self.args.fusion_reacquire and
                   best['reid']-runner >= self.args.reid_margin)
        self.last_score,self.last_fusion = best['reid'],best['fusion']
        self.last_pose,self.last_motion,self.last_pos = best['pose'],best['motion'],best['position']
        if not allowed:
            self.pending_id = None
            self.pending_count = 0
            return None, f'SEARCHING (best ReID={best["reid"]:.2f})'
        if best['id'] == self.pending_id:
            self.pending_count += 1
        else:
            self.pending_id = best['id']
            self.pending_count = 1
        if self.pending_count < REACQUIRE_CONFIRMS:
            return None, f'VERIFY {best["id"]}: {self.pending_count}/{REACQUIRE_CONFIRMS}'
        old = self.memory_id
        self.id = int(best['id'])
        self.pending_id = None
        self.pending_count = 0
        self.suspicious = 0
        self.last_center = box_center(best['box'])
        self.last_seen = now
        self.target_history = list(self.histories.get(self.id, []))
        print(f'[TARGET] REACQUIRED memory={old} -> ByteTrack {self.id}, '
              f'ReID={best["reid"]:.3f}, fusion={best["fusion"]:.3f}')
        return best['box'], f'REACQUIRED ID {self.id}'


class App:
    def __init__(self,args):
        self.args = args
        cv2.setNumThreads(1)
        self.reid = ReIDBackend(args.reid,args.weights,args.download_weights,args.reid_threads)
        self.pose = PoseBackend(args.pose_model)
        self.manager = TargetManager(self.reid,self.pose,args)
        self.distance = DistanceEstimator()
        print('[YOLO] Loading NCNN detector:',args.model)
        self.detector = YOLO(args.model)
        backend = cv2.CAP_V4L2 if os.name != 'nt' and isinstance(args.camera,int) else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(args.camera,backend)
        if args.mjpeg:
            self.cap.set(cv2.CAP_PROP_FOURCC,cv2.VideoWriter_fourcc(*'MJPG'))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
        self.cap.set(cv2.CAP_PROP_FPS,15)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE,1)
        if not self.cap.isOpened():
            raise RuntimeError(f'Cannot open camera {args.camera}; check /dev/video* and --camera')
        print('[CAMERA] Connected:',args.camera)
        self.show_frame = None
        self.show_boxes = np.empty((0,4),np.float32)
        self.show_ids = np.empty((0,),np.int32)
        self.profile_start = time.perf_counter()
        self.profile_n = 0
        self.profile_sum = np.zeros(6,dtype=float)  # camera, yolo, reid, pose, etc, display
        self.frametimes = deque(maxlen=20)
        self.frame_number = 0
        cv2.namedWindow(WINDOW,cv2.WINDOW_NORMAL)
        cv2.setMouseCallback(WINDOW,self.on_mouse)

    def on_mouse(self,event,x,y,_flags,_ud):
        if event != cv2.EVENT_LBUTTONDOWN or self.show_frame is None:
            return
        for box,tid in zip(self.show_boxes,self.show_ids):
            x1,y1,x2,y2 = map(float,box)
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.distance.reset()
                self.manager.begin_enrollment(int(tid))
                return

    def draw(self,frame,boxes,ids,target,status,dist,dist_info,fps):
        h,w = frame.shape[:2]
        cv2.line(frame,(w//2,0),(w//2,h),(255,180,0),1)
        tracked_id = self.manager.id
        for box,tid in zip(boxes,ids):
            x1,y1,x2,y2 = map(int,box)
            istarget = tracked_id is not None and int(tid)==tracked_id and target is not None
            isenroll = self.manager.enroll_id is not None and int(tid)==self.manager.enroll_id
            color = (30,230,30) if istarget else ((30,180,240) if isenroll else (180,180,180))
            cv2.rectangle(frame,(x1,y1),(x2,y2),color,2)
            cv2.putText(frame,f'ID {int(tid)}', (x1,max(15,y1-6)),cv2.FONT_HERSHEY_SIMPLEX,.5,color,1)
        textlines = [
            f'NCNN+ByteTrack | ReID={self.reid.name.upper()} | FPS {fps:.1f} | NO MOTOR',
            f'{status}',
            f'Identity memory: {self.manager.memory_id if self.manager.memory_id is not None else "--"}',
            f'ReID: {self.manager.last_score:.3f}' if self.manager.last_score is not None else 'ReID: --',
            f'Fusion: {self.manager.last_fusion:.3f}' if self.manager.last_fusion is not None else 'Fusion: --',
            (f'Distance: {dist:.2f} m ({dist_info})' if dist is not None
             else f'Distance: -- ({dist_info})'),
            'Click: enroll | U: unlock | C/1/2/3/4: calib | Q: quit',
        ]
        for i,msg in enumerate(textlines):
            # Simple backing strip so legibility does not depend on image color.
            y = 23+i*24
            cv2.rectangle(frame,(0,y-19),(min(w,650),y+4),(12,12,12),-1)
            cv2.putText(frame,msg[:94],(7,y),cv2.FONT_HERSHEY_SIMPLEX,.47,(240,240,240),1,cv2.LINE_AA)
        if target is not None:
            cx,cy = box_center(target)
            cv2.circle(frame,(int(cx),int(cy)),7,(0,255,0),2)
            error = 100.0*(cx-w/2)/(w/2)
            cv2.putText(frame,f'HORIZONTAL OFFSET: {error:+.1f}% (display only)',(8,h-12),
                        cv2.FONT_HERSHEY_SIMPLEX,.53,(0,255,255),2,cv2.LINE_AA)
        cv2.putText(frame,'NO PWM / NO SERIAL / NO ESP32',(7,h-36),
                    cv2.FONT_HERSHEY_SIMPLEX,.5,(100,220,255),2,cv2.LINE_AA)

    def run(self):
        print('[READY] VISION-ONLY, NO SERIAL, NO PWM, NO MOTOR COMMAND. Click a person.')
        try:
            while True:
                t0 = time.perf_counter()
                ok,frame = self.cap.read()
                t1 = time.perf_counter()
                if not ok or frame is None:
                    print('[CAMERA] Frame unavailable')
                    time.sleep(.05)
                    continue
                if self.args.flip == 'horizontal':
                    frame = cv2.flip(frame,1)
                elif self.args.flip == 'vertical':
                    frame = cv2.flip(frame,0)
                elif self.args.flip == 'both':
                    frame = cv2.flip(frame,-1)
                # Do not duplicate every frame. The display copy is made only on
                # display frames, after detection and identity processing.
                clean = frame
                result = self.detector.track(frame,persist=True,tracker='bytetrack.yaml',
                                             classes=[0],conf=self.args.conf,
                                             imgsz=self.args.imgsz,verbose=False)[0]
                t2 = time.perf_counter()
                if result.boxes is not None and result.boxes.id is not None:
                    boxes = result.boxes.xyxy.cpu().numpy().astype(np.float32)
                    ids = result.boxes.id.cpu().numpy().astype(np.int32)
                    confidences = (result.boxes.conf.cpu().numpy().astype(np.float32)
                                   if result.boxes.conf is not None else None)
                else:
                    boxes=np.empty((0,4),dtype=np.float32)
                    ids=np.empty((0,),dtype=np.int32)
                    confidences=np.empty((0,),dtype=np.float32)
                target,status = self.manager.update(clean,boxes,ids,confidences)
                if target is None:
                    self.distance.invalidate()
                    d,d_info = None,'TARGET NOT CONFIRMED'
                else:
                    d,d_info = self.distance.update(target,clean.shape)
                t3 = time.perf_counter()
                self.frame_number += 1
                self.frametimes.append(t0)
                fps = ((len(self.frametimes)-1)/(self.frametimes[-1]-self.frametimes[0])
                       if len(self.frametimes)>1 else 0.)
                if self.frame_number % self.args.display_every == 0:
                    self.show_frame = clean  # unmodified frame matching displayed boxes
                    self.show_boxes = boxes.copy()
                    self.show_ids = ids.copy()
                    display_frame = clean.copy()
                    self.draw(display_frame,boxes,ids,target,status,d,d_info,fps)
                    cv2.imshow(WINDOW,display_frame)
                key = cv2.waitKey(1) & 255
                t4 = time.perf_counter()
                self.profile_n += 1
                rid,pose = self.manager.reid_seconds,self.manager.pose_seconds
                self.profile_sum += np.array([t1-t0,t2-t1,rid,pose,max(0.,t3-t2-rid-pose),t4-t3])
                if t4-self.profile_start >= self.args.profile_interval:
                    avg=1000*self.profile_sum/max(1,self.profile_n)
                    real_fps=self.profile_n/(t4-self.profile_start)
                    print(f'[PROFILE] FPS_REAL={real_fps:.2f} CAMERA={avg[0]:.1f}ms '
                          f'YOLO_TRACK={avg[1]:.1f}ms REID={avg[2]:.1f}ms '
                          f'POSE={avg[3]:.1f}ms ETC={avg[4]:.1f}ms DISPLAY={avg[5]:.1f}ms')
                    self.profile_n = 0
                    self.profile_sum[:] = 0
                    self.profile_start = t4
                if key in (ord('q'),27):
                    break
                if key == ord('u'):
                    self.manager.reset()
                    self.distance.reset()
                    print('[TARGET] Unlocked and enrollment gallery cleared.')
                if key in (ord('c'),ord('1'),ord('2'),ord('3'),ord('4')):
                    ds = {ord('c'):self.args.calib_distance,ord('1'):1.,
                          ord('2'):1.5,ord('3'):2.,ord('4'):2.5}
                    if target is None:
                        print('[CALIB] Must have CONFIRMED target first.')
                    else:
                        self.distance.start(ds[key])
        finally:
            self.cap.release()
            cv2.destroyAllWindows()
        return 0


def build_parser():
    p=argparse.ArgumentParser(description='Pi4 YOLO NCNN + OSNet MSMT17 gallery Re-ID; NO MOTOR / PWM / SERIAL')
    p.add_argument('--camera',type=parse_camera,default=0)
    p.add_argument('--model',default='yolo26n_ncnn_model',help='Local YOLO NCNN model directory')
    p.add_argument('--imgsz',type=int,default=288)
    p.add_argument('--conf',type=float,default=.4)
    p.add_argument('--display-every',type=int,default=4)
    p.add_argument('--profile-interval',type=float,default=3.)
    p.add_argument('--mjpeg',action='store_true')
    p.add_argument('--flip',choices=['none','horizontal','vertical','both'],default='none')
    p.add_argument('--reid',choices=['osnet','hsv'],default='osnet',help='Default OSNet; HSV is fallback comparison ONLY')
    p.add_argument('--weights',default=CHECKPOINT_NAME,help='Path to OSNet-x0.25 MSMT17 checkpoint')
    p.add_argument('--download-weights',action='store_true',help='Explicit permission to download SHA256-verified checkpoint')
    p.add_argument('--reid-threads',type=int,default=2)
    p.add_argument('--reid-every',type=int,default=6,help='Verify tracked identity every N frames')
    p.add_argument('--reacquire-every',type=int,default=2,help='Search gallery when ID missing every N frames')
    p.add_argument('--max-candidates',type=int,default=4,
                   help='Maximum people embedded per reacquisition pass (higher = better recall, slower)')
    p.add_argument('--reid-min-conf',type=float,default=.45,
                   help='Minimum detector confidence before enrollment/Re-ID')
    p.add_argument('--reid-min-height',type=int,default=48,
                   help='Minimum person-crop height in pixels for dependable Re-ID')
    p.add_argument('--reid-min-width',type=int,default=20,
                   help='Minimum person-crop width in pixels for dependable Re-ID')
    p.add_argument('--min-blur-score',type=float,default=28.0,
                   help='Minimum Laplacian focus score for enrollment/reacquisition crops')
    p.add_argument('--pose-model',default='',help='Optional local YOLO pose model; OFF by default for Pi4')
    p.add_argument('--pose-every',type=int,default=12)
    p.add_argument('--fusion-track',type=float,default=.62)
    p.add_argument('--fusion-reacquire',type=float,default=.64)
    p.add_argument('--reid-margin',type=float,default=.06)
    p.add_argument('--calib-distance',type=float,default=1.5)
    return p


def main():
    args=build_parser().parse_args()
    if args.imgsz < 160 or args.imgsz % 32:
        raise SystemExit('--imgsz must be >=160 and divisible by 32')
    if min(args.display_every,args.reid_threads,args.reid_every,args.reacquire_every,
           args.max_candidates,args.pose_every,args.reid_min_height,args.reid_min_width) < 1:
        raise SystemExit('display, inference intervals, threads and crop dimensions must be >=1')
    if not (0.0 <= args.reid_min_conf <= 1.0) or args.min_blur_score < 0:
        raise SystemExit('Re-ID confidence must be 0..1 and blur threshold must be >=0')
    try:
        return App(args).run()
    except KeyboardInterrupt:
        return 0
    except Exception as e:
        print('[FATAL]',e)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
