#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure-Python DDMR V9.0 control core."""
from __future__ import annotations
import math

PWM_LIMIT = 55.0


def clamp(value, low, high):
    return max(low, min(high, value))


def parse_encoder_telemetry_line(line):
    """E,seq,countL,countR,vL,vR,pwmL,pwmR,ageMs,active"""
    fields = str(line).strip().split(",")
    if len(fields) < 9 or fields[0] != "E":
        return None
    try:
        item = {
            "seq": int(fields[1]),
            "countL": int(fields[2]),
            "countR": int(fields[3]),
            "vL": float(fields[4]),
            "vR": float(fields[5]),
            "pwmL": int(fields[6]),
            "pwmR": int(fields[7]),
            "command_age_ms": int(fields[8]),
            "remote_active": bool(int(fields[9])) if len(fields) > 9 else False,
        }
    except (ValueError, OverflowError):
        return None
    if not math.isfinite(item["vL"]) or not math.isfinite(item["vR"]):
        return None
    return item


class JerkLimitedPWM:
    def __init__(self, max_accel_up=260.0, max_accel_down=360.0,
                 max_jerk=1200.0, max_rate_up=150.0,
                 max_rate_down=240.0, pwm_limit=PWM_LIMIT):
        self.pwm_limit = pwm_limit
        self.max_accel_up = float(max_accel_up)
        self.max_accel_down = float(max_accel_down)
        self.max_jerk = float(max_jerk)
        self.max_rate_up = float(max_rate_up)
        self.max_rate_down = float(max_rate_down)
        self.value = 0.0
        self.acceleration = 0.0

    def reset(self):
        self.value = 0.0
        self.acceleration = 0.0

    def update(self, target, dt):
        target = clamp(float(target), -self.pwm_limit, self.pwm_limit)
        dt = clamp(float(dt), 0.005, 0.30)

        if self.value * target < 0.0:
            target = 0.0

        error = target - self.value
        if abs(error) < 0.35 and abs(self.acceleration) < 2.0:
            self.value = target
            self.acceleration = 0.0
            return self.value

        if error >= 0:
            rate_limit = self.max_rate_up
            accel_limit = self.max_accel_up
        else:
            rate_limit = self.max_rate_down
            accel_limit = self.max_accel_down

        desired_accel = clamp(error / dt, -rate_limit, rate_limit)
        desired_accel = clamp(desired_accel, -accel_limit, accel_limit)
        jerk = clamp((desired_accel - self.acceleration) / dt,
                     -self.max_jerk, self.max_jerk)
        self.acceleration = clamp(
            self.acceleration + jerk * dt, -accel_limit, accel_limit)
        self.value += self.acceleration * dt

        if (target - self.value) * error <= 0:
            self.value = target
            self.acceleration = 0.0

        self.value = clamp(self.value, -self.pwm_limit, self.pwm_limit)
        return self.value


class WheelEncoderPI:
    def __init__(self, pwm_bands, speed_bands, kp=260.0, ki=75.0, pwm_limit=PWM_LIMIT):
        self.pwm_limit = pwm_limit
        self.pwm_bands = [float(v) for v in pwm_bands]
        self.speed_bands = [float(v) for v in speed_bands]
        self.kp = float(kp)
        self.ki = float(ki)
        self.integral = 0.0
        self.last_sign = 0

    def reset(self):
        self.integral = 0.0
        self.last_sign = 0

    def speed_reference(self, target_pwm):
        magnitude = abs(float(target_pwm))
        if magnitude < 0.5:
            return 0.0

        xs, ys = self.pwm_bands, self.speed_bands

        if magnitude <= xs[0]:
            speed = ys[0] * magnitude / max(xs[0], 1e-6)
        elif magnitude >= xs[-1]:
            dx = max(xs[-1] - xs[-2], 1e-6)
            slope = (ys[-1] - ys[-2]) / dx
            speed = ys[-1] + slope * (magnitude - xs[-1])
        else:
            speed = ys[-1]
            for i in range(6):
                if xs[i] <= magnitude <= xs[i + 1]:
                    ratio = (magnitude - xs[i]) / max(
                        xs[i + 1] - xs[i], 1e-6)
                    speed = ys[i] + ratio * (ys[i + 1] - ys[i])
                    break

        return max(0.0, speed) * (1 if target_pwm >= 0 else -1)

    def update(self, target_pwm, measured_mps, dt):
        target_pwm = clamp(float(target_pwm), -self.pwm_limit, self.pwm_limit)
        measured_mps = float(measured_mps)
        dt = clamp(float(dt), 0.005, 0.30)

        if not math.isfinite(measured_mps) or abs(target_pwm) < 0.5:
            self.reset()
            return 0.0

        sign = 1 if target_pwm > 0 else -1
        if self.last_sign and sign != self.last_sign:
            self.integral = 0.0
        self.last_sign = sign

        target_speed = abs(self.speed_reference(target_pwm))
        measured_along_command = sign * measured_mps
        error = target_speed - measured_along_command

        requested = abs(target_pwm) + self.kp * error + self.integral
        output = clamp(requested, 0.0, self.pwm_limit)

        high_sat = requested > self.pwm_limit
        low_sat = requested < 0.0

        if ((not high_sat and not low_sat) or
            (high_sat and error < 0) or
            (low_sat and error > 0)):
            self.integral = clamp(
                self.integral + self.ki * error * dt, -40.0, 40.0)

        return sign * output


class FollowController:
    BAND_THRESHOLDS = (0.06, 0.12, 0.19, 0.27, 0.38, 0.54, 1.01)

    def __init__(self, args):
        self.args = args
        self.pwm_limit = args.pwm_limit
        self.filtered_error = 0.0
        self.derivative = 0.0
        self.previous_filtered_error = 0.0
        self.previous_time = None
        self.turn_active = False
        self.filtered_distance = None
        self.distance_active = False

        self.left_pi = WheelEncoderPI(
            args.pwm_bands_left, args.speed_bands_left,
            args.encoder_kp, args.encoder_ki, args.pwm_limit)
        self.right_pi = WheelEncoderPI(
            args.pwm_bands_right, args.speed_bands_right,
            args.encoder_kp, args.encoder_ki, args.pwm_limit)

        self.left_scurve = JerkLimitedPWM(pwm_limit=args.pwm_limit)
        self.right_scurve = JerkLimitedPWM(pwm_limit=args.pwm_limit)

        self.band_index = 0
        self.mode = "STOP"
        self.pd_output = 0.0
        self.target_left = self.target_right = 0.0
        self.applied_left = self.applied_right = 0
        self.v_ref_left = self.v_ref_right = 0.0
        self.v_meas_left = self.v_meas_right = 0.0
        self.reverse_time_left = self.reverse_time_right = 0.0
        self.stall_time_left = self.stall_time_right = 0.0
        self.fault = None

    def reset(self):
        self.filtered_error = 0.0
        self.derivative = 0.0
        self.previous_filtered_error = 0.0
        self.previous_time = None
        self.turn_active = False
        self.filtered_distance = None
        self.distance_active = False

        self.left_pi.reset()
        self.right_pi.reset()
        self.left_scurve.reset()
        self.right_scurve.reset()

        self.band_index = 0
        self.mode = "STOP"
        self.pd_output = 0.0
        self.target_left = self.target_right = 0.0
        self.applied_left = self.applied_right = 0
        self.v_ref_left = self.v_ref_right = 0.0
        self.v_meas_left = self.v_meas_right = 0.0
        self.reverse_time_left = self.reverse_time_right = 0.0
        self.stall_time_left = self.stall_time_right = 0.0
        self.fault = None

    def _band(self, magnitude):
        for index, threshold in enumerate(self.BAND_THRESHOLDS):
            if magnitude <= threshold:
                return index
        return 6

    def _update_pd(self, raw_error, dt):
        tau = self.args.error_filter_tau
        alpha = 1.0 - math.exp(-dt / max(tau, 1e-3))
        self.filtered_error += alpha * (raw_error - self.filtered_error)

        raw_derivative = (
            self.filtered_error - self.previous_filtered_error) / max(dt, 1e-3)
        self.previous_filtered_error = self.filtered_error

        raw_derivative = clamp(
            raw_derivative, -self.args.derivative_limit,
            self.args.derivative_limit)

        d_alpha = 1.0 - math.exp(
            -dt / max(self.args.derivative_filter_tau, 1e-3))
        self.derivative += d_alpha * (raw_derivative - self.derivative)

        predicted = (
            self.filtered_error +
            self.args.turn_lookahead * self.derivative)

        pd = (
            self.args.turn_kp * self.filtered_error +
            self.args.turn_kd * self.derivative)

        self.pd_output = clamp(pd, -1.0, 1.0)

        if self.turn_active:
            if abs(predicted) <= self.args.turn_exit:
                self.turn_active = False
        elif max(abs(self.filtered_error), abs(predicted)) >= self.args.turn_enter:
            self.turn_active = True

        return predicted

    def _distance_pwm(self, distance_m):
        if distance_m is None or not math.isfinite(float(distance_m)):
            return 0.0

        if self.filtered_distance is None:
            self.filtered_distance = float(distance_m)

        error = self.filtered_distance - self.args.target_distance

        if self.distance_active:
            if abs(error) <= self.args.distance_deadband:
                self.distance_active = False
        elif abs(error) >= (
            self.args.distance_deadband + self.args.distance_hysteresis):
            self.distance_active = True

        if not self.distance_active:
            return 0.0

        ratio = clamp(
            (abs(error) - self.args.distance_deadband) /
            max(self.args.distance_full_scale -
                self.args.distance_deadband, 1e-6),
            0.0, 1.0)

        ratio = math.sqrt(ratio)

        if error > 0:
            return (
                self.args.forward_min +
                ratio * (self.args.forward_max - self.args.forward_min))

        return -(
            self.args.reverse_min +
            ratio * (self.args.reverse_max - self.args.reverse_min))

    def compute(self, raw_error, distance_m, feedback, dt):
        dt = clamp(float(dt), 0.02, 0.30)
        self.fault = None

        self.v_meas_left = float(feedback["vL"])
        self.v_meas_right = float(feedback["vR"])

        self._update_pd(clamp(float(raw_error), -1.0, 1.0), dt)

        if distance_m is not None and math.isfinite(float(distance_m)):
            if self.filtered_distance is None:
                self.filtered_distance = float(distance_m)
            else:
                alpha = 1.0 - math.exp(
                    -dt / max(self.args.distance_filter_tau, 1e-3))
                self.filtered_distance += alpha * (
                    float(distance_m) - self.filtered_distance)

        self.band_index = self._band(abs(self.pd_output))
        error = self.filtered_error
        direction = 1 if error >= 0 else -1
        turn_fraction = clamp((abs(error) - self.args.turn_exit) /
                              (1.0 - self.args.turn_exit), 0.0, 1.0)
        turn_pwm = self.args.turn_min + turn_fraction * (self.args.turn_max - self.args.turn_min)

        if self.args.drive_mode == "rotate":
            if self.turn_active and abs(self.pd_output) > 0.025:
                raw_left = direction * turn_pwm
                raw_right = -direction * turn_pwm
                self.mode = "ROTATE"
            else:
                raw_left = raw_right = 0.0
                self.mode = (
                    "ROTATE-BRAKE" if self.turn_active else "CENTERED")
        else:
            base = self._distance_pwm(distance_m)
            raw_left = raw_right = base
            self.mode = "HOLD"
            if base > 0:
                error = self.filtered_error
                deadband = self.args.straight_deadband
                ratio = clamp((abs(error) - deadband) / (0.50 - deadband), 0.0, 1.0)
                drop = self.args.arc_drop_max * ratio
                if error > 0:
                    raw_right = max(0.0, raw_right - drop)
                else:
                    raw_left = max(0.0, raw_left - drop)
                self.mode = "ARC" if drop > 0 else "STRAIGHT"

            elif base < 0:
                self.mode = "REVERSE"
            elif self.turn_active and abs(error) > self.args.straight_deadband:
                raw_left, raw_right = direction * turn_pwm, -direction * turn_pwm
                self.mode = "ALIGN"

        self.target_left = clamp(raw_left, -self.pwm_limit, self.pwm_limit)
        self.target_right = clamp(raw_right, -self.pwm_limit, self.pwm_limit)

        self.v_ref_left = self.left_pi.speed_reference(self.target_left)
        self.v_ref_right = self.right_pi.speed_reference(self.target_right)

        for side, target_pwm, measured in (
            ("left", self.target_left, self.v_meas_left),
            ("right", self.target_right, self.v_meas_right),
        ):
            if abs(target_pwm) >= self.args.encoder_guard_pwm:
                along = (1 if target_pwm > 0 else -1) * measured

                if along < -self.args.reverse_speed_guard:
                    attr = "reverse_time_" + side
                    setattr(self, attr, getattr(self, attr) + dt)
                else:
                    setattr(
                        self, "reverse_time_" + side,
                        max(0.0, getattr(self, "reverse_time_" + side) - 2*dt))

                if abs(measured) < self.args.stall_speed_guard:
                    attr = "stall_time_" + side
                    setattr(self, attr, getattr(self, attr) + dt)
                else:
                    setattr(self, "stall_time_" + side, 0.0)
            else:
                setattr(self, "reverse_time_" + side, 0.0)
                setattr(self, "stall_time_" + side, 0.0)

        if self.reverse_time_left >= self.args.reverse_confirm_s:
            self.fault = "ENCODER_REVERSE_LEFT"
        elif self.reverse_time_right >= self.args.reverse_confirm_s:
            self.fault = "ENCODER_REVERSE_RIGHT"
        elif self.stall_time_left >= self.args.stall_confirm_s:
            self.fault = "ENCODER_STALL_LEFT"
        elif self.stall_time_right >= self.args.stall_confirm_s:
            self.fault = "ENCODER_STALL_RIGHT"

        if self.fault:
            self.applied_left = self.applied_right = 0
            return 0, 0

        pi_left = self.left_pi.update(
            self.target_left, self.v_meas_left, dt)
        pi_right = self.right_pi.update(
            self.target_right, self.v_meas_right, dt)

        self.applied_left = int(round(
            self.left_scurve.update(pi_left, dt)))
        self.applied_right = int(round(
            self.right_scurve.update(pi_right, dt)))

        return self.applied_left, self.applied_right