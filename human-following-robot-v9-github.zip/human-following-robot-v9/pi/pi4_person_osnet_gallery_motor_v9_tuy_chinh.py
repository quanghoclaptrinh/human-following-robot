#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Motor-control runner for pi4_person_osnet_gallery_no_motor.py.

Keep this file beside ``pi4_person_osnet_gallery_no_motor.py`` on Raspberry Pi.
It reuses the tested YOLO/ByteTrack/OSNet gallery pipeline and adds a conservative
USB-serial motor layer for the ESP32 signed-PWM protocol:

    M,<left>,<right>\n   signed wheel commands, range -200..200
    S\n                  immediate stop

Safety and follow behavior:
* Motors start DISARMED. Calibrate person distance before pressing R.
* S disarms immediately. Target/camera loss while armed sends M,0,0 (both wheels
  stopped while ESP32 remote mode stays armed); hard faults and exit send S.
* Hybrid mode drives straight when centred, arcs for normal horizontal error, and
  rotates in place only for a large horizontal error.
* A dedicated 25 Hz worker applies the S-curve independently of camera/Re-ID FPS.
"""
from __future__ import annotations

import argparse
import time
import threading
from collections import deque

import cv2
import numpy as np

import pi4_person_osnet_gallery_no_motor as vision
from ddmr_v9_control_tuy_chinh import FollowController, clamp, parse_encoder_telemetry_line


WINDOW = "PI4 V9.1 STRAIGHT + ARC PERSON FOLLOW / ENCODER CLOSED"
COMMAND_LIMIT = 120
SERIAL_KEEPALIVE_S = 0.20
SERIAL_RECONNECT_S = 1.0


def parse_pwm_bands(value):
    try:
        values = [int(part.strip()) for part in str(value).split(",")]
    except Exception as exc:
        raise argparse.ArgumentTypeError("PWM bands must be 7 comma-separated integers") from exc
    if len(values) != 7:
        raise argparse.ArgumentTypeError("PWM bands must contain exactly 7 values")
    return values


def parse_speed_bands(value):
    try:
        values = [float(part.strip()) for part in str(value).split(",")]
    except Exception as exc:
        raise argparse.ArgumentTypeError("Speed bands must be 7 comma-separated m/s values") from exc
    if len(values) != 7:
        raise argparse.ArgumentTypeError("Speed bands must contain exactly 7 values")
    return values


class MotorSerial:
    """V8-compatible M,left,right / S command link plus V9 encoder telemetry."""

    def __init__(self, port, baud, invert_left=False, invert_right=False, pwm_limit=55):
        self.pwm_limit = pwm_limit
        self.port = None if not port or str(port).lower() == "none" else str(port)
        self.baud = int(baud)
        self.invert_left = bool(invert_left)
        self.invert_right = bool(invert_right)
        self.serial_module = None
        self.connection = None
        self.last_packet = None
        self.last_send = 0.0
        self.last_connect_attempt = 0.0
        self.rx_buffer = bytearray()
        self.telemetry = None
        self.last_telemetry_at = 0.0
        self.telemetry_lock = threading.Lock()

        if self.port is None:
            print("[SERIAL] Disabled (--serial none). Vision-only until a port is supplied.")
            return
        try:
            import serial
        except Exception as exc:
            raise RuntimeError(
                "Motor mode requires pyserial: source .venv/bin/activate && pip install pyserial"
            ) from exc
        self.serial_module = serial
        self.connect(force=True)

    @property
    def connected(self):
        return self.connection is not None and self.connection.is_open

    @property
    def telemetry_age(self):
        with self.telemetry_lock:
            received = self.last_telemetry_at
        if received <= 0.0:
            return float("inf")
        return max(0.0, time.monotonic() - received)

    def telemetry_snapshot(self):
        with self.telemetry_lock:
            return None if self.telemetry is None else dict(self.telemetry)

    def telemetry_valid(self, timeout_s=0.60):
        with self.telemetry_lock:
            present = self.telemetry is not None
            received = self.last_telemetry_at
        return (self.connected and present and received > 0.0 and
                (time.monotonic() - received) <= timeout_s)

    def connect(self, force=False):
        if self.port is None or self.connected:
            return self.connected
        now = time.monotonic()
        if not force and now - self.last_connect_attempt < SERIAL_RECONNECT_S:
            return False
        self.last_connect_attempt = now
        try:
            self.connection = self.serial_module.Serial(
                self.port, self.baud, timeout=0, write_timeout=0.15
            )
            # Opening USB serial commonly resets ESP32. Motors remain OFF at boot.
            time.sleep(1.8)
            self.connection.reset_input_buffer()
            self.rx_buffer.clear()
            with self.telemetry_lock:
                self.telemetry = None
                self.last_telemetry_at = 0.0
            self.connection.write(b"S\n")
            self.connection.flush()
            self.last_packet = "S"
            self.last_send = time.monotonic()
            print(f"[SERIAL] Connected: {self.port} @ {self.baud}; STOP sent; waiting for E telemetry")
            return True
        except Exception as exc:
            self.connection = None
            print(f"[SERIAL] Waiting for {self.port}: {exc}")
            return False

    def poll_telemetry(self):
        if not self.connected:
            return False
        try:
            waiting = int(self.connection.in_waiting)
            if waiting <= 0:
                return False
            self.rx_buffer.extend(self.connection.read(waiting))
            updated = False
            while b"\n" in self.rx_buffer:
                raw, _, remainder = self.rx_buffer.partition(b"\n")
                self.rx_buffer = bytearray(remainder)
                line = raw.decode("ascii", errors="ignore").strip().rstrip("\r")
                item = parse_encoder_telemetry_line(line)
                if item is None:
                    continue
                with self.telemetry_lock:
                    self.telemetry = item
                    self.last_telemetry_at = time.monotonic()
                updated = True
            # Prevent a malformed/unbounded line from growing the buffer forever.
            if len(self.rx_buffer) > 512:
                self.rx_buffer.clear()
            return updated
        except Exception as exc:
            print(f"[SERIAL] Telemetry read failed: {exc}")
            try:
                self.connection.close()
            except Exception:
                pass
            self.connection = None
            self.last_packet = None
            with self.telemetry_lock:
                self.telemetry = None
                self.last_telemetry_at = 0.0
            return False

    def _write(self, packet, force=False):
        if self.port is None:
            return False
        if not self.connected and not self.connect():
            return False
        now = time.monotonic()
        if not force and packet == self.last_packet and now - self.last_send < SERIAL_KEEPALIVE_S:
            return True
        try:
            self.connection.write((packet + "\n").encode("ascii"))
            self.connection.flush()
            self.last_packet = packet
            self.last_send = now
            return True
        except Exception as exc:
            print(f"[SERIAL] Disconnected while sending; motor command cancelled: {exc}")
            try:
                self.connection.close()
            except Exception:
                pass
            self.connection = None
            self.last_packet = None
            with self.telemetry_lock:
                self.telemetry = None
                self.last_telemetry_at = 0.0
            return False

    def motor(self, left, right):
        left = int(clamp(round(left), -self.pwm_limit, self.pwm_limit))
        right = int(clamp(round(right), -self.pwm_limit, self.pwm_limit))
        if self.invert_left:
            left = -left
        if self.invert_right:
            right = -right
        return self._write(f"M,{left},{right}")

    def stop(self, immediate=True):
        if self.connected and self.last_packet == "S":
            return True
        return self._write("S", force=immediate)

    def close(self):
        self.stop(immediate=True)
        if self.connected:
            try:
                self.connection.close()
            except Exception:
                pass
        self.connection = None


class MotorControlWorker:
    """Independent 25 Hz motor/encoder loop, decoupled from camera FPS."""

    def __init__(self, motor, args):
        self.motor = motor
        self.args = args
        self.controller = FollowController(args)
        self.period_s = 0.04
        self.lock = threading.Lock()
        self.armed = False
        self.target = None
        self.target_updated_at = 0.0
        self.reset_pending = False
        self.fault = None
        self.stop_event = threading.Event()
        self.state = {
            "left": 0, "right": 0, "requested_left": 0, "requested_right": 0,
            "mode": "STOP", "band": 0, "pd": 0.0, "error": 0.0,
            "target_left": 0.0, "target_right": 0.0,
            "v_ref_left": 0.0, "v_ref_right": 0.0,
            "v_meas_left": 0.0, "v_meas_right": 0.0,
            "telemetry_age": float("inf"), "fault": None,
        }
        self.thread = threading.Thread(target=self._run, name="ddmr-v9-motor-loop", daemon=True)
        self.thread.start()

    def arm(self):
        # The worker owns serial reconnects; the UI thread never opens a second
        # handle to the same COM/tty device.
        if not self.motor.connected or not self.motor.telemetry_valid(self.args.telemetry_timeout):
            return False
        with self.lock:
            self.armed = True
            self.target = None
            self.target_updated_at = time.monotonic()
            self.reset_pending = True
            self.fault = None
        return True

    def set_target(self, error_x, distance_m):
        with self.lock:
            self.target = (float(error_x), None if distance_m is None else float(distance_m))
            self.target_updated_at = time.monotonic()

    def hold_stop(self):
        with self.lock:
            self.target = None
            self.target_updated_at = time.monotonic()
            self.reset_pending = True

    def disarm(self):
        with self.lock:
            self.armed = False
            self.target = None
            self.target_updated_at = time.monotonic()
            self.reset_pending = True

    def consume_fault(self):
        with self.lock:
            fault = self.fault
            self.fault = None
            return fault

    def snapshot(self):
        with self.lock:
            state = dict(self.state)
        state["telemetry_age"] = self.motor.telemetry_age
        return state

    def _publish(self, **values):
        with self.lock:
            self.state.update(values)

    def _trip(self, reason):
        with self.lock:
            self.armed = False
            self.target = None
            self.fault = reason
            self.reset_pending = True
            self.state["fault"] = reason
            self.state["mode"] = "FAULT"
            self.state["left"] = self.state["right"] = 0
            self.state["requested_left"] = self.state["requested_right"] = 0
            self.state["target_left"] = self.state["target_right"] = 0.0
        self.motor.stop(immediate=True)

    def _run(self):
        previous = time.monotonic()
        while not self.stop_event.is_set():
            tick_start = time.monotonic()
            self.motor.poll_telemetry()
            with self.lock:
                armed = self.armed
                target = self.target
                target_age = tick_start - self.target_updated_at
                reset = self.reset_pending
                self.reset_pending = False
            if reset:
                self.controller.reset()

            if armed and target is not None:
                if target_age > self.args.vision_timeout:
                    # A stale/missing vision setpoint is treated as temporary target loss:
                    # stop both wheels, clear the old setpoint, but KEEP the motor system
                    # armed. When the selected target is reacquired, set_target() resumes
                    # following without requiring another R key press.
                    self.hold_stop()
                    self.controller.reset()
                    if not self.motor.motor(0, 0):
                        self._trip("SERIAL_WRITE_FAILED_WHILE_HOLDING")
                    else:
                        self._publish(
                            left=0, right=0, requested_left=0, requested_right=0,
                            target_left=0.0, target_right=0.0,
                            v_ref_left=0.0, v_ref_right=0.0,
                            mode="WAIT_TARGET", fault=None,
                        )
                elif not self.motor.telemetry_valid(self.args.telemetry_timeout):
                    self._trip("ENCODER_TELEMETRY_STALE")
                else:
                    feedback = self.motor.telemetry_snapshot()
                    if feedback is None:
                        self._trip("ENCODER_TELEMETRY_MISSING")
                        previous = tick_start
                        elapsed = time.monotonic() - tick_start
                        self.stop_event.wait(max(0.0, self.period_s - elapsed))
                        continue
                    dt = clamp(tick_start - previous, 0.02, 0.12)
                    error_x, distance_m = target
                    left, right = self.controller.compute(error_x, distance_m, feedback, dt)
                    if self.controller.fault:
                        self._trip(self.controller.fault)
                    elif not self.motor.motor(left, right):
                        self._trip("SERIAL_WRITE_FAILED")
                    else:
                        self._publish(
                            left=left, right=right,
                            requested_left=int(round(self.controller.target_left)),
                            requested_right=int(round(self.controller.target_right)),
                            mode=self.controller.mode,
                            band=self.controller.band_index + 1,
                            pd=self.controller.pd_output,
                            error=self.controller.filtered_error,
                            target_left=self.controller.target_left,
                            target_right=self.controller.target_right,
                            v_ref_left=self.controller.v_ref_left,
                            v_ref_right=self.controller.v_ref_right,
                            v_meas_left=self.controller.v_meas_left,
                            v_meas_right=self.controller.v_meas_right,
                            telemetry_age=self.motor.telemetry_age,
                            fault=None,
                        )
            else:
                # Protocol distinction:
                # M,0,0 = stop wheels but keep ESP32 remote mode armed.
                # S      = emergency stop and disarm remote mode.
                if armed:
                    if not self.motor.motor(0, 0):
                        self._trip("SERIAL_WRITE_FAILED_WHILE_WAITING")
                    else:
                        self._publish(
                            left=0, right=0, requested_left=0, requested_right=0,
                            target_left=0.0, target_right=0.0,
                            v_ref_left=0.0, v_ref_right=0.0,
                            mode="WAIT_TARGET",
                        )
                else:
                    self.motor.stop(immediate=True)
                    self._publish(
                        left=0, right=0, requested_left=0, requested_right=0,
                        target_left=0.0, target_right=0.0,
                        v_ref_left=0.0, v_ref_right=0.0,
                        mode="STOP",
                    )

            previous = tick_start
            elapsed = time.monotonic() - tick_start
            self.stop_event.wait(max(0.0, self.period_s - elapsed))

    def close(self):
        self.disarm()
        self.stop_event.set()
        if self.thread.is_alive():
            self.thread.join(timeout=3.0)
        self.motor.stop(immediate=True)


class App(vision.App):
    def __init__(self, args):
        # Base App uses its module-level window name for callbacks and display.
        vision.WINDOW = WINDOW
        super().__init__(args)
        self.motor = MotorSerial(args.serial, args.baud, args.invert_left, args.invert_right, args.pwm_limit)
        self.worker = MotorControlWorker(self.motor, args)
        self.controller = self.worker.controller
        self.armed = False
        self.left_command = 0
        self.right_command = 0
        self.horizontal_error = 0.0
        self.last_control_time = time.monotonic()
        print("[SAFETY] Motors DISARMED. Press R once to arm. Target loss stops wheels but keeps ARMED; reacquisition resumes automatically. S stops/disarms.")

    def safe_stop(self, reason=None, disarm=False):
        self.left_command = self.right_command = 0
        self.horizontal_error = 0.0
        self.last_control_time = time.monotonic()
        if disarm:
            self.worker.disarm()
            self.armed = False
        else:
            self.worker.hold_stop()
        if reason:
            print("[STOP]", reason)

    def on_mouse(self, event, x, y, flags, userdata):
        if event != cv2.EVENT_LBUTTONDOWN or self.show_frame is None:
            return
        for box in self.show_boxes:
            x1, y1, x2, y2 = map(float, box)
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.safe_stop("Enrolling selected person; wheels stopped, ARM retained")
                super().on_mouse(event, x, y, flags, userdata)
                return

    def draw(self, frame, boxes, ids, target, status, dist, dist_info, fps):
        h, w = frame.shape[:2]
        cv2.line(frame, (w // 2, 0), (w // 2, h), (255, 180, 0), 1)
        enter = int(self.args.turn_enter * w * 0.5)
        exit_ = int(self.args.turn_exit * w * 0.5)
        for dx, color in ((enter, (0, 150, 255)), (exit_, (0, 220, 220))):
            cv2.line(frame, (w // 2 - dx, 0), (w // 2 - dx, h), color, 1)
            cv2.line(frame, (w // 2 + dx, 0), (w // 2 + dx, h), color, 1)

        tracked_id = self.manager.id
        for box, tid in zip(boxes, ids):
            x1, y1, x2, y2 = map(int, box)
            is_target = tracked_id is not None and int(tid) == tracked_id and target is not None
            is_enroll = self.manager.enroll_id is not None and int(tid) == self.manager.enroll_id
            color = (30, 230, 30) if is_target else ((30, 180, 240) if is_enroll else (180, 180, 180))
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(frame, f"ID {int(tid)}", (x1, max(15, y1 - 6)),
                        cv2.FONT_HERSHEY_SIMPLEX, .5, color, 1)

        serial_state = "CONNECTED" if self.motor.connected else (
            "OFF" if self.motor.port is None else "WAITING"
        )
        arm_state = "ARMED" if self.armed else "DISARMED"
        snapshot = self.worker.snapshot()
        telemetry = self.motor.telemetry_snapshot()
        self.left_command, self.right_command = snapshot["left"], snapshot["right"]
        encoder_line = (f"ENC L={snapshot['v_meas_left']:+.3f} R={snapshot['v_meas_right']:+.3f} m/s | age={self.motor.telemetry_age:.2f}s"
                        if telemetry is not None else "ENCODER: NO TELEMETRY")
        textlines = [
            f"NCNN+ByteTrack | ReID={self.reid.name.upper()} | FPS {fps:.1f}",
            f"{status}",
            f"MOTOR {arm_state} | SERIAL {serial_state} | MODE {snapshot['mode']}",
            f"PWM L={self.left_command:+d} R={self.right_command:+d} | X={self.horizontal_error:+.3f} | BAND {snapshot['band']}/7",
            encoder_line,
            f"VREF L={snapshot['v_ref_left']:+.3f} R={snapshot['v_ref_right']:+.3f} m/s",
            f"PD={snapshot['pd']:+.3f} | target PWM={snapshot['target_left']:+.0f},{snapshot['target_right']:+.0f}",
            f"ReID: {self.manager.last_score:.3f}" if self.manager.last_score is not None else "ReID: --",
            (f"Distance: {dist:.2f} m ({dist_info})" if dist is not None
             else f"Distance: -- ({dist_info})"),
            "C: calibrate distance first | R: ARM | S: DISARM | Loss: M,0,0 hold | U: unlock | Q: quit",
        ]
        for i, msg in enumerate(textlines):
            y = 23 + i * 22
            cv2.rectangle(frame, (0, y - 19), (min(w, 680), y + 4), (12, 12, 12), -1)
            color = (80, 255, 80) if i == 2 and self.armed else (240, 240, 240)
            cv2.putText(frame, msg[:100], (7, y), cv2.FONT_HERSHEY_SIMPLEX,
                        .47, color, 1, cv2.LINE_AA)

        if target is not None:
            cx, cy = vision.box_center(target)
            cv2.circle(frame, (int(cx), int(cy)), 7, (0, 255, 0), 2)

    def run(self):
        print("[READY] Click target -> wait GALLERY READY -> stand at known distance and press C -> wait CALIB OK -> press R once. Centered target + distance above setpoint = straight forward.")
        try:
            while True:
                t0 = time.perf_counter()
                ok, frame = self.cap.read()
                t1 = time.perf_counter()
                if not ok or frame is None:
                    # A temporary camera-frame drop is a vision interruption, not an
                    # operator disarm request. Stop the wheels but retain the ARM latch
                    # so tracking can resume automatically when frames return.
                    self.safe_stop(disarm=False)
                    now = time.monotonic()
                    if now - getattr(self, "last_camera_warning", 0.0) >= 2.0:
                        print("[VISION] Camera frame unavailable; motors STOPPED, ARM retained; waiting for camera.")
                        self.last_camera_warning = now

                    # Keep keyboard emergency controls responsive even while the
                    # camera is temporarily unavailable.
                    key = cv2.waitKey(1) & 255
                    if key in (ord("q"), 27):
                        break
                    elif key == ord("s"):
                        self.safe_stop("Emergency stop / disarmed", disarm=True)
                    elif key == ord("u"):
                        self.safe_stop("Target unlocked", disarm=True)
                        self.manager.reset()
                        self.distance.reset()

                    time.sleep(.05)
                    continue
                if self.args.flip == "horizontal":
                    frame = cv2.flip(frame, 1)
                elif self.args.flip == "vertical":
                    frame = cv2.flip(frame, 0)
                elif self.args.flip == "both":
                    frame = cv2.flip(frame, -1)
                # Keep the camera frame read-only; copy only when drawing the UI.
                clean = frame

                result = self.detector.track(
                    frame, persist=True, tracker="bytetrack.yaml", classes=[0],
                    conf=self.args.conf, imgsz=self.args.imgsz, verbose=False
                )[0]
                t2 = time.perf_counter()
                if result.boxes is not None and result.boxes.id is not None:
                    boxes = result.boxes.xyxy.cpu().numpy().astype(np.float32)
                    ids = result.boxes.id.cpu().numpy().astype(np.int32)
                    confidences = (result.boxes.conf.cpu().numpy().astype(np.float32)
                                   if result.boxes.conf is not None else None)
                else:
                    boxes = np.empty((0, 4), dtype=np.float32)
                    ids = np.empty((0,), dtype=np.int32)
                    confidences = np.empty((0,), dtype=np.float32)

                target, status = self.manager.update(clean, boxes, ids, confidences)
                if target is None:
                    self.distance.invalidate()
                    distance_m, distance_info = None, "TARGET NOT CONFIRMED"
                    self.safe_stop(disarm=False)
                else:
                    distance_m, distance_info = self.distance.update(target, clean.shape)
                    if self.distance.collecting is not None:
                        self.safe_stop(disarm=False)
                        status += " | CALIBRATING: STOP"
                    elif self.args.drive_mode == "hybrid" and distance_m is None:
                        self.safe_stop(disarm=False)
                        status += " | WAIT VALID DISTANCE: STOP"
                    elif self.armed:
                        cx, _ = vision.box_center(target)
                        frame_w = max(clean.shape[1] * 0.5, 1.0)
                        err = float(clamp((cx - clean.shape[1] * 0.5) / frame_w, -1.0, 1.0))
                        self.horizontal_error = err
                        # Reverse steering for this camera orientation; keep distance unchanged.
                        self.worker.set_target(-err, distance_m)
                    else:
                        self.safe_stop(disarm=False)

                worker_fault = self.worker.consume_fault()
                if worker_fault:
                    self.armed = False
                    status += f" | MOTOR LOOP: {worker_fault}"
                    print("[SAFETY] Motor worker disarmed:", worker_fault)
                snapshot = self.worker.snapshot()
                self.left_command, self.right_command = snapshot["left"], snapshot["right"]
                t3 = time.perf_counter()
                self.frame_number += 1
                self.frametimes.append(t0)
                fps = ((len(self.frametimes) - 1) /
                       (self.frametimes[-1] - self.frametimes[0])
                       if len(self.frametimes) > 1 else 0.)
                if self.frame_number % self.args.display_every == 0:
                    self.show_frame = clean
                    self.show_boxes = boxes.copy()
                    self.show_ids = ids.copy()
                    display_frame = clean.copy()
                    self.draw(display_frame, boxes, ids, target, status,
                              distance_m, distance_info, fps)
                    cv2.imshow(WINDOW, display_frame)

                key = cv2.waitKey(1) & 255
                t4 = time.perf_counter()
                self.profile_n += 1
                rid, pose = self.manager.reid_seconds, self.manager.pose_seconds
                self.profile_sum += np.array([
                    t1 - t0, t2 - t1, rid, pose,
                    max(0., t3 - t2 - rid - pose), t4 - t3
                ])
                if t4 - self.profile_start >= self.args.profile_interval:
                    avg = 1000 * self.profile_sum / max(1, self.profile_n)
                    real_fps = self.profile_n / (t4 - self.profile_start)
                    print(f"[PROFILE] FPS_REAL={real_fps:.2f} CAMERA={avg[0]:.1f}ms "
                          f"YOLO_TRACK={avg[1]:.1f}ms REID={avg[2]:.1f}ms "
                          f"POSE={avg[3]:.1f}ms ETC={avg[4]:.1f}ms DISPLAY={avg[5]:.1f}ms "
                          f"PWM={self.left_command:+d},{self.right_command:+d}")
                    self.profile_n = 0
                    self.profile_sum[:] = 0
                    self.profile_start = t4

                if key in (ord("q"), 27):
                    break
                if key == ord("r"):
                    if self.motor.port is None:
                        print("[SAFETY] Cannot arm: use --serial /dev/ttyUSB0 or /dev/ttyACM0")
                    elif not getattr(self.distance, "points", {}):
                        print("[SAFETY] ARM BLOCKED: distance is not calibrated. Keep the selected person at a known distance (e.g. 1.5 m), press C, wait for [CALIB] OK, then press R.")
                    elif distance_m is None:
                        print(f"[SAFETY] ARM BLOCKED: current distance is invalid ({distance_info}). Re-centre the person in frame and wait for a valid distance.")
                    elif self.worker.arm():
                        self.armed = True
                        self.last_control_time = time.monotonic()
                        print(f"[SAFETY] ARMED in {self.args.drive_mode.upper()} mode. Centered target and distance > {self.args.target_distance:.2f} m + deadband will drive straight.")
                    else:
                        print("[SAFETY] Cannot arm: V9 ESP32 encoder telemetry E,... is missing or stale. Flash the V9 ESP32 firmware first.")
                elif key == ord("s"):
                    self.safe_stop("Emergency stop / disarmed", disarm=True)
                elif key == ord("u"):
                    self.safe_stop("Target unlocked", disarm=True)
                    self.manager.reset()
                    self.distance.reset()
                elif key in (ord("c"), ord("1"), ord("2"), ord("3"), ord("4")):
                    distances = {
                        ord("c"): self.args.calib_distance,
                        ord("1"): 1.0,
                        ord("2"): 1.5,
                        ord("3"): 2.0,
                        ord("4"): 2.5,
                    }
                    if target is None:
                        print("[CALIB] Must have CONFIRMED target first.")
                    else:
                        self.safe_stop("Distance calibration; wheels stopped, ARM retained")
                        self.distance.start(distances[key])
        finally:
            self.safe_stop("Program exit", disarm=True)
            self.worker.close()
            self.motor.close()
            self.cap.release()
            cv2.destroyAllWindows()
        return 0


def build_parser():
    parser = vision.build_parser()
    parser.description = "Pi4 V8 YOLO NCNN + ByteTrack + OSNet gallery with DDMR V9 7-band PD/S-curve encoder-closed control"
    parser.add_argument("--serial", default="none",
                        help="V9 ESP32 port, e.g. /dev/ttyUSB0; no motor without encoder telemetry")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--drive-mode", choices=["hybrid", "follow", "rotate"], default="hybrid",
                        help="hybrid: rotate for large X error, arc near centre; rotate: rotation only")
    parser.add_argument("--invert-left", action=argparse.BooleanOptionalAction, default=False,
                        help="Invert left motor output if needed")
    parser.add_argument("--invert-right", action=argparse.BooleanOptionalAction, default=False,
                        help="Invert right motor output if needed")

    parser.add_argument("--pwm-bands-left", type=parse_pwm_bands,
                        default=[60, 65, 70, 78, 86, 96, 110],
                        help="7 left-wheel PWM bands, comma-separated, ascending, 0..120")
    parser.add_argument("--pwm-bands-right", type=parse_pwm_bands,
                        default=[60, 65, 70, 78, 86, 96, 110],
                        help="7 right-wheel PWM bands, comma-separated, ascending, 0..120")
    parser.add_argument("--turn-enter", "--rotate-first", type=float, default=0.20)
    parser.add_argument("--turn-exit", type=float, default=0.10)
    parser.add_argument("--straight-deadband", type=float, default=0.05,
                        help="normalized horizontal error within which both wheels drive equally")
    parser.add_argument("--turn-kp", type=float, default=0.55)
    parser.add_argument("--turn-kd", type=float, default=0.10)
    parser.add_argument("--turn-lookahead", type=float, default=0.15)
    parser.add_argument("--error-filter-tau", type=float, default=0.20)
    parser.add_argument("--derivative-filter-tau", type=float, default=0.14)
    parser.add_argument("--derivative-limit", type=float, default=1.50)

    parser.add_argument("--target-distance", type=float, default=1.5)
    parser.add_argument("--distance-deadband", type=float, default=0.18)
    parser.add_argument("--distance-hysteresis", type=float, default=0.05)
    parser.add_argument("--distance-full-scale", type=float, default=1.0)
    parser.add_argument("--distance-filter-tau", type=float, default=0.28)
    parser.add_argument("--pwm-limit", type=int, default=55)
    parser.add_argument("--turn-min", type=int, default=55)
    parser.add_argument("--turn-max", type=int, default=55)
    parser.add_argument("--forward-min", type=int, default=55)
    parser.add_argument("--forward-max", type=int, default=55)
    parser.add_argument("--arc-drop-max", "--arc-delta", type=float, default=5.0)
    parser.add_argument("--reverse-min", type=int, default=0)
    parser.add_argument("--reverse-max", type=int, default=0)

    parser.add_argument("--speed-bands-left", type=parse_speed_bands, default=None,
                        help="7 calibrated left-wheel speeds (m/s) at the left PWM band values")
    parser.add_argument("--speed-bands-right", type=parse_speed_bands, default=None,
                        help="7 calibrated right-wheel speeds (m/s) at the right PWM band values")
    parser.add_argument("--mps-per-pwm-left", type=float, default=0.0010,
                        help="fallback provisional left speed/PWM slope used when no 7-point map is supplied")
    parser.add_argument("--mps-per-pwm-right", type=float, default=0.0010,
                        help="fallback provisional right speed/PWM slope used when no 7-point map is supplied")
    parser.add_argument("--encoder-kp", type=float, default=260.0,
                        help="encoder PI proportional gain, PWM per (m/s)")
    parser.add_argument("--encoder-ki", type=float, default=75.0,
                        help="encoder PI integral gain, PWM per ((m/s)*s)")
    parser.add_argument("--telemetry-timeout", type=float, default=0.60,
                        help="stop/disarm if no fresh ESP32 E telemetry for this many seconds")
    parser.add_argument("--vision-timeout", type=float, default=1.0,
                        help="stop/disarm if the camera/Re-ID loop stops refreshing the motor setpoint")
    parser.add_argument("--encoder-guard-pwm", type=int, default=50)
    parser.add_argument("--reverse-speed-guard", type=float, default=0.025)
    parser.add_argument("--reverse-confirm-s", type=float, default=0.25)
    parser.add_argument("--stall-speed-guard", type=float, default=0.003)
    parser.add_argument("--stall-confirm-s", type=float, default=0.90)
    return parser


def validate_args(args):
    if args.drive_mode == "follow":
        args.drive_mode = "hybrid"
    if not 1 <= args.pwm_limit <= COMMAND_LIMIT:
        raise SystemExit("--pwm-limit must be in 1..120")
    if not 0 <= args.turn_min <= args.turn_max <= args.pwm_limit:
        raise SystemExit("Require 0 <= turn-min <= turn-max <= pwm-limit")
    if not 0 <= args.arc_drop_max <= 30 or args.straight_deadband >= 0.50:
        raise SystemExit("Require arc-drop-max in 0..30 and straight-deadband < 0.50")
    if args.imgsz < 160 or args.imgsz % 32:
        raise SystemExit("--imgsz must be >=160 and divisible by 32")
    if min(args.display_every, args.reid_threads, args.reid_every,
           args.reacquire_every, args.max_candidates, args.pose_every,
           args.reid_min_height, args.reid_min_width) < 1:
        raise SystemExit("display, inference intervals, threads and crop dimensions must be >=1")
    if not (0.0 <= args.reid_min_conf <= 1.0) or args.min_blur_score < 0:
        raise SystemExit("Re-ID confidence must be 0..1 and blur threshold must be >=0")
    if not (0.0 <= args.turn_exit < args.turn_enter < 1.0):
        raise SystemExit("Require 0 <= turn-exit < turn-enter < 1")
    if not (0.0 <= args.straight_deadband < args.turn_exit):
        raise SystemExit("Require 0 <= straight-deadband < turn-exit")
    if args.turn_kp <= 0 or args.turn_kd < 0 or args.turn_lookahead < 0:
        raise SystemExit("PD gains/lookahead are invalid")
    if args.error_filter_tau <= 0 or args.derivative_filter_tau <= 0 or args.derivative_limit <= 0:
        raise SystemExit("Filter time constants and derivative limit must be positive")
    for name, values in (("left", args.pwm_bands_left), ("right", args.pwm_bands_right)):
        if len(values) != 7 or any(v < 1 or v > 120 for v in values):
            raise SystemExit(f"{name} PWM table must contain 7 values in 1..120")
        if any(values[i] >= values[i + 1] for i in range(6)):
            raise SystemExit(f"{name} PWM bands must be strictly ascending")
    if args.mps_per_pwm_left <= 0 or args.mps_per_pwm_right <= 0:
        raise SystemExit("Fallback speed-per-PWM values must be positive")
    if args.speed_bands_left is None:
        args.speed_bands_left = [v * args.mps_per_pwm_left for v in args.pwm_bands_left]
    if args.speed_bands_right is None:
        args.speed_bands_right = [v * args.mps_per_pwm_right for v in args.pwm_bands_right]
    for name, values in (("left", args.speed_bands_left), ("right", args.speed_bands_right)):
        if len(values) != 7 or any(not np.isfinite(v) or v <= 0 for v in values):
            raise SystemExit(f"{name} speed map must contain 7 positive finite m/s values")
        if any(values[i] > values[i + 1] for i in range(6)):
            raise SystemExit(f"{name} speed map must be ascending")
    pwm_values = [args.forward_min, args.forward_max, args.reverse_min, args.reverse_max]
    if any(v < 0 or v > args.pwm_limit for v in pwm_values):
        raise SystemExit("Forward/reverse PWM settings must be in 0..pwm-limit")
    if args.forward_min > args.forward_max or args.reverse_min > args.reverse_max:
        raise SystemExit("Each forward/reverse PWM minimum must be <= its maximum")
    if args.target_distance <= 0 or args.distance_deadband < 0 or args.distance_hysteresis < 0:
        raise SystemExit("Target distance must be positive and deadband/hysteresis >=0")
    if args.distance_full_scale <= args.distance_deadband:
        raise SystemExit("Distance full scale must exceed the deadband")
    if args.encoder_kp < 0 or args.encoder_ki < 0:
        raise SystemExit("Encoder PI gains must be non-negative")
    if not (0.1 <= args.telemetry_timeout <= 2.0):
        raise SystemExit("Telemetry timeout must be in 0.1..2.0 seconds")
    if not (0.2 <= args.vision_timeout <= 3.0):
        raise SystemExit("Vision timeout must be in 0.2..3.0 seconds")
    if args.encoder_guard_pwm < 1 or args.reverse_speed_guard <= 0 or args.reverse_confirm_s <= 0:
        raise SystemExit("Encoder reverse/stall guard settings are invalid")
    if args.stall_speed_guard < 0 or args.stall_confirm_s <= 0:
        raise SystemExit("Encoder stall guard settings are invalid")

def main():
    args = build_parser().parse_args()
    validate_args(args)
    try:
        return App(args).run()
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        print("[FATAL]", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
