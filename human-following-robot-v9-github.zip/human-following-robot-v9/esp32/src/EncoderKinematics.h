#pragma once
#include <cmath>
#include <cstdint>
#include <algorithm>

// Encoder-only kinematic derivatives.
// Fits a cubic polynomial to the trailing 31 encoder-position samples.
// The derivatives are evaluated at the newest sample (causal, no future data).
// This is a kinematic estimate from wheel encoders, NOT an IMU vibration measure.
namespace EncoderAnalysis {

struct Estimate {
  float aLeft = 0.0f;       // filtered acceleration
  float aRight = 0.0f;
  float jLeft = 0.0f;       // filtered jerk
  float jRight = 0.0f;
  float aLeftRaw = 0.0f;    // raw causal cubic-fit derivatives
  float aRightRaw = 0.0f;
  float jLeftRaw = 0.0f;
  float jRightRaw = 0.0f;
  bool valid = false;
};

class CubicPositionFit {
 public:
  static constexpr int N = 31;

  void reset() {
    for (int i = 0; i < N; ++i) {
      t_[i] = sL_[i] = sR_[i] = 0.0f;
    }
    cursor_ = 0;
    filled_ = 0;
    lastUpdateT_ = 0.0f;
    filterInitialized_ = false;
    aFilterL_ = aFilterR_ = jFilterL_ = jFilterR_ = 0.0f;
  }

  Estimate update(float t, float sLeft, float sRight) {
    Estimate out;
    if (!std::isfinite(t) || !std::isfinite(sLeft) || !std::isfinite(sRight)) {
      reset();
      return out;
    }

    if (filled_ > 0) {
      const int newest = (cursor_ - 1 + N) % N;
      if (t <= t_[newest] || (t - t_[newest]) > 0.080f) reset();
    }

    float sampleDt = 0.020f;
    if (lastUpdateT_ > 0.0f && t > lastUpdateT_) sampleDt = t - lastUpdateT_;
    lastUpdateT_ = t;

    t_[cursor_] = t;
    sL_[cursor_] = sLeft;
    sR_[cursor_] = sRight;
    cursor_ = (cursor_ + 1) % N;
    if (filled_ < N) ++filled_;
    if (filled_ < N) return out;

    float aL = 0.0f, aR = 0.0f;
    float jL = 0.0f, jR = 0.0f;

    if (!fit(sL_, t, aL, jL) || !fit(sR_, t, aR, jR)) return out;

    out.aLeftRaw = aL;
    out.aRightRaw = aR;
    out.jLeftRaw = jL;
    out.jRightRaw = jR;

    // Separate causal low-pass for derivative display/metrics. Raw fit values
    // remain in the log; this stage is not fed into the velocity PI controller.
    if (!filterInitialized_) {
      aFilterL_ = aL; aFilterR_ = aR;
      jFilterL_ = jL; jFilterR_ = jR;
      filterInitialized_ = true;
    } else {
      const float alphaA = 1.0f - std::exp(-sampleDt / 0.080f);
      const float alphaJ = 1.0f - std::exp(-sampleDt / 0.160f);
      aFilterL_ += alphaA * (aL - aFilterL_);
      aFilterR_ += alphaA * (aR - aFilterR_);
      jFilterL_ += alphaJ * (jL - jFilterL_);
      jFilterR_ += alphaJ * (jR - jFilterR_);
    }

    out.aLeft = aFilterL_;
    out.aRight = aFilterR_;
    out.jLeft = jFilterL_;
    out.jRight = jFilterR_;
    out.valid = true;
    return out;
  }

 private:
  float t_[N] = {};
  float sL_[N] = {};
  float sR_[N] = {};
  int cursor_ = 0;
  int filled_ = 0;
  float lastUpdateT_ = 0.0f;
  bool filterInitialized_ = false;
  float aFilterL_ = 0.0f, aFilterR_ = 0.0f;
  float jFilterL_ = 0.0f, jFilterR_ = 0.0f;

  bool fit(const float *position, float tNow,
           float &acceleration, float &jerk) const {
    if (filled_ != N) return false;

    const int oldest = cursor_; // cursor points to oldest sample after full wrap
    const int newest = (cursor_ - 1 + N) % N;
    const float span = t_[newest] - t_[oldest];
    if (!std::isfinite(span) || span < 0.40f || span > 1.20f) return false;

    // Normalized time u is in [-1, 0]. This improves conditioning of the
    // 4x4 normal equations while preserving derivatives through span scaling.
    double normal[4][5] = {};
    for (int k = 0; k < N; ++k) {
      const int idx = (oldest + k) % N;
      const double u = (double(t_[idx]) - double(tNow)) / double(span);
      const double p[4] = {1.0, u, u*u, u*u*u};
      const double y = double(position[idx]);

      for (int r = 0; r < 4; ++r) {
        for (int c = 0; c < 4; ++c) normal[r][c] += p[r] * p[c];
        normal[r][4] += p[r] * y;
      }
    }

    // Gaussian elimination with partial pivoting.
    for (int col = 0; col < 4; ++col) {
      int pivot = col;
      for (int r = col + 1; r < 4; ++r) {
        if (std::fabs(normal[r][col]) > std::fabs(normal[pivot][col])) pivot = r;
      }
      if (std::fabs(normal[pivot][col]) < 1.0e-12) return false;
      if (pivot != col) {
        for (int c = col; c < 5; ++c) std::swap(normal[col][c], normal[pivot][c]);
      }
      const double divisor = normal[col][col];
      for (int c = col; c < 5; ++c) normal[col][c] /= divisor;
      for (int r = 0; r < 4; ++r) {
        if (r == col) continue;
        const double factor = normal[r][col];
        for (int c = col; c < 5; ++c) normal[r][c] -= factor * normal[col][c];
      }
    }

    const double c2 = normal[2][4];
    const double c3 = normal[3][4];
    const double invSpan = 1.0 / double(span);

    acceleration = float(2.0 * c2 * invSpan * invSpan);
    jerk = float(6.0 * c3 * invSpan * invSpan * invSpan);

    return std::isfinite(acceleration) && std::isfinite(jerk) &&
           std::fabs(acceleration) < 20.0f &&
           std::fabs(jerk) < 500.0f;
  }
};

} // namespace EncoderAnalysis
