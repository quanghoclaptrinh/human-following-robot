#include <Arduino.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <WiFi.h>
#include <WebServer.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "SCurveProfile.h"
#include "Tracking.h"
#include "EncoderKinematics.h"
#include "webpage.h"
#include "RemoteProtocol.h"

static constexpr const char *VERSION="DDMR_V9_0_MULTI_BAND_PD_SCURVE_ENCODER";
static constexpr uint8_t ENA=13,IN1=12,IN2=14,ENB=25,IN3=27,IN4=26;
// V1.4 Diagnostic: physical LEFT encoder = GPIO18/19; physical RIGHT = GPIO32/35.
// Confirmed on the user's BOTH test; individual wheel test still recommended.
static constexpr uint8_t ENC_L_A=18,ENC_L_B=19,ENC_R_A=32,ENC_R_B=35;
static constexpr int8_t MOTOR_LEFT_SIGN=1,MOTOR_RIGHT_SIGN=1;
static constexpr int PWM_MAX=120;
static constexpr float METRES_PER_COUNT=3.14159265358979323846f*.065f/234;
static constexpr uint32_t CONTROL_US=20000;
portMUX_TYPE encoderMux=portMUX_INITIALIZER_UNLOCKED;
volatile int32_t encoderLeft=0,encoderRight=0;
// Timestamped A-rising edges for period-based low-speed velocity estimation.
// Direction is normalized to positive physical forward before it is stored.
volatile uint32_t encoderLeftLastEdgeUs=0,encoderRightLastEdgeUs=0;
volatile uint32_t encoderLeftPeriodUs=0,encoderRightPeriodUs=0;
volatile int8_t encoderLeftEdgeDirection=0,encoderRightEdgeDirection=0;
// Matching positive forward readings in Diagnostic V1.4: L=+1, R=-1.
volatile int8_t encoderLeftSign=+1,encoderRightSign=-1;
int pwmLeft=0,pwmRight=0;
// Motor/encoder wiring corrected from Diagnostic V1.4; control math stays in Tracking.h.
#include "DriveIO.h"

// Value 3 is reserved for the old SETTLING state; it is NEVER entered here.
enum class Stage:uint8_t{IDLE=0,ARMING=1,RUNNING=2,POST=4,FINISHED=5,FAULT=6,STOPPED=7};
struct Frame {
  uint32_t seq=0;
  float t=0,tmRaw=0,dt=0,sRef=0,vRef=0,aRef=0,jRef=0,sL=0,sR=0,s=0,vL=0,vR=0,v=0;
  float vRawL=0,vRawR=0,vWindowL=0,vWindowR=0,vLegacyL=0,vLegacyR=0;
  float vPeriodL=0,vPeriodR=0,vPeriodFiltL=0,vPeriodFiltR=0,vHybridL=0,vHybridR=0;
  float pulseAgeL=0,pulseAgeR=0,vSmoothL=0,vSmoothR=0,vFbL=0,vFbR=0,vPiL=0,vPiR=0;
  float vAdaptiveL=0,vAdaptiveR=0,adaptiveWinL=0,adaptiveWinR=0,vCmdL=0,vCmdR=0,eL=0,eR=0;
  uint8_t speedModeL=0,speedModeR=0;
  uint8_t piRejectL=0,piRejectR=0;
  float ffL=0,ffR=0,iL=0,iR=0,assistR=0,autoR=0;
  float aEncL=0,aEncR=0,jEncL=0,jEncR=0; // filtered causal estimates for graphs/metrics
  float aEncRawL=0,aEncRawR=0,jEncRawL=0,jEncRawR=0; // unfiltered cubic-fit derivatives
  uint8_t kinValid=0;
  int32_t countL=0,countR=0;
  int16_t pwmL=0,pwmR=0;
  uint8_t phase=0,stage=0;
};
struct Shared {
  Frame row;
  uint32_t runId=0,seq=0;
  uint32_t logIntervalMs=40;
  Stage stage=Stage::IDLE;
  bool motorRequested=false,recording=false,smoothPI=false;
  float L=0,T=0,vmax=0,tr=0,aPeak=0,jPeak=0,rmsS=0,rmsV=0;
  Tracking::Gains gains;
  char fault[48]="",detail[180]="";
};
struct StartCommand {SCurveProfile profile;Tracking::Gains gains;uint32_t id=0;float vmax=.1f;bool motor=false,accelFF=false,autoRight=false,smoothPI=false;};
// V7.3 adds pulse-period/hybrid diagnostics and raw derivative channels.
// Frame is 248 bytes on the target's 4-byte ABI. CAP=256 uses 63,488 bytes.
// The 50Hz control/estimator stays full-rate; only stored history is decimated.
// Smaller bounded history keeps the expanded V7.3 telemetry inside ESP32 DRAM.
static constexpr size_t CAP=256;
Frame logRows[CAP];size_t logHead=0,logSize=0;
Shared shared;
portMUX_TYPE stateMux=portMUX_INITIALIZER_UNLOCKED;
bool urgentStop=false;
uint32_t heartbeatMs=0;
// V9 serial remote mode is mutually exclusive with the web S-curve experiment.
// The command grammar remains V8-compatible: M,<left>,<right> and S.
bool serialRemoteActive=false;
int16_t serialRemoteLeft=0,serialRemoteRight=0;
uint32_t serialRemoteLastMs=0,serialRemoteGeneration=0;
struct SerialTelemetry {
  uint32_t seq=0;
  int32_t countL=0,countR=0;
  float vL=0.0f,vR=0.0f;
  int16_t pwmL=0,pwmR=0;
  bool remoteActive=false;
};
SerialTelemetry serialTelemetry;
QueueHandle_t startQueue=nullptr;
WebServer server(80);
uint32_t nextRunId=0;
bool startPending=false;

const char *stageName(Stage s){
  switch(s){
    case Stage::ARMING:return "ARMING";case Stage::RUNNING:return "SCURVE";
    case Stage::POST:return "POST";
    case Stage::FINISHED:return "FINISHED";case Stage::FAULT:return "FAULT";
    case Stage::STOPPED:return "STOPPED";default:return "IDLE";
  }
}
bool busy(Stage s){return s==Stage::ARMING||s==Stage::RUNNING||s==Stage::POST;}
Shared statusCopy(){Shared q;portENTER_CRITICAL(&stateMux);q=shared;portEXIT_CRITICAL(&stateMux);return q;}
void counts(int32_t &l,int32_t &r){portENTER_CRITICAL(&encoderMux);l=encoderLeft;r=encoderRight;portEXIT_CRITICAL(&encoderMux);}
void encoderSnapshot(int32_t &l,int32_t &r,uint32_t &lastL,uint32_t &periodL,int8_t &dirL,
                     uint32_t &lastR,uint32_t &periodR,int8_t &dirR){
  portENTER_CRITICAL(&encoderMux);
  l=encoderLeft;r=encoderRight;
  lastL=encoderLeftLastEdgeUs;periodL=encoderLeftPeriodUs;dirL=encoderLeftEdgeDirection;
  lastR=encoderRightLastEdgeUs;periodR=encoderRightPeriodUs;dirR=encoderRightEdgeDirection;
  portEXIT_CRITICAL(&encoderMux);
}
void resetEncoderPulseTiming(){
  portENTER_CRITICAL(&encoderMux);
  encoderLeftLastEdgeUs=encoderRightLastEdgeUs=0;
  encoderLeftPeriodUs=encoderRightPeriodUs=0;
  encoderLeftEdgeDirection=encoderRightEdgeDirection=0;
  portEXIT_CRITICAL(&encoderMux);
}
void requestStop(){
  portENTER_CRITICAL(&stateMux);
  urgentStop=true;
  serialRemoteActive=false;
  serialRemoteLeft=serialRemoteRight=0;
  portEXIT_CRITICAL(&stateMux);
}
bool acceptSerialMotor(int left,int right){
  bool accepted=false;
  portENTER_CRITICAL(&stateMux);
  const bool runBusy=(urgentStop || shared.recording || busy(shared.stage) ||
                      shared.stage==Stage::FAULT || startPending);
  if(!runBusy){
    if(!serialRemoteActive)++serialRemoteGeneration;
    serialRemoteActive=true;
    serialRemoteLeft=static_cast<int16_t>(constrain(left,-PWM_MAX,PWM_MAX));
    serialRemoteRight=static_cast<int16_t>(constrain(right,-PWM_MAX,PWM_MAX));
    serialRemoteLastMs=millis();
    accepted=true;
  }
  portEXIT_CRITICAL(&stateMux);
  return accepted;
}
void publishSerialTelemetry(int32_t countL,int32_t countR,float vL,float vR,
                            int pwmL,int pwmR,bool remoteActive){
  portENTER_CRITICAL(&stateMux);
  serialTelemetry.seq++;
  serialTelemetry.countL=countL;serialTelemetry.countR=countR;
  serialTelemetry.vL=std::isfinite(vL)?vL:0.0f;
  serialTelemetry.vR=std::isfinite(vR)?vR:0.0f;
  serialTelemetry.pwmL=static_cast<int16_t>(pwmL);
  serialTelemetry.pwmR=static_cast<int16_t>(pwmR);
  serialTelemetry.remoteActive=remoteActive;
  portEXIT_CRITICAL(&stateMux);
}

// One task owns all running control state and PWM. Web only queues commands,
// updates the heartbeat, and copies bounded snapshots. All motion feedback comes from wheel encoders.
void controlTask(void *){
  Shared view;Frame row;StartCommand cmd,incoming;
  Tracking::Speed speedL,speedR;Tracking::FeedbackGuard guardL,guardR;
  Tracking::PIResponseEMA emaL,emaR;
  Tracking::WheelPI piL,piR;Tracking::RightBalance rightBalance;Tracking::Safety safety;
  EncoderAnalysis::CubicPositionFit encoderKinematics;
  Tracking::Speed remoteSpeedL,remoteSpeedR;
  int32_t remoteLastL=0,remoteLastR=0;
  uint32_t remoteGenerationSeen=0;
  bool remoteEstimatorReady=false;
  int32_t originL=0,originR=0,lastL=0,lastR=0;
  int32_t armLowL=0,armHighL=0,armLowR=0,armHighR=0;
  uint32_t previousUs=micros(),startUs=0,armUs=0,armDeadline=0,postUs=0;
  uint32_t recordTailUs=0;float metricTime=0,sumS2=0,sumV2=0;
  bool recording=false;
  // Logged samples have contiguous sequence IDs. PI, Encoder, encoder-kinematics
  // estimation and safety run at 50Hz; only web/CSV history is decimated.
  uint32_t logEveryTicks=2,logTicks=0;
  Stage lastLoggedStage=Stage::IDLE;
  TickType_t wake=xTaskGetTickCount();
  auto off=[&](){setMotor(0,0);piL.reset();piR.reset();rightBalance.reset();};
  auto fail=[&](const char *why,uint32_t now){
    snprintf(view.fault,sizeof(view.fault),"%s",why);
    uint32_t lastHb;portENTER_CRITICAL(&stateMux);lastHb=heartbeatMs;portEXIT_CRITICAL(&stateMux);
    const unsigned long hbAge=(unsigned long)(uint32_t)(millis()-lastHb);
    snprintf(view.detail,sizeof(view.detail),"t=%.3f PWM_before=%d/%d vL=%.4f vR=%.4f count=%ld/%ld heartbeatAge=%lums",
      row.t,pwmLeft,pwmRight,row.vL,row.vR,(long)row.countL,(long)row.countR,hbAge);
    off();view.stage=Stage::FAULT;recordTailUs=now;
  };
  for(;;){
    vTaskDelayUntil(&wake,pdMS_TO_TICKS(20));
    const uint32_t now=micros();const float dt=uint32_t(now-previousUs)*1.e-6f;previousUs=now;
    bool append=false;
    bool stop,remoteActive;uint32_t lastHeartbeat,remoteLastMs,remoteGeneration;
    int remoteLeft,remoteRight;
    portENTER_CRITICAL(&stateMux);
    stop=urgentStop;urgentStop=false;lastHeartbeat=heartbeatMs;
    remoteActive=serialRemoteActive;remoteLeft=serialRemoteLeft;remoteRight=serialRemoteRight;
    remoteLastMs=serialRemoteLastMs;remoteGeneration=serialRemoteGeneration;
    portEXIT_CRITICAL(&stateMux);
    int32_t l,r;
    uint32_t edgeLastL=0,edgePeriodL=0,edgeLastR=0,edgePeriodR=0;
    int8_t edgeDirL=0,edgeDirR=0;
    encoderSnapshot(l,r,edgeLastL,edgePeriodL,edgeDirL,edgeLastR,edgePeriodR,edgeDirR);
    if(stop){
      xQueueReset(startQueue);off();
      // An emergency STOP must not erase the first hardware fault or a
      // completed result, nor perpetually extend the recording tail.
      if((busy(view.stage)||recording)&&view.stage!=Stage::FAULT&&view.stage!=Stage::STOPPED){
        view.stage=Stage::STOPPED;
        snprintf(view.fault,sizeof(view.fault),"USER_STOP");recordTailUs=now;
      }
    }else if(xQueueReceive(startQueue,&incoming,0)==pdTRUE&&!busy(view.stage)&&!recording){
      cmd=incoming;
      // Keep a bounded history for the complete run plus post-record tail.
      // For longer profiles, reduce only the
      // logging rate automatically so the whole run remains in memory.
      const float recordSeconds=cmd.profile.tTotal+2.5f;
      const float minIntervalSeconds=recordSeconds/float(CAP-16);
      const float tickSeconds=CONTROL_US*1.0e-6f;
      logEveryTicks=std::max<uint32_t>(2, uint32_t(std::ceil(minIntervalSeconds/tickSeconds)));
      logTicks=0;
      lastLoggedStage=Stage::IDLE;
      off();view=Shared();view.logIntervalMs=logEveryTicks*(CONTROL_US/1000);view.stage=Stage::ARMING;view.runId=cmd.id;view.L=cmd.profile.distance;
      view.T=cmd.profile.tTotal;view.vmax=cmd.vmax;view.tr=cmd.profile.accelerationTime();
      view.aPeak=cmd.profile.peakAcceleration();view.jPeak=cmd.profile.peakJerk();
      view.gains=cmd.gains;view.motorRequested=cmd.motor;view.smoothPI=cmd.smoothPI;
      row=Frame();lastL=l;lastR=r;armUs=armDeadline=now;recording=false;
      armLowL=armHighL=l;armLowR=armHighR=r;
      portENTER_CRITICAL(&stateMux);logHead=logSize=0;portEXIT_CRITICAL(&stateMux);
    }
    // V9 remote mode: 50 Hz hybrid encoder speed estimate and direct signed-PWM
    // output. The S-curve web experiment and serial person-follow mode never
    // write the motor bridge at the same time.
    if(!stop && !recording && !busy(view.stage)){
      if(!remoteEstimatorReady || remoteGeneration!=remoteGenerationSeen){
        remoteSpeedL.reset();remoteSpeedR.reset();
        remoteLastL=l;remoteLastR=r;
        remoteGenerationSeen=remoteGeneration;remoteEstimatorReady=true;
      }
      remoteSpeedL.update((l-remoteLastL)*METRES_PER_COUNT,dt);
      remoteSpeedR.update((r-remoteLastR)*METRES_PER_COUNT,dt);
      remoteLastL=l;remoteLastR=r;
      const float remoteRef=Tracking::clamp(float(std::max(std::abs(remoteLeft),std::abs(remoteRight)))*.001f,.015f,.12f);
      const float remoteVL=remoteSpeedL.updateHybrid(now,edgeLastL,edgePeriodL,edgeDirL,remoteRef,METRES_PER_COUNT,dt);
      const float remoteVR=remoteSpeedR.updateHybrid(now,edgeLastR,edgePeriodR,edgeDirR,remoteRef,METRES_PER_COUNT,dt);
      if(remoteActive){
        if(uint32_t(millis()-remoteLastMs)>600UL){
          portENTER_CRITICAL(&stateMux);
          if(serialRemoteGeneration==remoteGeneration){serialRemoteActive=false;serialRemoteLeft=serialRemoteRight=0;}
          portEXIT_CRITICAL(&stateMux);
          remoteActive=false;off();
        }else{
          setMotor(remoteLeft,remoteRight);
        }
      }else{
        off();
      }
      publishSerialTelemetry(l,r,remoteVL,remoteVR,pwmLeft,pwmRight,remoteActive);
    }

    if(view.stage==Stage::ARMING){
      off();
      if(uint32_t(millis()-lastHeartbeat)>1500UL)fail("WEB_HEARTBEAT_LOST",now);
      else if(uint32_t(now-armDeadline)>5000000UL)fail("WHEELS_MOVING_AT_START",now);
      else {
        armLowL=std::min(armLowL,l);armHighL=std::max(armHighL,l);
        armLowR=std::min(armLowR,r);armHighR=std::max(armHighR,r);
        if(int64_t(armHighL)-armLowL>2||int64_t(armHighR)-armLowR>2){
          armLowL=armHighL=l;armLowR=armHighR=r;armUs=now;
        }
        if(uint32_t(now-armUs)>=1000000UL){
          resetEncoderPulseTiming();
          edgeLastL=edgePeriodL=edgeLastR=edgePeriodR=0;
          edgeDirL=edgeDirR=0;
          originL=lastL=l;originR=lastR=r;startUs=now;row=Frame();speedL.reset();speedR.reset();guardL.reset();guardR.reset();emaL.reset();emaR.reset();encoderKinematics.reset();
          safety.reset();metricTime=sumS2=sumV2=0;recording=true;view.stage=Stage::RUNNING;
        }
      }
    }
    if(recording){
      row.t=uint32_t(now-startUs)*1.e-6f;row.dt=dt;row.tmRaw=std::max(0.f,row.t-dt*.5f);
      // Position and counts in this row come from the SAME ISR snapshot.
      row.countL=l-originL;row.countR=r-originR;
      row.sL=row.countL*METRES_PER_COUNT;row.sR=row.countR*METRES_PER_COUNT;row.s=(row.sL+row.sR)*.5f;
      const MotionSample ref=cmd.profile.evaluate(row.t);
      row.sRef=ref.s;row.vRef=ref.v;row.aRef=ref.a;row.jRef=ref.j;row.phase=ref.phase;
      speedL.update((l-lastL)*METRES_PER_COUNT,dt);
      speedR.update((r-lastR)*METRES_PER_COUNT,dt);
      lastL=l;lastR=r;
      row.vHybridL=speedL.updateHybrid(now,edgeLastL,edgePeriodL,edgeDirL,ref.v,METRES_PER_COUNT,dt);
      row.vHybridR=speedR.updateHybrid(now,edgeLastR,edgePeriodR,edgeDirR,ref.v,METRES_PER_COUNT,dt);
      row.vPeriodL=speedL.periodSpeed;row.vPeriodR=speedR.periodSpeed;
      row.vPeriodFiltL=speedL.periodFiltered;row.vPeriodFiltR=speedR.periodFiltered;
      row.pulseAgeL=speedL.pulseAge;row.pulseAgeR=speedR.pulseAge;
      row.speedModeL=speedL.hybridMode;row.speedModeR=speedR.hybridMode;
      row.vL=row.vHybridL;row.vR=row.vHybridR;row.v=(row.vL+row.vR)*.5f;
      // Encoder-only kinematics: causal cubic least-squares fit over the latest
      // 31 position samples at 50Hz. Raw and filtered derivatives are both logged.
      const EncoderAnalysis::Estimate kin=encoderKinematics.update(row.t,row.sL,row.sR);
      row.kinValid=kin.valid?1:0;
      if(kin.valid){
        row.aEncL=kin.aLeft;row.aEncR=kin.aRight;row.jEncL=kin.jLeft;row.jEncR=kin.jRight;
        row.aEncRawL=kin.aLeftRaw;row.aEncRawR=kin.aRightRaw;
        row.jEncRawL=kin.jLeftRaw;row.jEncRawR=kin.jRightRaw;
      }else{
        row.aEncL=row.aEncR=row.jEncL=row.jEncR=0.0f;
        row.aEncRawL=row.aEncRawR=row.jEncRawL=row.jEncRawR=0.0f;
      }
      row.vSmoothL=speedL.filtered;row.vSmoothR=speedR.filtered;
      row.vRawL=speedL.raw;row.vRawR=speedR.raw;
      row.vWindowL=speedL.windowed;row.vWindowR=speedR.windowed;
      row.vLegacyL=speedL.feedback;row.vLegacyR=speedR.feedback;
      row.vFbL=row.vHybridL;row.vFbR=row.vHybridR;
      row.vAdaptiveL=speedL.adaptive;row.vAdaptiveR=speedR.adaptive;
      row.adaptiveWinL=speedL.adaptiveWindow;row.adaptiveWinR=speedR.adaptiveWindow;
      // Hybrid period/count estimate is the default feedback in V7.3.
      // Optional smoothPI adds a separate causal 60ms EMA after the hybrid estimate.
      const float guardedL=guardL.update(row.vHybridL,ref.v);
      const float guardedR=guardR.update(row.vHybridR,ref.v);
      row.vPiL=cmd.smoothPI?emaL.update(guardedL,dt):guardedL;
      row.vPiR=cmd.smoothPI?emaR.update(guardedR,dt):guardedR;
      row.piRejectL=guardL.rejectedNow?1:0;row.piRejectR=guardR.rejectedNow?1:0;
      row.eL=ref.s-row.sL;row.eR=ref.s-row.sR;
      if(view.stage==Stage::RUNNING&&row.t>=view.T){
        // No distance catch-up: stop at the first control tick at/after T.
        off();row.vCmdL=row.vCmdR=0;view.stage=Stage::POST;postUs=now;
      }
      row.assistR=0;row.autoR=0;
      if(view.stage==Stage::RUNNING){
        // SPEED-ONLY TRACKING: same reference for both wheels; position
        // is logged solely for monitoring and independent safety checks.
        row.vCmdL=Tracking::target(ref.v,view.vmax);
        row.vCmdR=Tracking::target(ref.v,view.vmax);
        if(cmd.motor){
          const char *reason=safety.check(dt,uint32_t(millis()-lastHeartbeat)*.001f,row.sL,row.sR,view.L,
            row.vFbL,row.vFbR,row.vCmdL,row.vCmdR,pwmLeft,pwmRight,view.vmax);
          if(reason)fail(reason,now);
          else {
            // RIGHT ONLY: independent feedforward to offset extra mechanical
            // load, with OPTIONAL slow adaptive trim at constant reference.
            // Original left PI and gains are deliberately untouched.
            Tracking::WheelGains rightGains=cmd.gains.right;
            row.autoR=cmd.autoRight?rightBalance.update(ref.v,row.vPiL,row.vPiR,ref.a,dt):0.0f;
            rightGains.loadPWM+=row.autoR;
            row.assistR=rightGains.loadPWM;
            setMotor(piL.update(row.vCmdL,row.vPiL,dt,cmd.gains.left,3.14159265358979323846f*.065f,cmd.accelFF?ref.a:0.f),
                     piR.update(row.vCmdR,row.vPiR,dt,rightGains,3.14159265358979323846f*.065f,cmd.accelFF?ref.a:0.f));
          }
        }else off();
        if(view.stage==Stage::RUNNING){
          metricTime+=dt;const float evL=row.vFbL-ref.v,evR=row.vFbR-ref.v;
          sumS2+=.5f*(row.eL*row.eL+row.eR*row.eR)*dt;
          sumV2+=.5f*(evL*evL+evR*evR)*dt;
        }
      }else {off();row.vCmdL=row.vCmdR=0;}
      if(view.stage==Stage::POST){
        if(cmd.motor&&std::max(row.sL,row.sR)>=view.L+.020f)fail("DISTANCE_GUARD",now);
        else if(uint32_t(now-postUs)>=2000000UL){
          view.stage=Stage::FINISHED;
          recording=false;
        }
      }
      if((view.stage==Stage::FAULT||view.stage==Stage::STOPPED)&&uint32_t(now-recordTailUs)>=2000000UL)recording=false;
      row.ffL=piL.feedforward;row.ffR=piR.feedforward;
      row.iL=piL.integral;row.iR=piR.integral;
      row.pwmL=pwmLeft;row.pwmR=pwmRight;row.stage=(uint8_t)view.stage;
      publishSerialTelemetry(l,r,row.vL,row.vR,pwmLeft,pwmRight,false);
      // IMPORTANT: increase seq only for actual stored samples; otherwise
      // browser falsely labels deliberate decimation as missing Wi-Fi data.
      ++logTicks;
      append=(row.seq==0)||(logTicks>=logEveryTicks)||(view.stage!=lastLoggedStage);
      if(append){
        ++row.seq;
        logTicks=0;
        lastLoggedStage=view.stage;
      }
      view.rmsS=metricTime>0?std::sqrt(sumS2/metricTime):0;view.rmsV=metricTime>0?std::sqrt(sumV2/metricTime):0;
    }
    view.row=row;view.seq=row.seq;view.recording=recording;
    portENTER_CRITICAL(&stateMux);
    if(append){logRows[logHead]=row;logHead=(logHead+1)%CAP;if(logSize<CAP)logSize++;}
    shared=view;
    portEXIT_CRITICAL(&stateMux);
  }
}

void error(int code,const char *why){server.send(code,"application/json",String("{\"ok\":false,\"error\":\"")+why+"\"}");}
bool number(const char *key,float fallback,float low,float high,float &value){
  if(!server.hasArg(key)){value=fallback;return true;}
  const String s=server.arg(key);char *end=nullptr;value=strtof(s.c_str(),&end);
  return end!=s.c_str()&&end&&*end==0&&std::isfinite(value)&&value>=low&&value<=high;
}
bool parse(StartCommand &c){
  float L,V,A,J,Tr;
  if(!number("L",.5f,.05f,5,L)||!number("V",.1f,.02f,.15f,V)||!number("Tr",2,0,120,Tr)
     ||!number("A",.10f,.02f,.25f,A)||!number("J",.18f,.02f,.60f,J)
     ||!number("staticL",46,0,80,c.gains.left.staticPWM)
     ||!number("ffL",.22f,0,1.5f,c.gains.left.kff)
     ||!number("kpL",1.50f,0,3,c.gains.left.kp)
     ||!number("kiL",1.00f,0,2,c.gains.left.ki)
     ||!number("kaL",0.f,0,80,c.gains.left.ka)
     ||!number("assistR",0,0,30,c.gains.right.loadPWM)
     ||!number("staticR",52,0,80,c.gains.right.staticPWM)
     ||!number("ffR",.22f,0,1.5f,c.gains.right.kff)
     ||!number("kpR",1.50f,0,3,c.gains.right.kp)
     ||!number("kiR",1.00f,0,2,c.gains.right.ki)
     ||!number("kaR",0.f,0,80,c.gains.right.ka)
){
    error(400,"Invalid parameter range");return false;
  }
  if(server.hasArg("ksL")||server.hasArg("kvL")||server.hasArg("kpos")||server.hasArg("kPos")){
    error(400,"Outdated web page: reload with Ctrl+F5");return false;
  }
  if(!c.profile.plan(L,{V,A,J})){error(400,"Invalid S-curve");return false;}
  if(Tr>0&&!c.profile.setAccelerationTime(Tr)){
    char why[128];snprintf(why,sizeof(why),"Tr must be %.3f..%.3f s; use Tr=0 for automatic",c.profile.accelTimeMin,c.profile.accelerationTimeMax());
    error(400,why);return false;
  }
  if(server.hasArg("accelFF")&&server.arg("accelFF")!="0"&&server.arg("accelFF")!="1"){
    error(400,"Invalid acceleration FF switch");return false;
  }
  if(server.hasArg("autoRight")&&server.arg("autoRight")!="0"&&server.arg("autoRight")!="1"){
    error(400,"Invalid right balance switch");return false;
  }
  if(server.hasArg("smoothPI")&&server.arg("smoothPI")!="0"&&server.arg("smoothPI")!="1"){
    error(400,"Invalid smooth PI mode");return false;
  }
  c.accelFF=server.arg("accelFF")=="1";
  c.autoRight=server.arg("autoRight")=="1";
  c.smoothPI=server.arg("smoothPI")=="1";
  c.vmax=V;return true;
}
void planReply(const StartCommand &c,uint32_t id){
  char b[600];snprintf(b,sizeof(b),"{\"ok\":true,\"version\":\"%s\",\"runId\":%lu,\"L\":%.6f,\"T\":%.6f,\"Tr\":%.6f,\"vPeak\":%.6f,\"aPeak\":%.6f,\"jPeak\":%.6f}",
    VERSION,(unsigned long)id,c.profile.distance,c.profile.tTotal,c.profile.accelerationTime(),c.profile.peakVelocity(),c.profile.peakAcceleration(),c.profile.peakJerk());
  server.send(200,"application/json",b);
}
void handleRun(){
  bool stopping,remoteActive;
  portENTER_CRITICAL(&stateMux);stopping=urgentStop;remoteActive=serialRemoteActive;portEXIT_CRITICAL(&stateMux);
  const Shared q=statusCopy();if(startPending||stopping||remoteActive||q.recording||busy(q.stage)){error(409,"STOP or wait before another run");return;}
  if(server.arg("confirm")!="YES"||(server.arg("motor")!="0"&&server.arg("motor")!="1")){error(400,"Explicit motor/run confirmation required");return;}
  StartCommand c;if(!parse(c))return;c.motor=server.arg("motor")=="1";c.id=++nextRunId;if(!c.id)c.id=++nextRunId;
  portENTER_CRITICAL(&stateMux);heartbeatMs=millis();portEXIT_CRITICAL(&stateMux);
  if(xQueueSend(startQueue,&c,0)!=pdTRUE){error(503,"Control command queue full");return;}
  startPending=true;planReply(c,c.id);
}
void handleData(){
  const Shared q=statusCopy();char b[1500];
  uint32_t lastHb;portENTER_CRITICAL(&stateMux);lastHb=heartbeatMs;portEXIT_CRITICAL(&stateMux);
  const unsigned long hbAge=(unsigned long)(uint32_t)(millis()-lastHb);
  snprintf(b,sizeof(b),"{\"ok\":true,\"version\":\"%s\",\"runId\":%lu,\"seq\":%lu,\"state\":\"%s\",\"busy\":%s,\"motorRequested\":%s,\"controlMode\":\"SPEED_ONLY_HYBRID_ENCODER\",\"smoothPI\":%s,\"L\":%.6f,\"T\":%.6f,\"t\":%.6f,\"s\":%.6f,\"sL\":%.6f,\"sR\":%.6f,\"vL\":%.6f,\"vR\":%.6f,\"vHybridL\":%.6f,\"vHybridR\":%.6f,\"vPeriodL\":%.6f,\"vPeriodR\":%.6f,\"speedModeL\":%u,\"speedModeR\":%u,\"pwmL\":%d,\"pwmR\":%d,\"assistR\":%.3f,\"autoR\":%.3f,\"rmsS\":%.6f,\"rmsV\":%.6f,\"logIntervalMs\":%lu,\"heartbeatAgeMs\":%lu,\"apClients\":%u,\"fault\":\"%s\",\"detail\":\"%s\"}",
    VERSION,(unsigned long)q.runId,(unsigned long)q.seq,stageName(q.stage),(busy(q.stage)||q.recording)?"true":"false",q.motorRequested?"true":"false",q.smoothPI?"true":"false",
    q.L,q.T,q.row.t,q.row.s,q.row.sL,q.row.sR,q.row.vL,q.row.vR,q.row.vHybridL,q.row.vHybridR,
    q.row.vPeriodL,q.row.vPeriodR,(unsigned int)q.row.speedModeL,(unsigned int)q.row.speedModeR,
    q.row.pwmL,q.row.pwmR,q.row.assistR,q.row.autoR,q.rmsS,q.rmsV,(unsigned long)q.logIntervalMs,
    hbAge,(unsigned int)WiFi.softAPgetStationNum(),q.fault,q.detail);
  server.send(200,"application/json",b);
}
void handleSamples(){
  const uint32_t id=strtoul(server.arg("runId").c_str(),nullptr,10),after=strtoul(server.arg("after").c_str(),nullptr,10);
  static Frame batch[8];size_t n=0;bool match;
  portENTER_CRITICAL(&stateMux);match=id&&id==shared.runId;
  if(match)for(size_t i=0;i<logSize&&n<8;i++){
    const Frame &r=logRows[(logHead+CAP-logSize+i)%CAP];if(r.seq>after)batch[n++]=r;
  }
  portEXIT_CRITICAL(&stateMux);
  if(!match){error(409,"Different runId; no automatic switch");return;}
  String body;body.reserve(30000);body="{\"ok\":true,\"rows\":[";
  for(size_t i=0;i<n;i++){
    const Frame &r=batch[i];char b[2560];
    snprintf(b,sizeof(b),"{\"seq\":%lu,\"t\":%.6f,\"tmRaw\":%.6f,\"dt\":%.6f,\"sRef\":%.6f,\"vRef\":%.6f,\"aRef\":%.6f,\"jRef\":%.6f,\"sL\":%.6f,\"sR\":%.6f,\"s\":%.6f,\"vL\":%.6f,\"vR\":%.6f,\"v\":%.6f,\"vRawL\":%.6f,\"vRawR\":%.6f,\"vWindowL\":%.6f,\"vWindowR\":%.6f,\"vLegacyL\":%.6f,\"vLegacyR\":%.6f,\"vPeriodL\":%.6f,\"vPeriodR\":%.6f,\"vPeriodFiltL\":%.6f,\"vPeriodFiltR\":%.6f,\"vHybridL\":%.6f,\"vHybridR\":%.6f,\"pulseAgeL\":%.6f,\"pulseAgeR\":%.6f,\"speedModeL\":%u,\"speedModeR\":%u,\"vSmoothL\":%.6f,\"vSmoothR\":%.6f,\"vFbL\":%.6f,\"vFbR\":%.6f,\"vPiL\":%.6f,\"vPiR\":%.6f,\"vAdaptiveL\":%.6f,\"vAdaptiveR\":%.6f,\"adaptiveWinL\":%.6f,\"adaptiveWinR\":%.6f,\"piRejectL\":%u,\"piRejectR\":%u,\"vCmdL\":%.6f,\"vCmdR\":%.6f,\"eL\":%.6f,\"eR\":%.6f,\"ffL\":%.3f,\"ffR\":%.3f,\"iL\":%.3f,\"iR\":%.3f,\"assistR\":%.3f,\"autoR\":%.3f,\"pwmL\":%d,\"pwmR\":%d,\"countL\":%ld,\"countR\":%ld,\"aEncL\":%.6f,\"aEncR\":%.6f,\"jEncL\":%.6f,\"jEncR\":%.6f,\"aEncRawL\":%.6f,\"aEncRawR\":%.6f,\"jEncRawL\":%.6f,\"jEncRawR\":%.6f,\"kinValid\":%u,\"phase\":%u,\"stage\":%u}",
      (unsigned long)r.seq,r.t,r.tmRaw,r.dt,r.sRef,r.vRef,r.aRef,r.jRef,r.sL,r.sR,r.s,r.vL,r.vR,r.v,
      r.vRawL,r.vRawR,r.vWindowL,r.vWindowR,r.vLegacyL,r.vLegacyR,r.vPeriodL,r.vPeriodR,
      r.vPeriodFiltL,r.vPeriodFiltR,r.vHybridL,r.vHybridR,r.pulseAgeL,r.pulseAgeR,
      (unsigned int)r.speedModeL,(unsigned int)r.speedModeR,r.vSmoothL,r.vSmoothR,r.vFbL,r.vFbR,
      r.vPiL,r.vPiR,r.vAdaptiveL,r.vAdaptiveR,r.adaptiveWinL,r.adaptiveWinR,
      (unsigned int)r.piRejectL,(unsigned int)r.piRejectR,r.vCmdL,r.vCmdR,r.eL,r.eR,
      r.ffL,r.ffR,r.iL,r.iR,r.assistR,r.autoR,r.pwmL,r.pwmR,(long)r.countL,(long)r.countR,
      r.aEncL,r.aEncR,r.jEncL,r.jEncR,r.aEncRawL,r.aEncRawR,r.jEncRawL,r.jEncRawR,
      (unsigned int)r.kinValid,r.phase,r.stage);
    if(i)body+=',';
    body+=b;
  }
  body+="]}";server.send(200,"application/json",body);
}
void handleEncoders(){
  int32_t l,r;counts(l,r);
  char b[112];snprintf(b,sizeof(b),"{\"ok\":true,\"left\":%ld,\"right\":%ld}",(long)l,(long)r);
  server.send(200,"application/json",b);
}
void setup(){
  // Disable the L298N bridges before Serial, Wi-Fi, FreeRTOS, encoder and web init.
  // Must be the first operation in setup().
  motorSafeInit();
  Serial.begin(115200);
  pinMode(ENC_L_A,INPUT_PULLUP);pinMode(ENC_L_B,INPUT_PULLUP); // left: 18/19
  pinMode(ENC_R_A,INPUT_PULLUP);pinMode(ENC_R_B,INPUT);        // right: 32/35; GPIO35 INPUT only
  attachInterrupt(digitalPinToInterrupt(ENC_L_A),readEncoderLeft,RISING);
  attachInterrupt(digitalPinToInterrupt(ENC_R_A),readEncoderRight,RISING);
  // AP first: even if the control task cannot be created, the SSID is
  // advertised and the serial console reports the failing initialization step.
  // Motors were already stopped above and remain OFF during initialization.
  Serial.println("[BOOT] V9.0 Multi-Band/PD/S-Curve + encoder remote mode: starting Wi-Fi access point...");
  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);
  const bool apOk = WiFi.softAP("DDMR_ESP32", "12345678");
  if (!apOk) {
    setMotor(0,0);
    Serial.println("[BOOT] FAULT WIFI_AP: softAP() returned false; motors OFF");
    while (true) delay(1000);
  }
  Serial.print("[BOOT] AP ready. SSID=DDMR_ESP32, IP=");
  Serial.println(WiFi.softAPIP());

  Serial.println("[BOOT] Creating control queue/task...");
  startQueue=xQueueCreate(2,sizeof(StartCommand));
  if(!startQueue||xTaskCreatePinnedToCore(controlTask,"speed_control",8192,nullptr,3,nullptr,1)!=pdPASS){
    setMotor(0,0);
    Serial.println("[BOOT] FAULT CONTROL_TASK_INIT; motors OFF; web server NOT started");
    while(true)delay(1000);
  }
  Serial.println("[BOOT] Control task created; starting HTTP server...");
  server.on("/",HTTP_GET,[]{server.send_P(200,"text/html; charset=utf-8",WEBPAGE);});
  server.on("/encoders",HTTP_GET,handleEncoders);
  server.on("/preview",HTTP_POST,[]{StartCommand c;if(parse(c))planReply(c,0);});
  server.on("/run",HTTP_POST,handleRun);server.on("/data",HTTP_GET,handleData);server.on("/samples",HTTP_GET,handleSamples);
  server.on("/stop",HTTP_POST,[]{startPending=false;requestStop();server.send(200,"application/json","{\"ok\":true}");});
  server.on("/heartbeat",HTTP_POST,[]{
    if(!nextRunId||server.arg("runId")!=String(nextRunId)){error(409,"Stale runId");return;}
    portENTER_CRITICAL(&stateMux);heartbeatMs=millis();portEXIT_CRITICAL(&stateMux);
    server.send(200,"application/json","{\"ok\":true}");
  });
  server.begin();Serial.println("[BOOT] HTTP server started on port 80");Serial.printf("READY %s; V9 serial remote + hybrid encoder telemetry; web S-curve experiment retained; EN PWM<=120; motor OFF by default\n",VERSION);
  Serial.println("V9 remote telemetry: 50Hz low-speed A-edge period + high-speed 80-200ms count-window hybrid velocity; web S-curve PI diagnostics retained.");
  Serial.println("Encoder a/j research channel: causal cubic position fit over 31 samples; filtered a/j tau=80/160ms; raw derivatives also logged; no IMU.");
  Serial.println("speedMode: 0=invalid, 1=period, 2=blend, 3=count-window; optional PI EMA 60ms is OFF by default; heartbeat fail-safe=1.5s.");
  Serial.println("RIGHT motor: L298N A ENA13 IN1=12 IN2=14 | encoder GPIO32/35 sign=-1");
  Serial.println("LEFT  motor: L298N B ENB25 IN3=27 IN4=26 | encoder GPIO18/19 sign=+1");
  Serial.println("D=65mm CPR=234; WiFi DDMR_ESP32 / 12345678 -> http://192.168.4.1");
  Serial.println("V9 serial commands: M,<left>,<right> signed PWM -200..200 (hardware clamp 120); S or STOP = immediate stop");
  Serial.println("V9 telemetry: E,seq,countL,countR,vL_mps,vR_mps,pwmL,pwmR,commandAgeMs,remoteActive");
}
void loop(){
  server.handleClient();
  if(startPending&&statusCopy().runId==nextRunId)startPending=false;
  static char line[64];static size_t lineLength=0;
  while(Serial.available()){
    const char c=static_cast<char>(Serial.read());
    if(c=='\n'||c=='\r'){
      if(lineLength){
        line[lineLength]='\0';
        const RemoteProtocol::Command command=RemoteProtocol::parseLine(line);
        if(command.type==RemoteProtocol::Type::STOP){requestStop();Serial.println("ACK,S");}
        else if(command.type==RemoteProtocol::Type::MOTOR){
          if(acceptSerialMotor(command.left,command.right))Serial.println("ACK,M");
          else Serial.println("ERR,BUSY");
        }else Serial.println("ERR,COMMAND");
      }
      lineLength=0;
    }else if(lineLength<sizeof(line)-1){line[lineLength++]=c;}
    else{lineLength=0;Serial.println("ERR,LINE_TOO_LONG");}
  }
  static uint32_t lastTelemetryMs=0;
  const uint32_t nowMs=millis();
  if(uint32_t(nowMs-lastTelemetryMs)>=50UL){
    lastTelemetryMs=nowMs;
    SerialTelemetry t;uint32_t commandAge=0;bool active=false;
    portENTER_CRITICAL(&stateMux);
    t=serialTelemetry;active=serialRemoteActive;
    commandAge=active?uint32_t(nowMs-serialRemoteLastMs):0;
    portEXIT_CRITICAL(&stateMux);
    Serial.printf("E,%lu,%ld,%ld,%.5f,%.5f,%d,%d,%lu,%u\n",
      (unsigned long)t.seq,(long)t.countL,(long)t.countR,t.vL,t.vR,
      (int)t.pwmL,(int)t.pwmR,(unsigned long)commandAge,active?1U:0U);
  }
  delay(1);
}
