#pragma once
// Backward-compatible line protocol used by the Raspberry Pi V8 motor wrapper.
// Commands: M,<left>,<right> (signed PWM, accepted range -200..200), S, STOP.
// Parsing is host-testable and has no Arduino dependency.
#include <cstdlib>
#include <cstring>
#include <cctype>

namespace RemoteProtocol {
enum class Type { NONE, MOTOR, STOP, INVALID };
struct Command {
  Type type = Type::NONE;
  int left = 0;
  int right = 0;
};

inline const char *skipSpaces(const char *p) {
  while (*p && std::isspace(static_cast<unsigned char>(*p))) ++p;
  return p;
}

inline bool parseInteger(const char *&p, long &value) {
  p = skipSpaces(p);
  if (!*p) return false;
  char *end = nullptr;
  value = std::strtol(p, &end, 10);
  if (end == p) return false;
  p = end;
  return true;
}

inline Command parseLine(const char *line) {
  Command out;
  if (!line) { out.type = Type::INVALID; return out; }
  const char *p = skipSpaces(line);
  size_t length = std::strlen(p);
  while (length > 0 && std::isspace(static_cast<unsigned char>(p[length - 1]))) --length;
  if (length == 1 && (p[0] == 'S' || p[0] == 's')) {
    out.type = Type::STOP; return out;
  }
  if (length == 4 && (p[0] == 'S' || p[0] == 's') &&
      (p[1] == 'T' || p[1] == 't') && (p[2] == 'O' || p[2] == 'o') &&
      (p[3] == 'P' || p[3] == 'p')) {
    out.type = Type::STOP; return out;
  }
  if (length < 4 || (p[0] != 'M' && p[0] != 'm') || p[1] != ',') {
    out.type = Type::INVALID; return out;
  }
  p += 2;
  long left = 0, right = 0;
  if (!parseInteger(p, left)) { out.type = Type::INVALID; return out; }
  p = skipSpaces(p);
  if (*p != ',') { out.type = Type::INVALID; return out; }
  ++p;
  if (!parseInteger(p, right)) { out.type = Type::INVALID; return out; }
  p = skipSpaces(p);
  if (*p != '\0' || left < -200 || left > 200 || right < -200 || right > 200) {
    out.type = Type::INVALID; return out;
  }
  out.type = Type::MOTOR;
  out.left = static_cast<int>(left);
  out.right = static_cast<int>(right);
  return out;
}
} // namespace RemoteProtocol
