#pragma once
#include <Arduino.h>
const char WEBPAGE[] PROGMEM=R"HTML(
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DDMR V9.0 — S-curve Encoder-hybrid: v/a/j</title><style>
*{box-sizing:border-box}body{margin:0;background:#111821;color:#e6edf3;font:16px system-ui,sans-serif}.wrap{max-width:1450px;margin:auto;padding:20px}h1{font-size:25px;margin:0 0 8px}h2{font-size:17px;margin:0 0 8px}.panel{background:#1b2531;border:1px solid #3d5064;border-radius:10px;padding:16px;margin:14px 0}.fields,.buttons,.stats{display:flex;gap:14px;flex-wrap:wrap;align-items:end}label{display:grid;gap:5px}input,button,select{font:inherit;padding:10px;border-radius:6px;border:1px solid #65788d}input,select{width:130px;background:#101820;color:#fff}select{width:auto;max-width:100%}button{cursor:pointer;background:#286fbd;color:white}button:disabled{opacity:.45;cursor:default}.stop{background:#b52d36}.check{display:flex;align-items:center;gap:8px}.check input{width:20px;height:20px}.muted{color:#b1c0d0;line-height:1.5}.warn{color:#ffd089}#message{white-space:pre-wrap;min-height:25px}.stats>div{background:#111b26;padding:10px;min-width:150px;border-radius:5px}.stats small{display:block;color:#b1c0d0}.stats b{display:block;font-size:20px}.plots{display:grid;grid-template-columns:1fr 1fr;gap:16px}.plots .panel{margin:0;min-width:0}canvas{width:100%;height:auto;background:#101820;border-radius:6px}.legend{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:14px;font-size:14px}details{margin:14px 0}summary{cursor:pointer;color:#b9d8ff}details .fields{margin-top:12px}@media(max-width:800px){.plots{grid-template-columns:1fr}.wrap{padding:10px}input{width:110px}}
.view-buttons button{background:#23384c;border:1px solid #5c7892}.view-buttons button.active{background:#206bb3;border-color:#a7d9ff;box-shadow:0 0 0 1px #a7d9ff inset}.is-hidden{display:none!important}
</style></head><body><main class="wrap">
<h1>DDMR V9.0 — S-curve Encoder-hybrid: Velocity · Acceleration · Jerk</h1><div class="muted">Điều khiển PI 2 bánh ở 50Hz · encoder-only · gia tốc/jerk suy ra từ vị trí encoder bằng fit đa thức bậc 3 nhân quả · không dùng IMU</div>
<section class="panel"><div id="connection">Đang kết nối…</div>
<p class="warn"><b>ĐÃ SỬA SƠ ĐỒ L298N:</b> BÁNH TRÁI = ENB GPIO25 / IN3 GPIO27 / IN4 GPIO26 / encoder GPIO18/19 (+).
BÁNH PHẢI = ENA GPIO13 / IN1 GPIO12 / IN2 GPIO14 / encoder GPIO32/35 (−). 
Đầu tiên tắt MOTOR, quay tay từng bánh để xác minh chỉ encoder tương ứng tăng DƯƠNG; sau đó thử trên giá đỡ, bù phải 0 và tự bù OFF. Không chạy 1m trước khi kiểm tra riêng LEFT/RIGHT. V9.0 giữ đúng cấu trúc motor đã kiểm chứng: PWM analogWrite trên ENA (GPIO13) và ENB (GPIO25), còn IN1/IN2 và IN3/IN4 chỉ đặt chiều bằng digitalWrite. Mỗi bánh có duty độc lập; khi đổi chiều, cả hai EN tắt trong deadtime 20ms.</p></section>
<section class="panel"><h2>Bù bánh PHẢI — để 0 khi kiểm tra sơ đồ chân mới</h2>
<div class="fields">
<label>Bù thêm PWM phải (0–30) <input id="assistR" type="number" value="0" min="0" max="30" step="1"></label>
<button id="assist0" type="button">Bù 0 (gốc)</button><button id="assist10" type="button">Bù +10</button>
<button id="assist20" type="button">Bù +20</button><button id="assist30" type="button">Bù +30</button>
<label class="check"><input id="autoRight" type="checkbox">Tự bù thêm cho bánh phải khi chạy đều (tối đa +20)</label>
</div>
<p class="muted">Mặc định bù 0, tự bù TẮT: điều khiển đúng như V6.2. Khi cần thử, chọn +10, +20 rồi +30 lần lượt trên GIÁ ĐỠ an toàn; giữ thông số bánh trái nguyên vẹn. Bù chỉ tác động PWM bánh phải và tuân theo giới hạn PWM=120, tốc độ tăng/giảm PWM. Tự bù chỉ hoạt động khi xe chạy đều và bánh trái bám khá sát; tự giảm khi giảm tốc.</p>
<p class="warn">Nếu PWM phải sát 120 mà bánh vẫn chậm hoặc động cơ nóng/khó quay bằng tay khi đã ngắt nguồn, DỪNG và kiểm tra cơ khí, driver, nguồn và encoder. Tăng PWM không chữa được bánh bị kẹt, còn có thể làm nóng motor.</p>
<div><small>Bù phải đang dùng (thủ công + tự động): </small><b id="balanceStatus">0 / 0 PWM</b></div></section>
<section class="panel"><div class="fields">
<label>Quãng đường tham chiếu L (m)<input id="L" type="number" value="0.15" min=".05" max="5" step=".1"></label>
<label>Vmax (m/s)<input id="V" type="number" value="0.05" min=".02" max=".15" step=".01"></label>
<label>Tăng tốc Tr (s), 0=tự tính<input id="Tr" type="number" value="2" min="0" max="120" step=".1"></label>
<button id="preview">Tính trước, không chạy</button></div>
<details><summary>Thông số nâng cao — giữ mặc định khi thử lần đầu</summary><div class="fields">
<label>Amax (m/s²)<input id="A" type="number" value=".10" min=".02" max=".25" step=".01"></label>
<label>Jmax (m/s³)<input id="J" type="number" value=".18" min=".02" max=".60" step=".01"></label>
<label>PWM nền trái (khởi động mềm)<input id="staticL" type="number" value="46" min="0" max="80" step="1"></label>
<label>Kff trái (PWM/RPM)<input id="ffL" type="number" value=".22" min="0" max="1.5" step=".01"></label>
<label>Kp trái (PWM/RPM)<input id="kpL" type="number" value="1.50" min="0" max="3" step=".05"></label>
<label>Ki trái (PWM/(RPM·s))<input id="kiL" type="number" value="1.00" min="0" max="2" step=".05"></label>
<label>PWM nền phải (khởi động mềm)<input id="staticR" type="number" value="52" min="0" max="80" step="1"></label>
<label>Kff phải (PWM/RPM)<input id="ffR" type="number" value=".22" min="0" max="1.5" step=".01"></label>
<label>Kp phải (PWM/RPM)<input id="kpR" type="number" value="1.50" min="0" max="3" step=".05"></label>
<label>Ki phải (PWM/(RPM·s))<input id="kiR" type="number" value="1.00" min="0" max="2" step=".05"></label>
<label class="check"><input id="smoothPI" type="checkbox">Thêm EMA nhân quả 60 ms sau Hybrid (tắt mặc định; Hybrid luôn dùng cho PI)</label>
<label class="check"><input id="accelFF" type="checkbox">Thử feedforward gia tốc (tắt mặc định)</label>
<label>Ka trái (PWM/(m/s²))<input id="kaL" type="number" value="0" min="0" max="80" step="1"></label>
<label>Ka phải (PWM/(m/s²))<input id="kaR" type="number" value="0" min="0" max="80" step="1"></label>

</div><p class="warn">FF gia tốc là THỬ NGHIỆM; mặc định TẮT và Ka=0. Chỉ bật sau khi đã hiệu chuẩn động cơ, kiểm tra trên giá đỡ và có ngắt nguồn phần cứng. Biên độ FF gia tốc giới hạn ±15 PWM. Không thay đổi bảo vệ dừng.</p><p class="muted">V6 điều khiển CHỈ theo vận tốc đặt: vCmdL=vCmdR=vRef. Quãng đường không tác động vào lệnh PWM; chỉ dùng để giám sát và bảo vệ. PWM giảm nhanh hơn khi vượt tốc. Các giá trị mặc định là ước lượng để thử nghiệm, KHÔNG phải hiệu chuẩn từ động cơ thật.</p></details>
<p id="plan" class="muted">Chọn L, Vmax, Tr rồi Tính trước.</p><div class="buttons">
<label class="check"><input id="motor" type="checkbox">Cho phép chạy MOTOR</label>
<button id="run" disabled>Bắt đầu S-curve</button><button id="stop" class="stop">DỪNG NGAY</button>
<button id="save">Lưu CSV + JSON</button>
    <div class="view-buttons" role="group" aria-label="Chọn tín hiệu bánh xe trên đồ thị">
      <button id="viewMean" type="button">Chỉ TB 2 bánh</button>
      <button id="viewLeft" type="button">Chỉ bánh trái</button>
      <button id="viewRight" type="button">Chỉ bánh phải</button>
      <button id="viewSeparate" type="button">Hai bánh L/R</button>
      <button id="viewAll" class="active" type="button">Hiện tất cả</button>
    </div>
<label class="check"><input id="raw" type="checkbox">Hiện tốc độ thô theo count/20ms</label>
<label class="check"><input id="periodDiag" type="checkbox">Hiện vận tốc đo chu kỳ xung Encoder</label>
<label class="check"><input id="feedback" type="checkbox">Hiện đường count-window 100ms + EMA (chẩn đoán)</label><label class="check"><input id="piSignal" type="checkbox">Hiện tốc độ PI đang sử dụng (nét đứt)</label><label class="check"><input id="command" type="checkbox">Hiện lệnh vận tốc mỗi bánh (= tham chiếu)</label>
    <label>Độ mượt đồ thị vận tốc
      <select id="displayFilter"><option value="0">Gốc, không WMA</option>
      <option value="5" selected>WMA 11 + chặn đỉnh nghi nhiễu (chỉ vẽ)</option>
      <option value="9">WMA 19 + chặn đỉnh nghi nhiễu (chỉ vẽ)</option></select>
    </label>
    <label class="check"><input id="compareOriginal" type="checkbox">So sánh đường gốc (nét đứt)</label>
<label class="check"><input id="tolerance" type="checkbox" checked>Hiện dải bám ±5% Vpeak</label>

</div><p class="warn">Luôn có ngắt nguồn motor độc lập. Đến T: cắt PWM; không chạy thêm ngoài S-curve. Nếu bánh vượt L+2cm, bảo vệ DISTANCE_GUARD vẫn cắt PWM: KHÔNG tắt an toàn để làm đẹp đồ thị. Xem trạng thái FAULT rõ ràng bên dưới. PWM=0 chỉ thả trôi.</p>
<div class="muted" id="heartbeatHealth">Wi-Fi heartbeat: chưa có lượt chạy.</div>
    <p class="muted" id="viewNote">Lựa chọn chỉ thay đổi cách hiển thị; Các nút xem chỉ đổi đồ thị; EMA bổ sung trong mục Nâng cao mới thay đổi tín hiệu PI; WMA vẫn chỉ để hiển thị.</p>
    <p id="filterNote" class="muted">Lọc hiển thị: median cục bộ 11 mẫu để đánh dấu đỉnh nghi nhiễu (ngưỡng 0,06 m/s), sau đó WMA. Đây chỉ là đường xem, KHÔNG áp dụng cho PI, số đếm, bảo vệ hoặc RMSE. Chọn count/20ms hoặc period để xem toàn bộ đỉnh đo thô. </p><div id="message"></div><pre id="fault" style="white-space:pre-wrap;color:#ff9696"></pre></section>
<section class="panel"><b>Kiểm tra encoder thủ công (motor OFF)</b><p class="muted">Ghi xung ban đầu, quay đúng một vòng bánh, rồi lấy chênh lệch xung. Nếu CPR hiệu dụng thực sự là 234 theo kiểu đọc A-RISING, chênh lệch độ lớn nên xấp xỉ 234. Không thay đổi phần điều khiển trước khi xác nhận tín hiệu encoder.</p><div>Xung tích lũy trái/phải: <b id="encoders">—</b></div></section><section class="panel stats"><div><small>Trạng thái</small><b id="state">—</b></div><div><small>Thời gian / T (s)</small><b id="time">—</b></div><div><small>Quãng đường giám sát (m)</small><b id="position">—</b></div><div><small>L − s, chỉ giám sát (m)</small><b id="error">—</b></div><div><small>PWM trái / phải</small><b id="pwm">0 / 0</b></div><div><small>RMSE Hybrid Encoder, hai bánh gộp (m/s)</small><b id="rms">—</b></div><div><small>Mẫu / mất mẫu</small><b id="samples">0 / 0</b></div></section>
<section class="panel"><h2>Vận tốc tức thời từ Encoder — Hybrid</h2><div class="stats">
<div id="liveMeanCard"><small>Trung bình hai bánh</small><b id="speedMean">—</b></div>
<div id="liveLeftCard"><small>Bánh trái</small><b id="speedLeft">—</b></div>
<div id="liveRightCard"><small>Bánh phải</small><b id="speedRight">—</b></div>
</div><p class="muted">Các số đo Hybrid Encoder trước WMA hiển thị. Đường trung bình = (vL + vR) / 2, không được dùng để che sai số riêng từng bánh.</p></section>
<section class="panel"><h2>Đánh giá bám vận tốc — từ Hybrid Encoder, KHÔNG dùng WMA</h2>
<div class="stats" id="trackingCards">
<div><small>RMSE trái (m/s)</small><b id="rmseLeft">—</b></div>
<div><small>RMSE phải (m/s)</small><b id="rmseRight">—</b></div>
<div><small>Mẫu trong ±5% Vpeak, trái / phải</small><b id="withinBand">—</b></div>
<div><small>Vọt tốc đỉnh trái / phải (% Vpeak)</small><b id="overshoot">—</b></div>
<div><small>Sai lệch trung bình có dấu, trái / phải (m/s)</small><b id="bias">—</b></div>
</div><p class="muted" id="metricNote">Chỉ đo khi chạy MOTOR, pha SCURVE và vRef ≥ 20% Vpeak; sai số tính từ Hybrid Encoder, không dùng các mẫu POST. Nếu mất mẫu mạng, kết quả trên trình duyệt chỉ là ước lượng.</p></section>
<section class="panel"><h2>Đánh giá gia tốc và jerk — suy ra từ Encoder</h2>
<div class="stats">
<div><small>RMSE gia tốc trái / phải (m/s²)</small><b id="accRmse">—</b></div>
<div><small>RMSE jerk trái / phải (m/s³)</small><b id="jerkRmse">—</b></div>
<div><small>Jerk RMS trái / phải (m/s³)</small><b id="jerkRms">—</b></div>
<div><small>|Jerk| đỉnh trái / phải (m/s³)</small><b id="jerkPeak">—</b></div>
<div><small>Mẫu hợp lệ cho a/j</small><b id="kinSamples">—</b></div>
</div><p id="kinMetricNote" class="muted">Gia tốc và jerk được ước lượng từ vị trí encoder bằng hồi quy đa thức bậc 3 trên 31 mẫu gần nhất, cập nhật trong task điều khiển 50Hz. Đây là đạo hàm động học đã làm trơn, không phải phép đo rung bằng IMU. Chỉ đánh giá khi có đủ cửa sổ mẫu hợp lệ.</p></section>
<div class="legend"><span style="color:#58a6ff">Tham chiếu</span><span style="color:#ffad60">Bánh trái (theo độ lọc đã chọn)</span><span style="color:#7bd99c">Bánh phải (theo độ lọc đã chọn)</span><span style="color:#d6a2ff">Trung bình Hybrid</span><span style="color:#d58e7d">Nét đứt: vận tốc lệnh / thô / đường lọc chậm (nếu bật)</span></div>
<section class="panel"><b>Chẩn đoán hai bánh ở đoạn vận tốc đều</b><p id="jitter" class="muted">Chưa có đủ dữ liệu chạy đều.</p><p class="muted">Độ lệch chuẩn dưới đây cho thấy mức dao động của TÍN HIỆU encoder, không kết luận độ rung cơ khí của robot. So sánh cùng một đoạn vận tốc ổn định, kiểm tra thêm vạch encoder, rung thân xe và quãng đường thực tế.</p></section>
<section class="plots">
<div class="panel"><h2>Vận tốc S-curve / bánh xe — có dải sai số ±5% · WMA chỉ để nhìn — m/s</h2><canvas id="cv" width="1050" height="500"></canvas></div>
<div class="panel"><h2>Sai số vận tốc v_ref − v_bánh (theo chế độ xem) — m/s</h2><canvas id="ce" width="1050" height="500"></canvas></div>
<div class="panel"><h2>Gia tốc S-curve / encoder — m/s²</h2><canvas id="ca" width="1050" height="420"></canvas></div>
<div class="panel"><h2>Jerk S-curve / encoder — m/s³</h2><canvas id="cj" width="1050" height="420"></canvas></div>
<div class="panel"><h2>Quãng đường — chỉ giám sát (m)</h2><canvas id="cs" width="1050" height="330"></canvas></div>
<div class="panel"><h2>PWM hai bánh — 0…120</h2><canvas id="cp" width="1050" height="330"></canvas></div>
</section><p class="muted">V9.0 Encoder-hybrid: lỗi quay ngược xác nhận từng bánh ≥0,30 s và lùi ≥8 mm; đoạn về âm >15 mm được xác nhận sau ≥0,16 s. Chọn đường count/20ms và period để xem tín hiệu thành phần. D65mm, CPR hiệu dụng giả định 234, dấu encoder L/R = +1/−1; trái A/B=GPIO18/19, phải A/B=GPIO32/35. Điều khiển task riêng danh định50Hz. Tốc độ thô count/20ms; <b>PI mặc định nhận Hybrid: đo chu kỳ A-rising ở tốc độ thấp, count-window 80–200ms ở tốc độ cao, chuyển tiếp 0,040–0,085m/s</b>; đồ thị chính mặc định dùng WMA đối xứng cho HIỂN THỊ; PI luôn nhận Hybrid qua bộ chặn xung đơn lẻ; EMA bổ sung chỉ bật khi người dùng chọn, không thay đổi bộ ước lượng gốc. Bật So sánh đường gốc để xem bộ đếm 60ms cũ; bật vận tốc chu kỳ xung để xem thành phần period; bật Hiện tốc độ PI để xem tín hiệu thực sự dùng cho điều khiển. Cửa sổ count-window 100ms + EMA vẫn lưu riêng để đối chiếu. WMA hai phía dùng mẫu cả trước và sau nên KHÔNG dùng trực tiếp trong vòng PI thời gian thực. Bộ lọc hiển thị có trễ, KHÔNG làm motor quay đều hơn; không trộn tham chiếu vào số đo. CSV giữ tốc độ count/20ms, count-window, period raw/filtered, Hybrid, legacy 60ms, tuổi xung và chế độ estimator. Vị trí không sửa vận tốc đặt: hai bánh nhận cùng một vRef. RMSE Hybrid Encoder gộp sai số từng bánh trên pha SCURVE, không tính đoạn thả trôi. Gia tốc và jerk THỰC TẾ được suy ra từ vị trí encoder từng bánh bằng fit đa thức bậc 3 nhân quả trên 31 mẫu điều khiển gần nhất (50Hz); tách đạo hàm raw và EMA nhân quả 80/160ms. Đây không phải phép đo rung thân xe như IMU. Jerk tham chiếu lấy trực tiếp từ S-curve 7 pha.</p>
</main><script>
'use strict';
const VERSION='DDMR_V9_0_MULTI_BAND_PD_SCURVE_ENCODER';
const $=id=>document.getElementById(id),rows=[];
let current=null,owned=0,displayRun=0,lastSeq=0,missing=0,awaitingRun=0,queuedAt=0,starting=false,polling=false,beating=false,metadata={},lastEncoderPoll=0;
let displayMode="all",heartbeatFailures=0,lastHbAck=0,lastPaint=0,lastPaintState="";
const PAINT_INTERVAL_MS=500;
const colors={ref:'#58a6ff',left:'#ffad60',right:'#7bd99c',mean:'#d6a2ff',rawL:'#b97844',rawR:'#4b9a76'};
const fmt=(x,n=3)=>x!==null&&x!==undefined&&Number.isFinite(Number(x))?Number(x).toFixed(n):'—';
function message(s,bad=false){$('message').textContent=s;$('message').style.color=bad?'#ff9696':'#b5e3c7';}
async function api(path,method='GET',params=null){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),1200);
  try{
    const options={method,cache:'no-store',signal:controller.signal};if(params)options.body=new URLSearchParams(params);
    const r=await fetch(path,options),q=await r.json();if(!r.ok)throw Error(q.error||r.status);return q;
  }catch(e){if(e.name==='AbortError')throw Error('ESP32 chưa phản hồi trong 1,2s');throw e;}
  finally{clearTimeout(timer);}
}
function parameters(){
  const keys=['L','V','Tr','A','J','staticL','ffL','kpL','kiL','kaL','staticR','ffR','kpR','kiR','kaR','assistR'];
  const p=Object.fromEntries(keys.map(k=>[k,Number($(k).value)]));
  const ranges={L:[.05,5],V:[.02,.15],Tr:[0,120],A:[.02,.25],J:[.02,.6],staticL:[0,80],ffL:[0,1.5],kpL:[0,3],kiL:[0,2],kaL:[0,80],staticR:[0,80],ffR:[0,1.5],kpR:[0,3],kiR:[0,2],kaR:[0,80],assistR:[0,30]};
  for(const k of keys)if(!$(k).value.trim()||!Number.isFinite(p[k])||p[k]<ranges[k][0]||p[k]>ranges[k][1])throw Error('Kiểm tra thông số '+k);
  p.accelFF=$('accelFF').checked?'1':'0';
  p.smoothPI=$('smoothPI').checked?'1':'0';
  p.autoRight=$('autoRight').checked?'1':'0';
  return p;
}
for(const n of [0,10,20,30])$('assist'+n).onclick=()=>{
  $('assistR').value=String(n);message('Bù PWM phải +'+n+' sẽ áp dụng từ lần chạy kế tiếp. Bánh trái giữ nguyên.');
};
function showPlan(q){$('plan').textContent=`L=${fmt(q.L)}m · T S-curve=${fmt(q.T)}s · Tr=${fmt(q.Tr)}s · Vpeak=${fmt(q.vPeak)}m/s · Apeak=${fmt(q.aPeak,4)}m/s² · Jpeak=${fmt(q.jPeak)}m/s³. Không tự đổi các giới hạn đã nhập.`;}
async function stop(){owned=awaitingRun=0;try{await api('/stop','POST');message('Đã gửi yêu cầu DỪNG; chờ phản hồi trạng thái. PWM=0 vẫn có thể thả trôi.');}catch(e){message('Không xác nhận được DỪNG qua Wi-Fi. Dùng công tắc ngắt nguồn. '+e.message,true);}}
$('stop').onclick=stop;
$('preview').onclick=async()=>{try{showPlan(await api('/preview','POST',parameters()));}catch(e){message(e.message,true);}};
$('run').onclick=async()=>{
  if(starting||awaitingRun||current?.busy){message('Đợi hết lượt hoặc bấm Dừng.',true);return;}
  try{
    if(current?.version!==VERSION)throw Error('Sai firmware; nạp V9.0 Encoder-hybrid và tải lại trang.');
    const p=parameters(),motor=$('motor').checked;
    if(motor&&!confirm('Xe sẽ chạy sau 1 giây. Đã có khoảng trống, đúng chiều bánh/encoder và công tắc ngắt nguồn?'))return;
    starting=true;$('run').disabled=true;
    let q;try{q=await api('/run','POST',{...p,motor:motor?'1':'0',confirm:'YES'});}
    catch(e){await stop();throw Error('Không xác nhận được lệnh chạy; đã thử gửi DỪNG. Dùng ngắt nguồn nếu xe chưa dừng. '+e.message);}
    owned=displayRun=awaitingRun=q.runId;queuedAt=Date.now();rows.length=0;lastSeq=missing=0;
    heartbeatFailures=0;lastHbAck=Date.now();lastPaint=0;
    metadata={version:VERSION,runId:displayRun,requested:p,plan:q,motorRequested:motor,diameter_m:.065,effectiveCPR:234,
      encoderSigns:[1,-1],controlHzNominal:50,speedFilterTau_s:.080,encoderWindowSamples:5,encoderWindowNominal_s:.100,motorMapping:'ENA13=RIGHT; ENB25=LEFT',encoderMapping:'LEFT18/19(+); RIGHT32/35(-)',feedbackWindowSamples:3,feedbackWindowNominal_s:.060,pwmLimit:120,forwardOnly:true,
      controlMode:'SPEED_ONLY',positionFeedback:false,controller:'V9.0 Encoder-hybrid: V6.8 DRAM-fixed baseline PI and adaptive 80-200ms + causal EMA retained. Encoder-derived a/j are a causal cubic least-squares fit to the latest 31 control-rate position samples.',
       encoderKinematics:{method:'causal cubic least-squares fit of wheel position from encoder counts',windowSamples:31,controlRateHz:50,derivativesAt:'latest sample',outputs:['aEncL','aEncR','jEncL','jEncR'],rawOutputs:['aEncRawL','aEncRawR','jEncRawL','jEncRawR'],filterTau_s:{acceleration:.08,jerk:.16},reference:['aRef','jRef'],imuUsed:false,interpretation:'filtered and raw wheel-kinematic derivatives; not chassis vibration or direct accelerometer measurements'},
      piSpeedMode:p.smoothPI==='1'?'HYBRID_PERIOD_COUNT_BLEND_PLUS_CAUSAL_EMA_60MS':'HYBRID_PERIOD_COUNT_BLEND',
      speedEstimator:{method:'low-speed edge-period + high-speed causal count-window blend',edge:'A-rising',periodLowSpeedTau_s:.05,periodStaleTimeout_s:'clamp(3*period,0.12,0.50)',countWindowTarget:8,countWindowMin_s:.08,countWindowMax_s:.20,blendStart_mps:.040,blendFull_mps:.085,controlRateHz:50},
      optionalPiEmaTau_s:.06,
      rightLoadBalance:{manualPwm:p.assistR,adaptiveEnabled:p.autoRight==='1',adaptiveCapPwm:20,manualCapPwm:30,pwmTotalCap:120,leftControllerUnchanged:true},
      wheelFeedforward:{staticL:p.staticL,ffL:p.ffL,kpL:p.kpL,kiL:p.kiL,kaL:p.kaL,staticR:p.staticR,ffR:p.ffR,kpR:p.kpR,kiR:p.kiR,kaR:p.kaR,accelFF:p.accelFF,pwmRise_per_s:150,pwmFall_per_s:420,identified:false},
      pwmOffAt:'first control tick at/after T',distanceGuardExtra_m:.02,postRecord_s:2,absolutePositionValidated:false,
      note:'V9.0: hybrid edge-period/count-window velocity estimator is default PI feedback; legacy 20ms/60ms/100ms count estimators retained for diagnostics; raw and EMA-filtered causal cubic acceleration/jerk logged separately; reverse and Wi-Fi guards unchanged.' ,created:new Date().toISOString()};
    showPlan(q);drawAll();message(motor?'Đã nhận lệnh. Chờ bánh đứng yên 1s rồi chạy.':'Chỉ ghi tham chiếu/encoder, PWM giữ0.');
  }catch(e){message(e.message,true);}finally{starting=false;}
};
// A missed HTTP response must NOT trigger an unnecessary browser-side STOP.
// The ESP32 itself still removes PWM and reports WEB_HEARTBEAT_LOST when
// there is no valid heartbeat for >1.5s. Do not mask a real network outage.
async function heartbeat(){
  if(!owned||beating)return;
  beating=true;
  try{
    await api('/heartbeat','POST',{runId:owned});
    lastHbAck=Date.now();heartbeatFailures=0;
    $('heartbeatHealth').textContent='Heartbeat OK (đã xác nhận bởi ESP32).';
  }catch(e){
    heartbeatFailures++;
    $('heartbeatHealth').textContent='Heartbeat chưa xác nhận '+heartbeatFailures+' lần: '
      +e.message+'. ESP32 sẽ TỰ DỪNG nếu mất heartbeat >1,5s.';
    // Never suppress the server-side fail-safe, and never auto-restart.
  }finally{beating=false;}
}
function accept(batch){
  for(const row of batch){if(row.seq<=lastSeq)continue;if(row.seq>lastSeq+1)missing+=row.seq-lastSeq-1;lastSeq=row.seq;
    const kv=Number(row.kinValid)===1;
    rows.push({...row,evL:row.vRef-row.vL,evR:row.vRef-row.vR,
      aEncPlotL:kv?Number(row.aEncL):NaN,aEncPlotR:kv?Number(row.aEncR):NaN,
      jEncPlotL:kv?Number(row.jEncL):NaN,jEncPlotR:kv?Number(row.jEncR):NaN,
      aEncMean:kv?(Number(row.aEncL)+Number(row.aEncR))*.5:NaN,
      jEncMean:kv?(Number(row.jEncL)+Number(row.jEncR))*.5:NaN});}
}
async function poll(){
  if(polling)return;polling=true;
  try{
    current=await api('/data');if(current.version!==VERSION)throw Error('Sai firmware. Nạp V9.0 Encoder-hybrid rồi tải lại trang.');
    $('connection').textContent='Đã kết nối · '+VERSION;
    if(!current.busy&&Date.now()-lastEncoderPoll>1000){lastEncoderPoll=Date.now();try{const enc=await api('/encoders');$('encoders').textContent=enc.left+' / '+enc.right;}catch(_){$('encoders').textContent='—';}}
    $('state').textContent=current.state;$('time').textContent=fmt(current.t,2)+' / '+fmt(current.T,2);
    $('position').textContent=fmt(current.s);$('error').textContent=current.runId?fmt(current.L-current.s):'—';
    $('pwm').textContent=current.pwmL+' / '+current.pwmR;$('rms').textContent=fmt(current.rmsV,4);
    $('speedMean').textContent=fmt((current.vL+current.vR)/2,4)+' m/s';
    $('speedLeft').textContent=fmt(current.vL,4)+' m/s';
    $('speedRight').textContent=fmt(current.vR,4)+' m/s';
    $('heartbeatHealth').textContent=(heartbeatFailures>0&&current.busy)?('CẢNH BÁO: chưa nhận được '+heartbeatFailures+' heartbeat liên tiếp; ESP32 tự dừng sau 1500 ms nếu mất kết nối.'):(current.busy?'Heartbeat '+fmt(current.heartbeatAgeMs,0)+' ms từ lần cuối | thiết bị Wi-Fi: '+current.apClients+' | tự dừng sau 1500 ms nếu mất tín hiệu':'Wi-Fi sẵn sàng | thiết bị kết nối: '+current.apClients);
    $('balanceStatus').textContent=fmt(current.assistR,1)+' / '+fmt(current.autoR,1)+' PWM';
    // A network timeout must NOT erase the last known fault from the ESP32.
    $('fault').textContent=current.fault?'FAULT / STOP: '+current.fault+'\n'+current.detail+'\nPWM đã được yêu cầu về 0; không bỏ bảo vệ.':'';
    if(metadata&&displayRun&&current.runId===displayRun)metadata.logIntervalMs=current.logIntervalMs;
    if(displayRun&&current.runId===displayRun)awaitingRun=0;
    $('run').disabled=starting||!!awaitingRun||current.busy;$('preview').disabled=starting||!!awaitingRun||current.busy;
    if(displayRun&&displayRun===current.runId){
      for(let k=0;k<2;k++){
        const q=await api('/samples?runId='+displayRun+'&after='+lastSeq);accept(q.rows);
        if(q.rows.length<12)break;
      }
      // On Android, redrawing every 200ms may block the heartbeat timer.
      // Live telemetry text is refreshed each poll; heavy canvas only 2Hz.
      if(Date.now()-lastPaint>PAINT_INTERVAL_MS||current.state!==lastPaintState){
        drawAll();lastPaint=Date.now();lastPaintState=current.state;
      }
      if(!current.busy&&lastSeq>=current.seq){
        metadata.result={...current};metadata.logComplete=missing===0;
        metadata.referenceCompleted=current.state==='FINISHED'&&current.t>=current.T;
        metadata.recordComplete=metadata.logComplete&&metadata.referenceCompleted;
        metadata.endpointSuccess=null; // Not a position controller: never claim endpoint success.
        metadata.trackingValidated=false;
        owned=0;
        if(current.state==='FINISHED'){
          if(!metadata.motorRequested)message('Lượt chỉ ghi dữ liệu đã xong; PWM0 nên không đánh giá bám/điểm cuối.');
          else message('Đã hết S-curve. Lệnh đặt bằng vRef cho cả hai bánh. Xem RMSE vận tốc và lưu CSV; FINISHED không đồng nghĩa bám đúng.');
        }
      }
    }else if(displayRun&&displayRun!==current.runId){
      if(awaitingRun===displayRun&&Date.now()-queuedAt<1500)message('Lệnh đã gửi, đang chờ task điều khiển nhận lượt mới.');
      else {owned=awaitingRun=0;message('ESP32 đang ở lượt khác hoặc chưa nhận lượt mới. Không tự chạy lại.',true);}
    }
  }catch(e){$('connection').textContent='Chưa nhận phản hồi mới';$('run').disabled=true;message(e.message,true);}
  finally{polling=false;}
}
function chart(id,series,unit,data=rows,options={}){
  const c=$(id),g=c.getContext('2d'),w=c.width,h=c.height,p={l:80,r:20,t:22,b:40};
  g.clearRect(0,0,w,h);let end=1,lo=0,hi=0;
  for(const row of data){end=Math.max(end,row.t);for(const s of series)if(Number.isFinite(row[s.key])){lo=Math.min(lo,row[s.key]);hi=Math.max(hi,row[s.key]);}}
  if(options.band&&Number.isFinite(options.tol))for(const r of data)if(r.stage===2&&Number.isFinite(r.vRef))hi=Math.max(hi,r.vRef+options.tol);
  if(hi-lo<1.e-6){hi+=.1;lo-=.1;}const m=(hi-lo)*.12;lo-=m;hi+=m;
  const X=x=>p.l+x/end*(w-p.l-p.r),Y=y=>h-p.b-(y-lo)/(hi-lo)*(h-p.t-p.b);
  g.font='16px system-ui';g.fillStyle='#b1c0d0';g.strokeStyle='#34475a';g.lineWidth=1;
  for(let i=0;i<=4;i++){const y=p.t+i*(h-p.t-p.b)/4;g.beginPath();g.moveTo(p.l,y);g.lineTo(w-p.r,y);g.stroke();g.fillText((hi-i*(hi-lo)/4).toFixed(3),2,y+5);}
  for(let i=0;i<=5;i++){const x=p.l+i*(w-p.l-p.r)/5;g.beginPath();g.moveTo(x,p.t);g.lineTo(x,h-p.b);g.stroke();g.fillText((i*end/5).toFixed(1),x-12,h-12);}
  g.fillText(unit,4,16);g.fillText('t (s)',w-50,h-2);
  // Transparent constant-width tolerance band, only while SCURVE is running.
  // This band is a visual criterion; never fed to the controller or to RMSE.
  if(options.band&&Number.isFinite(options.tol)&&options.tol>0){
    g.save();g.fillStyle='rgba(88,166,255,0.18)';
    for(let i=1;i<data.length;i++){
      const a=data[i-1],b=data[i];
      if(a.stage!==2||b.stage!==2||b.seq!==a.seq+1||!Number.isFinite(a.vRef)||!Number.isFinite(b.vRef))continue;
      g.beginPath();g.moveTo(X(a.t),Y(a.vRef+options.tol));g.lineTo(X(b.t),Y(b.vRef+options.tol));
      g.lineTo(X(b.t),Y(Math.max(0,b.vRef-options.tol)));
      g.lineTo(X(a.t),Y(Math.max(0,a.vRef-options.tol)));g.closePath();g.fill();
    }g.restore();
  }
  // Visual marker: safety stop is a FAULT, never treated as normal S-curve deceleration.
  const stopRow=data.find(r=>r.stage===6||r.stage===7);
  if(stopRow){const fx=X(stopRow.t);g.save();g.setLineDash([5,5]);g.strokeStyle='#ff5c75';g.beginPath();g.moveTo(fx,p.t);g.lineTo(fx,h-p.b);g.stroke();g.setLineDash([]);g.fillStyle='#ff8998';g.fillText('DỪNG DO LỖI / STOP',Math.max(p.l+5,Math.min(fx+8,w-230)),p.t+18);g.restore();}
  for(const s of series){g.strokeStyle=s.color;g.lineWidth=2.5;g.setLineDash(s.dash||[]);g.beginPath();let prior=null;
    for(const q of data){if(!Number.isFinite(q[s.key])){prior=null;continue;}if(prior===null)g.moveTo(X(q.t),Y(q[s.key]));else g.lineTo(X(q.t),Y(q[s.key]));prior=q;}
    g.stroke();}g.setLineDash([]);
}
// Display-only, zero-phase triangular weighted moving average.
// Do NOT use this centered filter for live PI: it uses samples on both sides
// of the timestamp and would introduce noncausal feedback latency.
// Stage boundaries, large missing-data gaps, and FAULT/STOP are not blurred.
function triangularWMA(data,key,radius){
  if(radius===0)return data.map(r=>Number(r[key]));
  const smoothed=new Array(data.length);
  const segment=new Array(data.length);
  let group=0;
  for(let i=0;i<data.length;i++){
    if(i>0&&(data[i].stage!==data[i-1].stage||
        data[i].seq!==data[i-1].seq+1||
        !Number.isFinite(data[i].t)||!Number.isFinite(data[i-1].t)||
        data[i].t<data[i-1].t))group++;
    segment[i]=group;
  }
  const maxDt=0.026*(radius+1); // Slight tolerance for 20ms scheduler jitter.
  for(let i=0;i<data.length;i++){
    const center=data[i];let sum=0,weightSum=0;
    for(let j=Math.max(0,i-radius);j<=Math.min(data.length-1,i+radius);j++){
      const q=data[j], v=Number(q[key]);
      if(segment[j]!==segment[i]||!Number.isFinite(v)||
         !Number.isFinite(q.t)||!Number.isFinite(center.t)||
         Math.abs(q.t-center.t)>maxDt)continue;
      const weight=radius+1-Math.abs(j-i);
      sum+=weight*v;weightSum+=weight;
    }
    smoothed[i]=weightSum?sum/weightSum:Number(center[key]);
  }
  return smoothed;
}
// DISPLAY ONLY: identify isolated departures from a local time/phase-safe
// median, without changing feedback to PI, raw counts or official RMSE.
// This is a *suspected outlier*, not proof of sensor noise. 0.06 m/s is
// deliberately above several quantization steps of the 60ms count window.
function displayMedianFlags(data,key){
  const values=[],flags=[];
  const radius=5,limit=0.060;
  for(let i=0;i<data.length;i++){
    const c=data[i],neighbors=[];
    for(let j=Math.max(0,i-radius);j<=Math.min(data.length-1,i+radius);j++){
      const q=data[j];
      if(q.stage!==c.stage||Math.abs(q.seq-c.seq)>radius||
         !Number.isFinite(q.t)||!Number.isFinite(c.t)||
         Math.abs(q.t-c.t)>0.125||!Number.isFinite(Number(q[key])))continue;
      neighbors.push(Number(q[key]));
    }
    neighbors.sort((a,b)=>a-b);
    const v=Number(c[key]);
    const median=neighbors.length>=5?neighbors[Math.floor(neighbors.length/2)]:v;
    const suspected=neighbors.length>=5&&Number.isFinite(v)&&Math.abs(v-median)>limit;
    values.push(suspected?median:v);
    flags.push(suspected?1:0);
  }
  return {values,flags};
}
function makeDisplayRows(data,radius){
  const cL=displayMedianFlags(data,'vL');
  const cR=displayMedianFlags(data,'vR');
  // The original signal is untouched when the filter is set to GOC.
  const tmp=data.map((q,i)=>({...q,vCleanDisplayL:cL.values[i],vCleanDisplayR:cR.values[i]}));
  const l=radius===0?data.map(q=>q.vL):triangularWMA(tmp,'vCleanDisplayL',radius);
  const r=radius===0?data.map(q=>q.vR):triangularWMA(tmp,'vCleanDisplayR',radius);
  return data.map((q,i)=>({...q,vPlotL:l[i],vPlotR:r[i],
    suspectL:cL.flags[i],suspectR:cR.flags[i],
    vCleanDisplayL:cL.values[i],vCleanDisplayR:cR.values[i],
    vPlot:(l[i]+r[i])/2,
    pwmMean:(q.pwmL+q.pwmR)/2,
    evPlotMean:q.vRef-(l[i]+r[i])/2,
    evPlotL:q.vRef-l[i],evPlotR:q.vRef-r[i]}));
}
function standardDeviation(arr){
  if(arr.length<2)return NaN;
  const mean=arr.reduce((a,b)=>a+b,0)/arr.length;
  return Math.sqrt(arr.reduce((sum,x)=>sum+(x-mean)**2,0)/(arr.length-1));
}
function showJitter(){
  const peak=Number(metadata?.plan?.vPeak);
  if(!Number.isFinite(peak)||peak<=0){$('jitter').textContent='Chưa có dữ liệu S-curve.';return;}
  const flat=rows.filter(r=>r.stage===2&&r.vRef>=.98*peak);
  if(flat.length<25){$('jitter').textContent='Chưa đủ 25 mẫu tại vận tốc gần Vpeak để đánh giá dao động tín hiệu.';return;}
  const s=(key)=>fmt(standardDeviation(flat.map(r=>r[key]).filter(Number.isFinite)),4);
  const mean=k=>flat.reduce((sum,r)=>sum+(Number(r[k])||0),0)/flat.length;
  const ref=mean('vRef'), vl=mean('vL'),vr=mean('vR'),pl=mean('pwmL'),pr=mean('pwmR');
  const per=x=>(100*x/ref).toFixed(1)+'%';
  $('jitter').textContent=`${flat.length} mẫu chạy đều · v_ref=${fmt(ref,4)}m/s
Bánh TRÁI: v=${fmt(vl,4)} (${per(vl)} mục tiêu), PWM TB=${fmt(pl,1)} · Bánh PHẢI: v=${fmt(vr,4)} (${per(vr)} mục tiêu), PWM TB=${fmt(pr,1)}
Chênh lệch hai bánh=${fmt(Math.abs(vl-vr),4)}m/s; eL=${fmt(ref-vl,4)}, eR=${fmt(ref-vr,4)}m/s
Độ lệch chuẩn count/20ms L/R=${s('vRawL')}/${s('vRawR')}; Hybrid PI=${s('vFbL')}/${s('vFbR')}; count EMA=${s('vSmoothL')}/${s('vSmoothR')}m/s.
Nếu PWM phải cao nhưng v phải vẫn thấp, kiểm tra tải/motor/encoder/CPR trước khi tăng gain; không nhầm đường đẹp với tốc độ thực sự ổn định.`;
}
// Evaluation is deliberately based on the HYBRID PI feedback, not
// on display-only centered WMA. Time-weighting corrects small scheduler jitter.
function trackingMetrics(data,peak){
  const valid=Number.isFinite(peak)&&peak>0;
  const samples=valid?data.filter(r=>r.stage===2&&r.vRef>=.2*peak&&
      Number.isFinite(r.vFbL)&&Number.isFinite(r.vFbR)&&Number.isFinite(r.dt)&&r.dt>0&&r.dt<=.060):[];
  let sum=0,sqL=0,sqR=0,biasL=0,biasR=0,inL=0,inR=0,overL=0,overR=0;
  const tolerance=peak*.05;
  // On-device 50Hz control remains unchanged; log rate can be 25Hz or
  // lower for long runs. Weight metrics using the actual *logged* time
  // spacing rather than controller dt (which stays around 20ms).
  const nominalLogDt=(typeof metadata!=='undefined' && Number(metadata?.logIntervalMs)>0)
    ?Number(metadata.logIntervalMs)/1000:0.04;
  for(let i=0;i<samples.length;i++){
    const r=samples[i];
    const gap=i>0?r.t-samples[i-1].t:nominalLogDt;
    // Do not pretend absent Wi-Fi samples were measured: cap large gaps.
    const w=Number.isFinite(gap)&&gap>0?Math.min(gap,1.5*nominalLogDt):nominalLogDt;
    const eL=r.vFbL-r.vRef,eR=r.vFbR-r.vRef;
    sum+=w;sqL+=w*eL*eL;sqR+=w*eR*eR;
    biasL+=w*eL;biasR+=w*eR;
    if(Math.abs(eL)<=tolerance)inL+=w;
    if(Math.abs(eR)<=tolerance)inR+=w;
    overL=Math.max(overL,eL);overR=Math.max(overR,eR);
  }
  if(!sum)return null;
  return {samples:samples.length,seconds:sum,tolerance,
    rmseL:Math.sqrt(sqL/sum),rmseR:Math.sqrt(sqR/sum),
    pctL:100*inL/sum,pctR:100*inR/sum,
    overL:100*overL/peak,overR:100*overR/peak,
    biasL:biasL/sum,biasR:biasR/sum};
}
function updateTrackingMetrics(){
  const peak=Number(metadata?.plan?.vPeak),m=trackingMetrics(rows,peak);
  const valid=metadata.motorRequested&&m&&rows.length>=10;
  $('rmseLeft').textContent=valid?fmt(m.rmseL,4):'—';
  $('rmseRight').textContent=valid?fmt(m.rmseR,4):'—';
  $('withinBand').textContent=valid?`${fmt(m.pctL,1)}% / ${fmt(m.pctR,1)}%`:'—';
  $('overshoot').textContent=valid?`${fmt(m.overL,1)}% / ${fmt(m.overR,1)}%`:'—';
  $('bias').textContent=valid?`${fmt(m.biasL,4)} / ${fmt(m.biasR,4)}`:'—';
  const mode=metadata.motorRequested?'MOTOR bật':'MOTOR tắt (không đánh giá bám)';
  $('metricNote').textContent=valid?`${mode} · ${m.samples} mẫu (${fmt(m.seconds,2)}s), chuẩn ±${fmt(m.tolerance,4)} m/s theo Vpeak. Chỉ SCURVE, vRef ≥ 20% Vpeak; không WMA; ${missing?`MẤT ${missing} mẫu qua Wi-Fi, chỉ ước lượng`: 'không phát hiện mất mẫu'}. Vọt tốc đo từ Hybrid Encoder.`
  :`${mode}. Chưa đủ dữ liệu để tính RMSE từng bánh. Chỉ đo khi SCURVE và vRef ≥ 20% Vpeak.`;
  return valid?m:null;
}
function encoderKinematicMetrics(data){
  const valid=data.filter(r=>r.stage===2&&Number(r.kinValid)===1&&
    Number.isFinite(r.aRef)&&Number.isFinite(r.jRef)&&
    Number.isFinite(r.aEncL)&&Number.isFinite(r.aEncR)&&
    Number.isFinite(r.jEncL)&&Number.isFinite(r.jEncR));
  if(valid.length<8)return null;
  const nominal=(Number(metadata?.logIntervalMs)>0?Number(metadata.logIntervalMs)/1000:.04);
  let total=0,sqaL=0,sqaR=0,sqjL=0,sqjR=0,j2L=0,j2R=0,peakL=0,peakR=0;
  for(let i=0;i<valid.length;i++){
    const r=valid[i],gap=i? r.t-valid[i-1].t:nominal;
    if(!Number.isFinite(gap)||gap<=0)continue;
    const weight=Math.min(gap,1.5*nominal);
    const eaL=r.aEncL-r.aRef,eaR=r.aEncR-r.aRef;
    const ejL=r.jEncL-r.jRef,ejR=r.jEncR-r.jRef;
    total+=weight;sqaL+=weight*eaL*eaL;sqaR+=weight*eaR*eaR;
    sqjL+=weight*ejL*ejL;sqjR+=weight*ejR*ejR;
    j2L+=weight*r.jEncL*r.jEncL;j2R+=weight*r.jEncR*r.jEncR;
    peakL=Math.max(peakL,Math.abs(r.jEncL));peakR=Math.max(peakR,Math.abs(r.jEncR));
  }
  if(total<=0)return null;
  return {samples:valid.length,seconds:total,
    accelRmseL:Math.sqrt(sqaL/total),accelRmseR:Math.sqrt(sqaR/total),
    jerkRmseL:Math.sqrt(sqjL/total),jerkRmseR:Math.sqrt(sqjR/total),
    jerkRmsL:Math.sqrt(j2L/total),jerkRmsR:Math.sqrt(j2R/total),
    jerkPeakL:peakL,jerkPeakR:peakR};
}
function updateEncoderKinematicMetrics(){
  const m=encoderKinematicMetrics(rows),ok=metadata.motorRequested&&m;
  $('accRmse').textContent=ok?`${fmt(m.accelRmseL,3)} / ${fmt(m.accelRmseR,3)}`:'—';
  $('jerkRmse').textContent=ok?`${fmt(m.jerkRmseL,3)} / ${fmt(m.jerkRmseR,3)}`:'—';
  $('jerkRms').textContent=ok?`${fmt(m.jerkRmsL,3)} / ${fmt(m.jerkRmsR,3)}`:'—';
  $('jerkPeak').textContent=ok?`${fmt(m.jerkPeakL,3)} / ${fmt(m.jerkPeakR,3)}`:'—';
  $('kinSamples').textContent=m?String(m.samples):'—';
  $('kinMetricNote').textContent=ok
    ?`Encoder-only · ${m.samples} mẫu hợp lệ (${fmt(m.seconds,2)}s) · fit bậc 3 nhân quả 31 mẫu ở 50Hz (~0,6s); a/j hiển thị qua EMA nhân quả 80/160ms; CSV giữ cả đạo hàm raw · log lưu ${fmt(metadata.logIntervalMs||40,0)}ms. Nếu log >80ms, đồ thị jerk bị lấy mẫu thưa; nên dùng lượt ngắn cho nghiên cứu. ${missing?'Mất '+missing+' mẫu lưu qua Wi-Fi; số liệu trình duyệt có thể thiếu.':'Không phát hiện thiếu mẫu lưu.'} Không diễn giải jerk encoder thành rung động thân xe.`
    :`Chưa đủ mẫu hợp lệ hoặc MOTOR đang tắt. Cần tối thiểu 8 mẫu kinValid trong pha SCURVE; các mẫu đầu tiên chưa có đủ cửa sổ 11 điểm sẽ bị loại.`;
  return ok?m:null;
}
function drawAll(){
  const ref=key=>({key,color:colors.ref}),left=key=>({key,color:colors.left}),right=key=>({key,color:colors.right}),mean=key=>({key,color:colors.mean,dash:[6,4]});
  const showMean=displayMode==='mean'||displayMode==='all';
  const showLeft=displayMode==='left'||displayMode==='separate'||displayMode==='all';
  const showRight=displayMode==='right'||displayMode==='separate'||displayMode==='all';
  const radius=Number($('displayFilter').value);
  const displayRows=makeDisplayRows(rows,radius);
  $('filterNote').textContent=radius===0
    ?'Đang hiện vận tốc Hybrid Encoder (chu kỳ xung ở tốc độ thấp + count-window ở tốc độ cao), trước PI. Đường gốc 60ms có thể bật để so sánh.'
    :`WMA ${radius*2+1} + median chặn đỉnh nghi nhiễu trên ĐỒ THỊ. Mẫu nghi nhiễu L/R: ${displayRows.reduce((n,r)=>n+r.suspectL,0)}/${displayRows.reduce((n,r)=>n+r.suspectR,0)}. KHÔNG đổi PI, số đếm, bảo vệ, RMSE hoặc CSV gốc. Đây chỉ là cách HIỂN THỊ.`;
  chart('cs',[ref('sRef'),...(showMean?[mean('s')]:[]),...(showLeft?[left('sL')]:[]),...(showRight?[right('sR')]:[])],'m');
  const cmds=$('command').checked?[...(showLeft?[{key:'vCmdL',color:'#ff7d2a',dash:[9,6]}]:[]),...(showRight?[{key:'vCmdR',color:'#42dc8f',dash:[9,6]}]:[])]:[];
  const raw=$('raw').checked?[...(showLeft?[{key:'vRawL',color:colors.rawL,dash:[4,6]}]:[]),...(showRight?[{key:'vRawR',color:colors.rawR,dash:[4,6]}]:[])]:[];
  const periodDiag=$('periodDiag').checked?[...(showLeft?[{key:'vPeriodFiltL',color:'#f0a35c',dash:[3,3]}]:[]),...(showRight?[{key:'vPeriodFiltR',color:'#8bd5ca',dash:[3,3]}]:[])]:[];
  const feedback=$('feedback').checked?[...(showLeft?[{key:'vSmoothL',color:'#ffd099',dash:[6,6]}]:[]),...(showRight?[{key:'vSmoothR',color:'#b0f0c9',dash:[6,6]}]:[])]:[];
  const piPlot=$('piSignal').checked?[...(showLeft?[{key:'vPiL',color:'#f59e0b',dash:[7,4]}]:[]),...(showRight?[{key:'vPiR',color:'#10b981',dash:[7,4]}]:[])]:[];
  const original=$('compareOriginal').checked&&radius>0?
    [...(showLeft?[{key:'vLegacyL',color:'#a36535',dash:[2,5]}]:[]),...(showRight?[{key:'vLegacyR',color:'#3c815b',dash:[2,5]}]:[])]:[];
  const peak=Number(metadata?.plan?.vPeak),showBand=$('tolerance').checked&&Number.isFinite(peak)&&peak>0;
  chart('cv',[ref('vRef'),...(showMean?[mean('vPlot')]:[]),...(showLeft?[left('vPlotL')]:[]),...(showRight?[right('vPlotR')]:[]),...original,...cmds,...raw,...periodDiag,...feedback,...piPlot],'m/s',displayRows,{band:showBand,tol:peak*.05});
  chart('ce',[...(showMean?[mean('evPlotMean')]:[]),...(showLeft?[left('evPlotL')]:[]),...(showRight?[right('evPlotR')]:[])],'m/s',displayRows);
  chart('ca',[ref('aRef'),...(showMean?[mean('aEncMean')]:[]),...(showLeft?[left('aEncPlotL')]:[]),...(showRight?[right('aEncPlotR')]:[])],'m/s²',rows);
  chart('cj',[ref('jRef'),...(showMean?[mean('jEncMean')]:[]),...(showLeft?[left('jEncPlotL')]:[]),...(showRight?[right('jEncPlotR')]:[])],'m/s³',rows);
  chart('cp',[...(showMean?[mean('pwmMean')]:[]),...(showLeft?[left('pwmL')]:[]),...(showRight?[right('pwmR')]:[])],'PWM',displayRows);
  $('liveMeanCard').classList.toggle('is-hidden',!showMean);
  $('liveLeftCard').classList.toggle('is-hidden',!showLeft);
  $('liveRightCard').classList.toggle('is-hidden',!showRight);
  for(const [name,mode] of [['viewMean','mean'],['viewLeft','left'],['viewRight','right'],['viewSeparate','separate'],['viewAll','all']])
    $(name).classList.toggle('active',displayMode===mode);
  $('viewNote').textContent='Hiển thị: '+({mean:'trung bình hai bánh',left:'chỉ bánh trái',right:'chỉ bánh phải',separate:'riêng từng bánh L/R',all:'trung bình và từng bánh'}[displayMode])+'; chỉ thay đổi đồ thị, KHÔNG thay đổi PI, an toàn hay CSV.';
  $('samples').textContent=rows.length+' / '+missing;showJitter();updateTrackingMetrics();updateEncoderKinematicMetrics();
}
for(const [name,mode] of [['viewMean','mean'],['viewLeft','left'],['viewRight','right'],['viewSeparate','separate'],['viewAll','all']])
  $(name).onclick=()=>{displayMode=mode;drawAll();};
$('raw').onchange=drawAll;
$('periodDiag').onchange=drawAll;
$('feedback').onchange=drawAll;
$('piSignal').onchange=drawAll;
$('command').onchange=drawAll;
$('displayFilter').onchange=drawAll;
$('compareOriginal').onchange=drawAll;
$('tolerance').onchange=drawAll;
function download(name,text,type){const u=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
$('save').onclick=()=>{
  if(current?.busy||starting){message('Đợi ghi xong sau dừng trước khi lưu.',true);return;}
  if(!rows.length){message('Chưa có mẫu để lưu.',true);return;}
  const keys=['seq','t','tmRaw','dt','sRef','vRef','aRef','jRef','aEncL','aEncR','aEncMean','jEncL','jEncR','jEncMean','aEncRawL','aEncRawR','jEncRawL','jEncRawR','kinValid','sL','sR','s','vL','vR','v','vRawL','vRawR','vWindowL','vWindowR','vLegacyL','vLegacyR','vPeriodL','vPeriodR','vPeriodFiltL','vPeriodFiltR','vHybridL','vHybridR','pulseAgeL','pulseAgeR','speedModeL','speedModeR','vSmoothL','vSmoothR','vFbL','vFbR','vPiL','vPiR','vAdaptiveL','vAdaptiveR','adaptiveWinL','adaptiveWinR','piRejectL','piRejectR','vCmdL','vCmdR','eL','eR','ffL','ffR','iL','iR','assistR','autoR','pwmL','pwmR','countL','countR','phase','stage'];
  const name='ddmr_scurve_v7_3_encoder_hybrid_'+displayRun;
  // Additional WMA columns are diagnostic/display-only; never replace raw measurements.
  const w11=makeDisplayRows(rows,5),w19=makeDisplayRows(rows,9);
  const extras=['vWma11L','vWma11R','vWma19L','vWma19R','suspectL','suspectR','vCleanDisplayL','vCleanDisplayR'];
  const csvKeys=keys.concat(extras);
  const exportRows=rows.map((r,i)=>({...r,vWma11L:w11[i].vPlotL,vWma11R:w11[i].vPlotR,
    vWma19L:w19[i].vPlotL,vWma19R:w19[i].vPlotR,
    suspectL:w11[i].suspectL,suspectR:w11[i].suspectR,
    vCleanDisplayL:w11[i].vCleanDisplayL,vCleanDisplayR:w11[i].vCleanDisplayR}));
  download(name+'.csv',csvKeys.join(',')+'\n'+exportRows.map(r=>csvKeys.map(k=>r[k]??'').join(',')).join('\n'),'text/csv;charset=utf-8');
  download(name+'.json',JSON.stringify({...metadata,trackingMetricsHybrid:trackingMetrics(rows,Number(metadata?.plan?.vPeak)),encoderKinematicMetrics:encoderKinematicMetrics(rows),samples:rows.length,missingSamples:missing,displayWmaRadius:Number($('displayFilter').value),wmaDisplayOnly:true, wmaCentered:true, wmaUsesReference:false, wmaAffectsController:false, rawFeedbackUnchanged:true, hybridEstimatorIsControlFeedback:true, medianOutlierThreshold_mps:.060, medianOutlierWindow:11,
    reverseConfirm_s:.30, reverseBacktrack_m:.008, heartbeatGuardMs:1500, displayMode, piIsolatedSpikeGuard:true, piSuspiciousThreshold_mps:.075, piConfirmSamples:4, exported:new Date().toISOString()},null,2),'application/json');
  message('Đã yêu cầu tải CSV + JSON. Cho phép trình duyệt tải nhiều tệp.');
};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&owned){navigator.sendBeacon('/stop',new URLSearchParams());stop();}});
window.addEventListener('pagehide',()=>{if(owned)navigator.sendBeacon('/stop',new URLSearchParams());});
setInterval(heartbeat,250);setInterval(poll,200);drawAll();poll();
</script></body></html>
)HTML";
