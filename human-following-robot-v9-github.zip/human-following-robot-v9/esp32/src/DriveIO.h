#pragma once
// DDMR V7.3 encoder-hybrid motor I/O.
// Preserve the user's proven ESP32 + L298N PWM structure:
// RIGHT motor / Channel A: ENA=GPIO13 (PWM), IN1=GPIO12, IN2=GPIO14.
// LEFT  motor / Channel B: ENB=GPIO25 (PWM), IN3=GPIO27, IN4=GPIO26.
// Direction is digital on IN pins; speed PWM is analogWrite() on ENA/ENB.
// LEFT encoder A/B: GPIO18/19, sign +1.
// RIGHT encoder A/B: GPIO32/35, sign -1.
//
// Safety behavior retained from V7.1:
// - motorSafeInit() is called first in setup; both bridges start disabled.
// - setMotor(0,0) immediately sets both EN PWM outputs to zero and all IN pins LOW.
// - a direction change disables both channels, sets direction pins, then waits
//   a non-blocking 20ms deadtime before applying PWM.
// - each EN channel is independently PWM-controlled; a zero wheel command
//   produces zero duty on that wheel's EN pin.
//
// Globals/constants are declared in main.cpp before including this file.

void IRAM_ATTR readEncoderLeft() {
  const uint32_t edgeUs = micros();
  const int8_t direction = (digitalRead(ENC_L_B) ? -1 : 1) * encoderLeftSign;
  portENTER_CRITICAL_ISR(&encoderMux);
  const uint32_t elapsed = uint32_t(edgeUs - encoderLeftLastEdgeUs);
  const uint32_t maxGap = encoderLeftPeriodUs > 0
    ? (encoderLeftPeriodUs * 3UL > 120000UL ? encoderLeftPeriodUs * 3UL : 120000UL)
    : 120000UL;
  if (encoderLeftLastEdgeUs != 0 && direction == encoderLeftEdgeDirection &&
      elapsed <= maxGap && elapsed <= 500000UL) {
    encoderLeftPeriodUs = elapsed;
  } else {
    // First edge after startup or a direction reversal: wait for the next
    // same-direction edge before publishing a valid period.
    encoderLeftPeriodUs = 0;
  }
  encoderLeftLastEdgeUs = edgeUs;
  encoderLeftEdgeDirection = direction;
  encoderLeft += direction;
  portEXIT_CRITICAL_ISR(&encoderMux);
}

void IRAM_ATTR readEncoderRight() {
  const uint32_t edgeUs = micros();
  const int8_t direction = (digitalRead(ENC_R_B) ? -1 : 1) * encoderRightSign;
  portENTER_CRITICAL_ISR(&encoderMux);
  const uint32_t elapsed = uint32_t(edgeUs - encoderRightLastEdgeUs);
  const uint32_t maxGap = encoderRightPeriodUs > 0
    ? (encoderRightPeriodUs * 3UL > 120000UL ? encoderRightPeriodUs * 3UL : 120000UL)
    : 120000UL;
  if (encoderRightLastEdgeUs != 0 && direction == encoderRightEdgeDirection &&
      elapsed <= maxGap && elapsed <= 500000UL) {
    encoderRightPeriodUs = elapsed;
  } else {
    encoderRightPeriodUs = 0;
  }
  encoderRightLastEdgeUs = edgeUs;
  encoderRightEdgeDirection = direction;
  encoderRight += direction;
  portEXIT_CRITICAL_ISR(&encoderMux);
}

static int8_t appliedLeftDirection = 0;
static int8_t appliedRightDirection = 0;
static bool directionDeadtimePending = false;
static uint32_t directionReadyAtUs = 0;

static inline int8_t motorDirection(int value, int8_t sign) {
  if (value > 0) return sign;
  if (value < 0) return -sign;
  return 0;
}

static inline void zeroDirectionInputs() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

static inline void writeDirectionPins(int8_t dirLeft, int8_t dirRight) {
  // RIGHT motor: L298N Channel A
  digitalWrite(IN1, dirRight > 0 ? HIGH : LOW);
  digitalWrite(IN2, dirRight < 0 ? HIGH : LOW);

  // LEFT motor: L298N Channel B
  digitalWrite(IN3, dirLeft > 0 ? HIGH : LOW);
  digitalWrite(IN4, dirLeft < 0 ? HIGH : LOW);
}

// Call as the FIRST operation in setup(). Preload safe LOW levels before
// changing pins to OUTPUT, then initialize ENA/ENB PWM at zero duty.
static void motorSafeInit() {
  digitalWrite(ENA, LOW);
  digitalWrite(ENB, LOW);
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);

  pinMode(ENA, OUTPUT);
  pinMode(ENB, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
  analogWrite(ENA, 0);
  analogWrite(ENB, 0);

  appliedLeftDirection = 0;
  appliedRightDirection = 0;
  directionDeadtimePending = false;
  directionReadyAtUs = 0;
  pwmLeft = 0;
  pwmRight = 0;
}

static void setMotor(int left, int right) {
  left = constrain(left, -PWM_MAX, PWM_MAX);
  right = constrain(right, -PWM_MAX, PWM_MAX);
  pwmLeft = left;
  pwmRight = right;

  const int8_t dirL = motorDirection(left, MOTOR_LEFT_SIGN);
  const int8_t dirR = motorDirection(right, MOTOR_RIGHT_SIGN);

  // A zero command must disable both bridges immediately, regardless of
  // direction state or whether a direction-change deadtime is pending.
  if (left == 0 && right == 0) {
    analogWrite(ENA, 0);
    analogWrite(ENB, 0);
    zeroDirectionInputs();
    appliedLeftDirection = 0;
    appliedRightDirection = 0;
    directionDeadtimePending = false;
    directionReadyAtUs = 0;
    return;
  }

  // Disable both channels before changing either wheel's direction.
  // Set static direction levels now; only ENA/ENB carry PWM.
  if (dirL != appliedLeftDirection || dirR != appliedRightDirection) {
    analogWrite(ENA, 0);
    analogWrite(ENB, 0);
    zeroDirectionInputs();
    writeDirectionPins(dirL, dirR);

    appliedLeftDirection = dirL;
    appliedRightDirection = dirR;
    directionReadyAtUs = micros() + 20000UL;
    directionDeadtimePending = true;
    return;
  }

  if (directionDeadtimePending) {
    if (static_cast<int32_t>(micros() - directionReadyAtUs) < 0) return;
    directionDeadtimePending = false;
  }

  // The user's verified baseline: analogWrite() on ENA/ENB for speed,
  // digitalWrite() on IN1..IN4 for direction. Each wheel is independent.
  analogWrite(ENA, dirR != 0 ? abs(right) : 0);
  analogWrite(ENB, dirL != 0 ? abs(left) : 0);
}
