#pragma once
// V7.3: retain legacy count estimators for comparison and add a hybrid
// low-speed edge-period / high-speed count-window velocity estimate.
// No ESP32 dependency: this file is unit tested on a desktop C++ compiler.
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace Tracking {
inline float clamp(float x,float lo,float hi){return std::max(lo,std::min(hi,x));}
inline float target(float vRef,float vmax){return clamp(vRef,0.0f,vmax);}
static constexpr float PWM_LIMIT=120.0f;
static constexpr float PWM_RISE=150.0f; // Limit sudden acceleration
static constexpr float PWM_FALL=420.0f; // Release power quickly when motor exceeds reference
static constexpr float DISPLAY_TAU=.080f;
struct Speed {
  static constexpr int N=12;
  float delta[N]={},period[N]={};
  int cursor=0,filled=0;
  float raw=0,feedback=0,windowed=0,filtered=0;
  float adaptive=0, adaptiveWindow=0;

  // V7.3 hybrid estimator diagnostics.
  float periodSpeed=0.0f;       // instantaneous signed speed from edge-to-edge period
  float periodFiltered=0.0f;    // causal low-pass of period estimate
  float hybrid=0.0f;            // final estimate used by PI/safety
  float pulseAge=999.0f;      // seconds since latest encoder A rising edge
  uint8_t hybridMode=0;         // 0=invalid/stopped, 1=period, 2=blend, 3=count-window
  bool periodFilterInitialized=false;

  void reset(){
    for(int i=0;i<N;++i){delta[i]=0;period[i]=0;}
    cursor=filled=0;raw=feedback=windowed=filtered=0;
    adaptive=adaptiveWindow=0;
    periodSpeed=periodFiltered=hybrid=0.0f;
    pulseAge=999.0f;hybridMode=0;periodFilterInitialized=false;
  }

  // Legacy count estimators are retained as diagnostics and for A/B comparison.
  void update(float distance,float dt){
    if(!std::isfinite(distance)||!std::isfinite(dt)||dt<=0)return;
    raw=distance/dt;
    delta[cursor]=distance;period[cursor]=dt;
    cursor=(cursor+1)%N;
    if(filled<N)++filled;
    float s60=0,t60=0,s100=0,t100=0;
    for(int j=0;j<filled;++j){
      const int index=(cursor-1-j+N)%N;
      if(j<5){s100+=delta[index];t100+=period[index];}
      if(j<3){s60+=delta[index];t60+=period[index];}
    }
    feedback=t60>0?s60/t60:0;
    windowed=t100>0?s100/t100:0;
    filtered+=(1.0f-std::exp(-dt/DISPLAY_TAU))*(windowed-filtered);
  }

  // Count-window estimator retained from V7.2. It is more reliable at
  // moderate/high speed, where multiple encoder edges occur per window.
  float estimateAdaptive(float refMps,float metresPerCount){
    if(!std::isfinite(refMps)||!std::isfinite(metresPerCount)||metresPerCount<=0){
      adaptive=adaptiveWindow=0;return adaptive;
    }
    const float reference=std::max(std::abs(refMps),.015f);
    const float targetWindow=clamp(8.0f*metresPerCount/reference,.080f,.200f);
    float travelled=0.0f,elapsed=0.0f;
    for(int i=0;i<filled;++i){
      const int index=(cursor-1-i+N)%N;
      travelled+=delta[index];elapsed+=period[index];
      if(elapsed>=targetWindow)break;
    }
    adaptiveWindow=elapsed;
    adaptive=elapsed>0?travelled/elapsed:0.0f;
    return adaptive;
  }

  // Hybrid estimator:
  // - low speed: time between successive A-rising edges (period method)
  // - higher speed: causal 80..200ms count window
  // - blend through the transition region to avoid a discontinuity.
  // No reference signal is mixed into the measured speed; ref only selects
  // the estimator weighting. Both component estimates remain separately logged.
  float updateHybrid(uint32_t nowUs,uint32_t lastEdgeUs,uint32_t edgePeriodUs,
                     int8_t edgeDirection,float refMps,float metresPerCount,float dt){
    estimateAdaptive(refMps,metresPerCount);

    if(lastEdgeUs==0){
      pulseAge=999.0f;
    }else{
      pulseAge=float(uint32_t(nowUs-lastEdgeUs))*1.0e-6f;
    }

    const float edgePeriodS=edgePeriodUs>0?float(edgePeriodUs)*1.0e-6f:0.0f;
    const float staleLimit=edgePeriodS>0
      ?clamp(3.0f*edgePeriodS,.120f,.500f):.120f;
    const bool pulseValid=(lastEdgeUs!=0 && edgePeriodUs>0 && edgePeriodUs<=500000UL &&
                           edgeDirection!=0 && pulseAge<=staleLimit);

    if(pulseValid){
      periodSpeed=clamp(float(edgeDirection)*metresPerCount/edgePeriodS,-.50f,.50f);
      const float alpha=1.0f-std::exp(-dt/.050f);
      if(!periodFilterInitialized){
        periodFiltered=periodSpeed;
        periodFilterInitialized=true;
      }else{
        periodFiltered+=alpha*(periodSpeed-periodFiltered);
      }
    }else{
      periodSpeed=0.0f;
      if(periodFilterInitialized){
        const float decay=std::exp(-dt/.050f);
        periodFiltered*=decay;
        if(pulseAge>staleLimit*1.5f && std::abs(periodFiltered)<.001f){
          periodFiltered=0.0f;
          periodFilterInitialized=false;
        }
      }
    }

    // Require most of the requested count window before trusting it.
    const float reference=std::max(std::abs(refMps),.015f);
    const float desiredWindow=clamp(8.0f*metresPerCount/reference,.080f,.200f);
    const bool countValid=(filled>=3 && adaptiveWindow>=.75f*desiredWindow);
    const float countSpeed=countValid?adaptive:0.0f;

    if(pulseValid && countValid){
      // Select the blend from the measured period speed (not by mixing in
      // the command/reference). A wheel that is commanded fast but still
      // moving slowly must retain the higher-resolution period estimate.
      const float hint=std::abs(periodFiltered);
      const float countWeight=clamp((hint-.040f)/.045f,0.0f,1.0f);
      hybrid=(1.0f-countWeight)*periodFiltered+countWeight*countSpeed;
      hybridMode=(countWeight<=.001f)?1:((countWeight>=.999f)?3:2);
    }else if(pulseValid){
      hybrid=periodFiltered;
      hybridMode=1;
    }else if(countValid){
      hybrid=countSpeed;
      hybridMode=3;
    }else{
      hybrid=0.0f;
      hybridMode=0;
    }

    if(!std::isfinite(hybrid))hybrid=0.0f;
    return hybrid;
  }
};
// A causal, 1st-order filter that influences the PI ONLY when the operator
// selects the smooth mode. Reset at the beginning of every run.
struct PIResponseEMA {
  static constexpr float TAU_S=.060f;
  float value=0;
  void reset(){value=0;}
  float update(float measured,float dt){
    if(!std::isfinite(measured)||!std::isfinite(dt)||dt<=0)return value;
    const float alpha=1.0f-std::exp(-dt/TAU_S);
    value+=alpha*(measured-value);
    return value;
  }
};

// PI-only rejection of isolated 60-ms encoder velocity impulses. IMPORTANT:
// - raw signed counts and raw 60-ms encoder speed are NEVER overwritten;
// - Safety::check receives raw speed and raw position, not guarded speed;
// - actual persistent reversal/overspeed is accepted after 4 samples and
//   still triggers the independent safety mechanism.
// An isolated glitch can pollute three overlapping 60-ms estimates; 4 ticks
// of persistence separates this case from a sustained physical change.
struct FeedbackGuard {
  static constexpr float JUMP_MPS=0.075f;
  static constexpr float REVERSE_MPS=-0.025f;
  static constexpr unsigned int CONFIRM_TICKS=4;
  float output=0;
  unsigned int pending=0;
  unsigned int rejectedTotal=0;
  bool rejectedNow=false;
  void reset(){output=0;pending=0;rejectedTotal=0;rejectedNow=false;}
  float update(float measured,float reference){
    rejectedNow=false;
    if(!std::isfinite(measured))return output; // separate raw safety flags invalid
    const bool movingForward=reference>=0.015f;
    const bool reverseSpike=movingForward && measured<REVERSE_MPS;
    const bool bigJump=movingForward && std::abs(measured-output)>JUMP_MPS;
    if(!reverseSpike&&!bigJump){pending=0;output=measured;return output;}
    ++pending;
    if(pending>=CONFIRM_TICKS){output=measured;pending=0;return output;}
    ++rejectedTotal;
    rejectedNow=true;
    return output;
  }
};

// V8.1 gains: staticPWM + kff * RPM, PI error measured in RPM.
// Defaults are NOT physical motor calibration values.
struct WheelGains {
  float staticPWM=46.0f;
  float kff=0.22f;       // PWM per RPM
  float kp=1.50f;        // PWM per RPM
  float ki=1.00f;       // PWM per (RPM*s)
  float ka=0.0f;         // OPTIONAL PWM per (m/s^2); zero is exactly V6.1
  float loadPWM=0.0f;    // Added to smooth static FF, zero preserves V6.2
};
struct Gains {
  WheelGains left;
  WheelGains right;
  Gains(){right.staticPWM=52.0f;}
};

struct WheelPI {
  float integral=0, output=0, feedforward=0, refRPM=0, feedbackRPM=0;
  void reset(){integral=output=feedforward=refRPM=feedbackRPM=0;}
  int update(float wanted,float measured,float dt,const WheelGains &g,
             float wheelCircumferenceM=3.14159265358979323846f*.065f,
             float accelRef=0.0f){
    if(!std::isfinite(wanted)||!std::isfinite(measured)||!std::isfinite(dt)||
       dt<=0||!std::isfinite(wheelCircumferenceM)||wheelCircumferenceM<=0||wanted<.001f){
      reset();return 0;
    }
    refRPM=wanted*60.0f/wheelCircumferenceM;
    feedbackRPM=measured*60.0f/wheelCircumferenceM;
    const float error=refRPM-feedbackRPM;
    // Smooth startup: no sudden full static PWM at tiny references.
    const float ratio=clamp(wanted/.025f,0.0f,1.0f);
    const float faded=ratio*ratio*(3.0f-2.0f*ratio);
    // Optional acceleration feedforward; bounded to +/-15 PWM.
    // The default ka=0 reproduces V6.1 bit-for-bit for unchanged inputs.
    const float accelTerm=clamp(g.ka*accelRef,-15.0f,15.0f);
    // Optional per-wheel load compensation. Applied smoothly to avoid a
    // full PWM step at near-zero speed. Bounded before PWM hard clamp.
    feedforward=(g.staticPWM+clamp(g.loadPWM,0.0f,50.0f))*faded+g.kff*refRPM+accelTerm;
    // Velocity error is the ONLY feedback. No position-induced change of v_ref.
    const float oldOutput=output;
    const float lo=std::max(0.0f,oldOutput-PWM_FALL*dt);
    const float hi=std::min(PWM_LIMIT,oldOutput+PWM_RISE*dt);
    const float p=g.kp*error;
    const float requested=feedforward+p+integral;
    const float constrained=clamp(requested,lo,hi);
    // Conditional anti-windup: only integrate if error tends to escape the
    // imposed clamp, or command was feasible. Negative integral cancels excess FF.
    const bool high=requested>constrained+1.e-4f;
    const bool low=requested<constrained-1.e-4f;
    if((!high&&!low)||(high&&error<0)||(low&&error>0)){
      integral=clamp(integral+g.ki*error*dt,-100.0f,80.0f);
    }
    output=clamp(feedforward+p+integral,lo,hi);
    return (int)std::lround(output);
  }
};

// Optional, slow right-only assistance during flat-speed tracking.
// It never modifies the left wheel or the velocity reference, and never
// bypasses the PI PWM clamp, slew limit, encoder stall and safety guard.
struct RightBalance {
  float addedPWM=0.0f;
  void reset(){addedPWM=0.0f;}
  float update(float ref,float vLeft,float vRight,float accel,float dt){
    if(!std::isfinite(ref)||!std::isfinite(vLeft)||!std::isfinite(vRight)||
       !std::isfinite(accel)||!std::isfinite(dt)||dt<=0||dt>.06f){
      reset();return 0.0f;
    }
    // Never add power once braking begins; blend the assistance away.
    if(ref<.020f || accel<-.005f){
      addedPWM=std::max(0.0f,addedPWM-30.0f*dt);
    }else if(ref>=.065f && std::abs(accel)<.015f &&
             std::abs(vLeft-ref)<=.014f && vRight>.003f){
      // Only help the right wheel while left is close to its reference.
      const float err=ref-vRight;
      if(err>.012f)addedPWM=std::min(20.0f,addedPWM+7.0f*dt);
      else if(err<-.002f)addedPWM=std::max(0.0f,addedPWM-24.0f*dt);
      else if(err<.006f)addedPWM=std::max(0.0f,addedPWM-7.0f*dt);
    }
    return addedPWM;
  }
};

struct Safety {
  // V6.5: a speed mismatch between the wheels is NOT reverse motion.
  // The measured speed is a ~60ms encoder window; one bad count can appear
  // in three consecutive 20ms ticks. Trip only on *persistent* reverse
  // evidence: signed speed AND genuine backward displacement of that wheel.
  // Never correct/overwrite raw encoder counts or bypass other safety checks.
  static constexpr float REVERSE_SPEED_MPS = -0.030f;
  static constexpr float REVERSE_CONFIRM_S = 0.300f;
  static constexpr float REVERSE_DISTANCE_M = 0.008f;
  static constexpr float START_BACKWARD_M = 0.015f;
  float reverseTimeL=0,reverseTimeR=0;
  float peakSL=0,peakSR=0;
  float stallLeft=0,stallRight=0,overTime=0;
  void reset(){
    reverseTimeL=reverseTimeR=0;
    peakSL=peakSR=0;
    stallLeft=stallRight=overTime=0;
  }
  const char *check(float dt,float heartbeatAge,float sL,float sR,float goal,
                    float vL,float vR,float wantedL,float wantedR,int pwmL,int pwmR,float vmax){
    if(!std::isfinite(dt)||dt<=0||dt>.060f)return "CONTROL_DEADLINE";
    if(heartbeatAge>1.5f)return "WEB_HEARTBEAT_LOST";
    if(!std::isfinite(sL)||!std::isfinite(sR)||!std::isfinite(vL)||!std::isfinite(vR))
      return "INVALID_ENCODER_MEASUREMENT";
    if(std::max(sL,sR)>=goal+.020f)return "DISTANCE_GUARD";

    peakSL=std::max(peakSL,sL);
    peakSR=std::max(peakSR,sR);
    // Each wheel has its own debouncer. A right wheel going faster cannot
    // by itself trigger a reverse fault on either wheel.
    reverseTimeL=(vL<REVERSE_SPEED_MPS)
      ?reverseTimeL+dt:std::max(0.0f,reverseTimeL-2.0f*dt);
    reverseTimeR=(vR<REVERSE_SPEED_MPS)
      ?reverseTimeR+dt:std::max(0.0f,reverseTimeR-2.0f*dt);
    const float backL=peakSL-sL,backR=peakSR-sR;
    // Negative excursion below the start or genuine backwards travel
    // are still protected, but only after repeat evidence of reverse speed.
    if((reverseTimeL>=REVERSE_CONFIRM_S && backL>=REVERSE_DISTANCE_M) ||
       (reverseTimeL>=0.160f && sL<=-START_BACKWARD_M))return "NEGATIVE_ENCODER_LEFT";
    if((reverseTimeR>=REVERSE_CONFIRM_S && backR>=REVERSE_DISTANCE_M) ||
       (reverseTimeR>=0.160f && sR<=-START_BACKWARD_M))return "NEGATIVE_ENCODER_RIGHT";

    overTime=std::max(vL,vR)>std::max(.30f,2.0f*vmax)?overTime+dt:0;
    if(overTime>.30f)return "OVERSPEED";
    stallLeft=pwmL>=60&&wantedL>.025f&&std::abs(vL)<.003f?stallLeft+dt:0;
    stallRight=pwmR>=60&&wantedR>.025f&&std::abs(vR)<.003f?stallRight+dt:0;
    if(stallLeft>.7f||stallRight>.7f)return "STALL_OR_ENCODER_MISSING";
    return nullptr;
  }
};
} // namespace Tracking
