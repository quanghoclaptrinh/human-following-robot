#pragma once
#include <cmath>
#include <stdint.h>
// Seven-phase profile plus an independent acceleration-duration constraint.
struct MotionLimits { float vmax, amax, jmax; };
struct MotionSample { float s, v, a, j; uint8_t phase; };

struct SCurveProfile {
  float distance = 0.0f, tj = 0.0f, ta = 0.0f, tv = 0.0f;
  float tMin = 0.0f, lambda = 1.0f, tTotal = 0.0f, jmax = 0.0f;
  float accelTimeMin = 0.0f, accelTimeRequested = 0.0f;
  bool fixedAcceleration = false;
  uint8_t topology = 0;
  bool valid = false;

  bool plan(float requestedDistance, const MotionLimits &limits) {
    distance = fabsf(requestedDistance);
    tj = ta = tv = tMin = tTotal = 0.0f;
    lambda = 1.0f; topology = 0; valid = false;
    fixedAcceleration = false; accelTimeMin = accelTimeRequested = 0.0f;
    if (!std::isfinite(distance) || !std::isfinite(limits.vmax) ||
        !std::isfinite(limits.amax) || !std::isfinite(limits.jmax) ||
        limits.vmax <= 0.0f || limits.amax <= 0.0f || limits.jmax <= 0.0f) return false;
    if (distance < 1.0e-6f) { valid = true; return true; }

    jmax = limits.jmax;
    const float tjAtAmax = limits.amax / limits.jmax;
    const float velocityAtAmaxWithoutTa = limits.amax * tjAtAmax;
    if (limits.vmax < velocityAtAmaxWithoutTa) {
      const float tjAtVmax = sqrtf(limits.vmax / limits.jmax);
      const float distanceToVmax = 2.0f * limits.jmax * tjAtVmax * tjAtVmax * tjAtVmax;
      if (distance < distanceToVmax - 1.0e-6f) {
        topology = 1;
        tj = cbrtf(distance / (2.0f * limits.jmax));
      } else {
        topology = 2;
        tj = tjAtVmax;
        tv = fmaxf(0.0f, (distance - distanceToVmax) / limits.vmax);
      }
    } else {
      const float distanceToAmax = 2.0f * limits.jmax * tjAtAmax * tjAtAmax * tjAtAmax;
      const float taAtVmax = limits.vmax / limits.amax - tjAtAmax;
      const float halfDistanceAtVmax = limits.amax *
        (tjAtAmax * tjAtAmax + 1.5f * tjAtAmax * taAtVmax + 0.5f * taAtVmax * taAtVmax);
      const float distanceToVmax = 2.0f * halfDistanceAtVmax;
      if (distance < distanceToAmax - 1.0e-6f) {
        topology = 1;
        tj = cbrtf(distance / (2.0f * limits.jmax));
      } else if (distance < distanceToVmax - 1.0e-6f) {
        topology = 3;
        tj = tjAtAmax;
        const float radicand = tj * tj + 4.0f * distance / limits.amax;
        ta = fmaxf(0.0f, 0.5f * (-3.0f * tj + sqrtf(fmaxf(0.0f, radicand))));
      } else {
        topology = 4;
        tj = tjAtAmax;
        ta = fmaxf(0.0f, taAtVmax);
        tv = fmaxf(0.0f, (distance - distanceToVmax) / limits.vmax);
      }
    }
    tMin = 4.0f * tj + 2.0f * ta + tv;
    accelTimeMin = 2.0f * tj + ta;
    tTotal = tMin;
    valid = std::isfinite(tMin) && tMin > 0.0f;
    return valid;
  }

  void setTimeScale(float newLambda) {
    // Global time scaling would reduce the jerk and change the requested ramp.
    // It is deliberately unavailable in independent acceleration-time mode.
    if (fixedAcceleration) return;
    lambda = fmaxf(1.0f, newLambda);
    tTotal = tMin * lambda;
  }

  float peakVelocity() const {
    if (!valid || distance < 1.0e-6f) return 0.0f;
    return jmax * tj * (tj + ta) / lambda;
  }

  float accelerationTime() const { return (2.0f * tj + ta) * lambda; }
  float peakAcceleration() const { return jmax * tj / (lambda * lambda); }
  float peakJerk() const { return jmax / (lambda * lambda * lambda); }
  float accelerationTimeMax() const {
    const float v = peakVelocity();
    return v > 0.0f ? distance / v : 0.0f;
  }

  // Preserve the baseline attainable peak speed AND the jerk amplitude.
  // For a ramp of length Tr: Vp = J*tj*(Tr-tj), ta=Tr-2*tj.
  // Its symmetric accel/decel distance is Vp*Tr; cruise uses the remainder.
  // Short moves may have no spare distance: reject, never silently lower Vp/J.
  bool setAccelerationTime(float requested) {
    if (!valid || fixedAcceleration || lambda != 1.0f ||
        !std::isfinite(requested) || requested <= 0.0f || requested >= 3600.0f) return false;
    const double v = peakVelocity(), J = jmax, minimum = accelTimeMin;
    const double eps = 1.0e-5 * std::fmax(1.0, minimum);
    if (v <= 0.0 || J <= 0.0 || requested + eps < minimum) return false;
    const double ramp = std::fmax((double)requested, minimum);
    const double cruise = distance / v - ramp;
    if (cruise < -1.0e-5 || ramp + distance / v >= 3600.0) return false;
    double discriminant = ramp * ramp - 4.0 * v / J;
    if (discriminant < -1.0e-5) return false;
    discriminant = std::fmax(0.0, discriminant);
    // Stable small root; avoid cancellation for long ramps.
    const double jerkTime = (2.0 * v / J) / (ramp + std::sqrt(discriminant));
    const double hold = ramp - 2.0 * jerkTime;
    if (hold < -1.0e-5) return false;
    tj = jerkTime; ta = std::fmax(0.0, hold); tv = std::fmax(0.0, cruise);
    tTotal = 4.0f * tj + 2.0f * ta + tv;
    fixedAcceleration = true; accelTimeRequested = requested; lambda = 1.0f;
    topology = ta > 1.0e-6f ? (tv > 1.0e-6f ? 4 : 3) : (tv > 1.0e-6f ? 2 : 1);
    return std::isfinite(tTotal);
  }

  static void integrate(float dt, float jerk, float &s, float &v, float &a) {
    s += v * dt + 0.5f * a * dt * dt + (1.0f / 6.0f) * jerk * dt * dt * dt;
    v += a * dt + 0.5f * jerk * dt * dt;
    a += jerk * dt;
  }

  MotionSample evaluate(float actualTime) const {
    MotionSample out{0.0f, 0.0f, 0.0f, 0.0f, 0};
    if (!valid || distance < 1.0e-6f) return out;
    if (actualTime <= 0.0f) {
      out.j = jmax / (lambda * lambda * lambda); out.phase = 1; return out;
    }
    if (actualTime >= tTotal) { out.s = distance; out.phase = 7; return out; }
    const float baseTime = actualTime / lambda;
    const float durations[7] = {tj, ta, tj, tv, tj, ta, tj};
    const float jerks[7] = {jmax, 0.0f, -jmax, 0.0f, -jmax, 0.0f, jmax};
    float remaining = baseTime, s = 0.0f, v = 0.0f, a = 0.0f;
    for (uint8_t i = 0; i < 7; ++i) {
      const float dt = fminf(remaining, durations[i]);
      if (dt > 0.0f) integrate(dt, jerks[i], s, v, a);
      if (remaining <= durations[i] + 1.0e-7f) {
        out.s = s; out.v = v / lambda; out.a = a / (lambda * lambda);
        out.j = jerks[i] / (lambda * lambda * lambda); out.phase = i + 1;
        return out;
      }
      remaining -= durations[i];
    }
    out.s = distance; out.phase = 7; return out;
  }
};
